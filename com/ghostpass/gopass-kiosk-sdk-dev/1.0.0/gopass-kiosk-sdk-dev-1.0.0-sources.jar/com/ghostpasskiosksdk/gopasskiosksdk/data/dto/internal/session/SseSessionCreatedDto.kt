package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session

import kotlinx.serialization.Serializable

@Serializable
internal data class SseSessionCreatedDto(
    val sessionId: String,
    val encryptedKioskDk: String,
    val rtdbPath: String,
    val firebaseToken: String,
    val expiresAt: String
)
package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth

internal enum class FaceAuthFailReason(val message: String? = null) {
    EMPTY_SESSION_IDS("SessionId가 비어 있습니다."),
    ALL_FAILED("모든 SessionId가 실패하였습니다."),
    TIMEOUT("인증 시간을 초과 하였습니다."),
    DECRYPTION_ERROR("복호화에 실패하였습니다."),
    PARSE_ERROR("Payload 파싱에 실패하였습니다."),
    UPDATE_FAILED,
    PERMISSION_DENIED,
    UNKNOWN()
}
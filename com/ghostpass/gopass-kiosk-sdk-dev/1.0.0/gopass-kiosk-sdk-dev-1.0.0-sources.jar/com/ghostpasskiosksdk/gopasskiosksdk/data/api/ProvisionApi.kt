package com.ghostpasskiosksdk.gopasskiosksdk.data.api

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.infra.ApiClient.Companion.HEADER_SKIP_SIGNATURE
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResponse
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.challenge.ChallengeData
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionData
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

internal interface ProvisionApi {
    companion object {
        private const val PREFIX = "api/v1"
    }
    @Headers("${HEADER_SKIP_SIGNATURE}: true")
    @GET("$PREFIX/sdk/attestation/challenge")
    suspend fun requestChallenge()
            : Response<ApiResponse<ChallengeData>>
    @Headers("${HEADER_SKIP_SIGNATURE}: true")
    @POST("$PREFIX/kiosk/enroll")
    suspend fun requestProvision(@Body body: ProvisionRequest)
            : Response<ApiResponse<ProvisionData>>
}
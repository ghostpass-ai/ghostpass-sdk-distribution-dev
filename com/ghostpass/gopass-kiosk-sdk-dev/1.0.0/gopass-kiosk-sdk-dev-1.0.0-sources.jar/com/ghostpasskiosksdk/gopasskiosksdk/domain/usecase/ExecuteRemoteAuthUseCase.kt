package com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemoteStateChannelRepository
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.SessionRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

internal class ExecuteRemoteAuthUseCase (
    private val remoteChannelRepository: RemoteStateChannelRepository,
    private val sessionRepository: SessionRepository
) {
    companion object {
        const val TAG = "RTDB 작업 TAG"
    }

    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend operator fun invoke(
        sessionPayloads: Map<SessionData, EncryptedSessionPayload>,
        timeoutMs: Long = 5000L
    ): SessionIdEvent {
        infoLog(TAG, "👾 RTDB 작업 시작")

        // 세션별로 각각 다르게 암호화된 데이터를 업데이트
        val updateResults = remoteChannelRepository.updateKioskSecureData(sessionPayloads)

        val successSessions = mutableSetOf<SessionData>()
        val failedSessions = mutableSetOf<SessionData>()
        val tokenMap = mutableMapOf<String, AuthToken>()

        // 개별 검사: 성공/실패 분류 + 인증 토큰 수집
        updateResults.forEach { (session, result) ->
            result.onSuccess { authToken ->
                successSessions.add(session)
                tokenMap[session.sessionId] = authToken
            }.onFailure { e ->
                failedSessions.add(session)
                errorLog(TAG, "세션(${session.sessionId}) 업데이트 실패: ${e.message}")
            }
        }

        // 업데이트 실패 세션: 실패 결과 보고 (정리하지 않음 - 타임아웃까지 유지)
        if (failedSessions.isNotEmpty()) {
            reportFailedSessionsBackground(failedSessions)
        }

        if (successSessions.isEmpty()) {
            return SessionIdEvent.Failed(FaceAuthFailReason.UPDATE_FAILED)
        }

        var authEvent: SessionIdEvent = SessionIdEvent.Failed(FaceAuthFailReason.TIMEOUT)
        try {
            authEvent = remoteChannelRepository.observeSessionId(
                sessionIds = successSessions,
                tokenMap = tokenMap,
                timeoutMs = timeoutMs
            )
        } finally {
            // 모든 성공 세션 결과 보고 + 승리 세션만 정리
            reportResultsAndCleanupWinnerBackground(successSessions.toSet(), authEvent)
            tokenMap.clear()
            successSessions.clear()
        }
        return authEvent
    }

    private fun reportFailedSessionsBackground(failedSessions: Set<SessionData>) {
        backgroundScope.launch {
            failedSessions.forEach { session ->
                runCatching { sessionRepository.submitResult(session.sessionId, false) }
                    .onFailure { e -> errorLog(TAG, "submitResult 실패 [${session.sessionId}]: ${e.message}") }
            }
        }
    }

    private fun reportResultsAndCleanupWinnerBackground(
        successSessions: Set<SessionData>,
        authEvent: SessionIdEvent
    ) {
        backgroundScope.launch {
            val winnerId = (authEvent as? SessionIdEvent.Success)?.sessionId

            try {
                successSessions.forEach { session ->
                    val isWinner = session.sessionId == winnerId
                    runCatching { sessionRepository.submitResult(session.sessionId, isWinner) }
                        .onFailure { e -> errorLog(TAG, "submitResult 실패 [${session.sessionId}]: ${e.message}") }
                }
            } finally {
                if (winnerId != null) {
                    debugLog(TAG, "승리 세션 정리 완료: $winnerId")
                }
            }
        }
    }

    /**
     * 내부 백그라운드 스코프를 취소하여 진행 중인 결과 보고 코루틴을 정리합니다.
     * 호출 후 이 인스턴스의 백그라운드 작업은 더 이상 실행되지 않습니다.
     */
    fun destroy() {
        backgroundScope.coroutineContext[Job]?.cancel()
    }
}

package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth

internal sealed class LivenessResult {
    data object Collecting : LivenessResult() // 수집중 (4장 안모임)
    data object Passed : LivenessResult()
    data object NotConfirmed : LivenessResult() // confidence 미달 (재시도 카운트 누적)
    data object TxFailed : LivenessResult() // 라이브니스 체크 3번 누적되어 Transaction 실패 확정
}

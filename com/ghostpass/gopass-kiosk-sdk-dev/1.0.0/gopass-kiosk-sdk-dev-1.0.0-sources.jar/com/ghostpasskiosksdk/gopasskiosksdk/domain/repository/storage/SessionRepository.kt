package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.InitiatedSessionPayload

internal interface SessionRepository {
    suspend fun submitResult(sessionId: String, success: Boolean): Result<Unit>
    suspend fun requestSession(deviceId: String): ApiResult<InitiatedSessionPayload>
}
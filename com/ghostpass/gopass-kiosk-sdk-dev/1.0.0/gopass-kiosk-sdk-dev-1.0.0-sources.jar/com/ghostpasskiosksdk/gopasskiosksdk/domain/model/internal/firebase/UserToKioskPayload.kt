package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase

internal data class UserToKioskPayload(
    val payload: String,
    val seq: Int,
    val ts: Long = 0L
)

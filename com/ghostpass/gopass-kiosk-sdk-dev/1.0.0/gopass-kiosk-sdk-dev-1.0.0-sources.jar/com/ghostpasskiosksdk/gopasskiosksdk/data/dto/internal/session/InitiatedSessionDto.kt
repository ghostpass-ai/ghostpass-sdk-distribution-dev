package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session

import kotlinx.serialization.Serializable

@Serializable
internal data class InitiatedSessionDto(
    val sessionId: String,
    val rtdbPath: String,
    val encryptedDk: String,
    val firebaseToken: String,
    val expiresAt: String
)

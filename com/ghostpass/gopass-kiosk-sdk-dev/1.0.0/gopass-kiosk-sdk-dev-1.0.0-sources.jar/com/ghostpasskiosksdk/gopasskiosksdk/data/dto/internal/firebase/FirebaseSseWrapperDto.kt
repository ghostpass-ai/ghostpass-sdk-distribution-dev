package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase

import kotlinx.serialization.Serializable

@Serializable
internal data class FirebaseSseWrapperDto(
    val path: String,
    val data: UserToKioskPayloadDto? = null
)

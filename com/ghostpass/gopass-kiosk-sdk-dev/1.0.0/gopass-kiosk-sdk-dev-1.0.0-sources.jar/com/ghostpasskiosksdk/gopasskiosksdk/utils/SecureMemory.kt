package com.ghostpasskiosksdk.gopasskiosksdk.utils

import java.util.Arrays

internal fun ByteArray?.wipe() {
    if (this == null) return
    Arrays.fill(this, 0)
}

internal fun FloatArray?.wipe() {
    if (this == null) return
    Arrays.fill(this, 0f)
}

internal inline fun <R> ByteArray.useAndWipe(block: (ByteArray) -> R): R {
    return try {
        block(this)
    } finally {
        this.wipe() // 만들어두신 확장 함수를 여기서 호출!
    }
}
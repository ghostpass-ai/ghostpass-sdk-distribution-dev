package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.challenge

import kotlinx.serialization.Serializable

@Serializable
internal data class ChallengeData(
    val challenge: String,
    val expiresIn: Int
)
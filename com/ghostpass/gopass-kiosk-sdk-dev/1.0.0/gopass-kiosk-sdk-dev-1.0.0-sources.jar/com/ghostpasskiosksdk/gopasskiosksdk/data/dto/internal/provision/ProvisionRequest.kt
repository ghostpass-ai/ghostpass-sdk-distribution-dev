package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision

import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName

@Serializable
internal data class ProvisionRequest(
    val challenge: String,
    val kioskId: String,
    val platform: String,
    val beaconMajor: Int,
    val beaconMinor: Int,
    @SerialName("attestationData")val attestation: String,
    val clientPublicKey: String
)
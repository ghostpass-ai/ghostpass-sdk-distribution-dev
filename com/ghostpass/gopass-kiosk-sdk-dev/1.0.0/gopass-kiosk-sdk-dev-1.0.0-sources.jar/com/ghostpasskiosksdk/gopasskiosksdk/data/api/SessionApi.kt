package com.ghostpasskiosksdk.gopasskiosksdk.data.api

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResponse
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.InitiatedSessionDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.InitiatedSessionRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.SessionResultDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.SessionResultRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path

internal interface SessionApi {
    companion object {
        const val PREFIX = "api/v1/sessions"
    }
    @POST("$PREFIX/{sessionId}/result")
    suspend fun submitSessionResult(
        @Path("sessionId") sessionId: String,
        @Body request: SessionResultRequest
    ) : Response<ApiResponse<SessionResultDto>>

    @POST("$PREFIX/kiosk-initiated")
    suspend fun requestSession(
        @Body request: InitiatedSessionRequest
    ) : Response<ApiResponse<InitiatedSessionDto>>
}
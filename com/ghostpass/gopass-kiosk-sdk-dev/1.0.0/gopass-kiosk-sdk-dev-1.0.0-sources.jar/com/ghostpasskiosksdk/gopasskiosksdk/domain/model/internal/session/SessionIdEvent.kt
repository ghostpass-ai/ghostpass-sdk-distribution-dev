package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason

internal sealed class SessionIdEvent {
    data class Success(
        val sessionId: String
    ) : SessionIdEvent()
    data class Failed(val reason : FaceAuthFailReason) : SessionIdEvent()
}
package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase

internal data class KioskToUserPayload (
    val encryptedData: String,
    val sequence: Int,
    val timestamp: Long
)

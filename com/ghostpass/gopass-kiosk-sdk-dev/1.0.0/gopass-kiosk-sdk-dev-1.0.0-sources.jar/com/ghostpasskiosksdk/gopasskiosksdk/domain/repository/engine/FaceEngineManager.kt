package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine

internal interface FaceEngineManager {
    // 1. 초기화
    suspend fun initialize()
}
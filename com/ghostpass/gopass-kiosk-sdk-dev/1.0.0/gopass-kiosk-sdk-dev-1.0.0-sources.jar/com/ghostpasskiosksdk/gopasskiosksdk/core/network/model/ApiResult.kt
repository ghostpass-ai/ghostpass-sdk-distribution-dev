package com.ghostpasskiosksdk.gopasskiosksdk.core.network.model

internal sealed class ApiResult<out T> {
    data class Success<T>(val data: T, val message: String? = null) : ApiResult<T>()
    data class Failure(
        val httpCode: Int,
        val code: String? = null,
        val message: String? = null,
    ) : ApiResult<Nothing>()

    data class NetworkError(val error: Throwable) : ApiResult<Nothing>()
}
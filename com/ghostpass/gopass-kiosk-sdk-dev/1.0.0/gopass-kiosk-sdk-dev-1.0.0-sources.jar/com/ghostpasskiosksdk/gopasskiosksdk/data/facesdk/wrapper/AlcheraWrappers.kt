package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper

import com.alcherainc.facesdk.type.Face
import com.alcherainc.facesdk.type.InputImage
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine.FaceEngineTypes

// Alchera의 InputImage를 감싸는 래퍼
internal class AlcheraImageFrame(
    val originImage: InputImage
) : FaceEngineTypes.FaceImageFrame

// Alchera의 Face를 감싸는 래퍼
internal class AlcheraDetectedFace(
    val originFace: Face
) : FaceEngineTypes.DetectedFace
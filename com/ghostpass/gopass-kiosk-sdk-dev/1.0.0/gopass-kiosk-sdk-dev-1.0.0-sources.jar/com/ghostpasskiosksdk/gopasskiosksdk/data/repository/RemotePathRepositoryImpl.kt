package com.ghostpasskiosksdk.gopasskiosksdk.data.repository

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.SseSessionCreatedDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.toDomain
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SseSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemotePathRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.retryWhen
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json.Default.decodeFromString
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import java.io.IOException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.pow

internal class RemotePathRepositoryImpl(
    private val okHttpClient: OkHttpClient
) : RemotePathRepository {
    companion object {
        const val TAG = "SSE Repository TAG"
        private const val MAX_EXPONENTIAL_BACKOFF_MS = 30_000L  // 최대 30초 대기
        private const val AUTH_ERROR_DELAY_MS = 60_000L       // 인증 에러 시 1분 대기
        private const val DNS_ERROR_DELAY_MS = 60_000L        // DNS 실패(화면 꺼짐 등) 시 1분 대기
        private const val HEARTBEAT_TIMEOUT_MS = 150_000L     // 30초 × 5회 = 150초 미수신 시 타임아웃
        private const val HEARTBEAT_CHECK_INTERVAL_MS = 30_000L
    }

    override fun observePaths(): Flow<SseSessionPayload> = callbackFlow {
        val lastEventAt = AtomicLong(0L)

        // 1. 요청 생성
        val request = Request.Builder()
            .url("${BuildConfig.BASE_URL}api/v1/kiosk/events")
            .header("Accept", "text/event-stream")
            .header("Cache-Control", "no-cache")
            .header("Connection", "keep-alive")
            .build()

        // 2. EventSource 리스너 설정
        val listener = object : EventSourceListener() {
            override fun onOpen(eventSource: EventSource, response: Response) {
                lastEventAt.set(System.currentTimeMillis())
                debugLog(TAG, "SSE Connection Opened! (HTTP 200)")
            }
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                lastEventAt.set(System.currentTimeMillis())
                debugLog(TAG, "Raw Event Received -> id: $id, type: $type, data: $data")
                runCatching {
                    when (type) {
                        "CONNECTED" -> {
                            debugLog(TAG, "SSE Successfully Connected: $data")
                        }

                        "HEARTBEAT" -> {
                            debugLog(TAG, "SSE Heartbeat 수신")
                        }

                        "SESSION_CREATED" -> {
                            debugLog(TAG, "data : $data")
                            val sseDto = decodeFromString<SseSessionCreatedDto>(data)
                            val sendResult = trySend(sseDto.toDomain())

                            if (sendResult.isSuccess) {
                                debugLog(TAG, "Channel 전송 성공!")
                            } else {
                                errorLog(TAG, "Channel 전송 실패 (버퍼 초과 등): ${sendResult.exceptionOrNull()}")
                            }
                        }

                        else -> debugLog(TAG, "Unknown Event Type: $type")
                    }
                }.onFailure { e ->
                    errorLog(TAG, "JSON 파싱 에러 발생 e: ${e.message}")
                    close(
                        GoPassSdkException.from(
                            error = ErrorCode.INTERNAL_ERROR,
                            cause = InternalErrorCode.SSE_INVALID_FORM
                        )
                    )
                }
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                val httpCode = response?.code
                val host = request.url.host

                val errorBody = runCatching {
                    response?.peekBody(1024L)?.string()
                }.getOrNull()

                errorLog(TAG, "⚠️ SSE Connection Failed: HTTP=$httpCode, Body=$errorBody, Error=${t?.message}")
                if (t is UnknownHostException) {
                    errorLog(TAG, "DNS 해석 실패: host=$host. 검증된 네트워크 복구 여부 또는 DNS/VPN/Private DNS 상태를 확인하세요.")
                }
                // IOException으로 통일하여 retryWhen에서 확실히 재시도
                if (httpCode == 401 || httpCode == 403) {
                    close(
                        GoPassSdkException.from(
                            error = ErrorCode.INTERNAL_ERROR,
                            cause = InternalErrorCode.SSE_AUTH_TOKEN_INVALID
                        )
                    )
                } else {
                    // 재배포(402, 5xx)나 DNS 실패 등은 모두 IOException으로 전달하여 백오프 태움
                    val exceptionMessage = "SSE failed (HTTP $httpCode, Body: $errorBody)"
                    close(t as? IOException ?: IOException(exceptionMessage))
                }
            }

            override fun onClosed(eventSource: EventSource) {
                close()
            }
        }
        val sseOkHttpClient = okHttpClient.newBuilder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()

        // 3. 연결 시작
        val factory = EventSources.createFactory(sseOkHttpClient)
        val eventSource = factory.newEventSource(request, listener)

        // 4. Heartbeat watchdog — 150초(30초 × 5회) 동안 이벤트 미수신 시 재연결 트리거
        val heartbeatWatchdog = launch {
            while (true) {
                delay(HEARTBEAT_CHECK_INTERVAL_MS)
                val last = lastEventAt.get()
                if (last > 0L && System.currentTimeMillis() - last > HEARTBEAT_TIMEOUT_MS) {
                    val elapsedSec = (System.currentTimeMillis() - last) / 1000
                    warnLog(TAG, "SSE Heartbeat 타임아웃: ${elapsedSec}초 동안 이벤트 미수신 — 재연결 트리거")
                    eventSource.cancel()
                    close(IOException("SSE heartbeat timeout: ${elapsedSec}s elapsed"))
                    break
                }
            }
        }

        // 5. Flow가 취소될 때 연결 종료
        awaitClose {
            debugLog(TAG, "SSE Connection Closed")
            heartbeatWatchdog.cancel()
            eventSource.cancel()
        }
    // 물리적 네트워크 단절 → 자동 재연결
    }.retryWhen { cause, attempt ->
        // 1. 수학적 오버플로우 방지 (cappedAttempt)
        val cappedAttempt = if (attempt > 20) 20 else attempt.toInt()

        // 2. 에러 유형 판별
        val isAuthError = cause is GoPassSdkException &&
            cause.causeCode == InternalErrorCode.SSE_AUTH_TOKEN_INVALID.code
        val isDnsError = cause is UnknownHostException

        val delayTime = when {
            isAuthError -> AUTH_ERROR_DELAY_MS // 인증 에러는 1분 단위로 똑똑
            isDnsError -> DNS_ERROR_DELAY_MS   // DNS 실패(Doze 모드 등) 시 1분 단위 대기
            else -> {
                // 일반적인 네트워크 장애/재배포는 지수 백오프 (최대 30초)
                minOf(
                    1000L * (2.0.pow(cappedAttempt.toDouble())).toLong(),
                    MAX_EXPONENTIAL_BACKOFF_MS
                )
            }
        }

        if (attempt % 10 == 0L) {
            errorLog(TAG, "SSE 재연결 시도 중 (attempt=$attempt): $cause")
        }
        delay(delayTime)
        true
    }
}

package com.ghostpasskiosksdk.gopasskiosksdk.core.device.infra

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.BluetoothStateProvider
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

internal class AndroidBluetoothProvider(
    private val context: Context
) : BluetoothStateProvider {
    companion object {
        private const val TAG = "AndroidBluetoothProvider TAG"
    }
    private val _isEnabled = MutableStateFlow(checkBluetoothEnabled())
    override val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    private val isMonitoring = AtomicBoolean(false)
    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                _isEnabled.value = checkBluetoothEnabled()
            }
        }
    }

    override fun startMonitoring() {
        if (!isMonitoring.compareAndSet(false, true)) {
            return
        }

        context.registerReceiver(
            bluetoothReceiver,
            IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED)
        )
    }

    override fun stopMonitoring() {
        if (!isMonitoring.compareAndSet(true, false)) {
            return
        }

        try {
            context.unregisterReceiver(bluetoothReceiver)
        } catch (e: IllegalArgumentException) {
            warnLog(TAG, "해제할 리시버가 존재하지 않음")
        }
    }

    override fun checkBluetoothEnabled(): Boolean {
        return getAdapter()?.isEnabled ?: false
    }

    override fun isBleAdvertisingSupported(): Boolean {
        val adapter = getAdapter() ?: return false
        if (!adapter.isEnabled) return false
        /**
         * BLE Advertising 지원 여부 판단 로직 && 가 아닌 || 를 사용하는 이유:
         * 일부 안드로이드 단말(특정 제조사 칩셋)은 단일 광고(Single Advertising)는 지원하지만,
         * 하드웨어 드라이버 특성상 isMultipleAdvertisementSupported 에서 false를 반환하는 경우가 존재함.
         * * 우리 SDK는 단일 비콘 송출이 목적이므로, bluetoothLeAdvertiser 객체가 존재한다면
         * 최대한 송출 시도를 허용함(False Negative 방지).
         * 실제 송출 실패 케이스(False Positive)는 BeaconBroadcaster의 startAdvertising 콜백에서
         * 2차적으로 걸러내어 안정성을 확보함.
         */
        return adapter.bluetoothLeAdvertiser != null || adapter.isMultipleAdvertisementSupported
    }

    private fun getAdapter(): BluetoothAdapter? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(BluetoothManager::class.java)?.adapter
        } else {
            @Suppress("DEPRECATION")
            BluetoothAdapter.getDefaultAdapter()
        }
    }
}
package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.FailReason

internal sealed class FaceAuthPrecheckResult {
    abstract val checks: FaceAuthChecks

    data class Success(
        override val checks: FaceAuthChecks,
        val landmark: FloatArray
    ) : FaceAuthPrecheckResult() {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as Success

            if (checks != other.checks) return false
            return landmark.contentEquals(other.landmark)
        }

        override fun hashCode(): Int {
            var result = checks.hashCode()
            result = 31 * result + landmark.contentHashCode()
            return result
        }
    }

    data class Failed(
        override val checks: FaceAuthChecks,
        val reasons: List<FailReason>
    ) : FaceAuthPrecheckResult()
}

internal data class FaceAuthChecks(
    val isValidPose: Boolean = false,
    val isValidPosition: Boolean = false,
    val isValidSizeMax: Boolean = false,
    val isValidSizeMin: Boolean = false,
) {
    companion object {
        // 모든 기본 검증(포즈, 위치, 크기)을 통과한 상태를 상수로 만들어 둡니다.
        val ALL_PASSED = FaceAuthChecks(
            isValidPose = true,
            isValidPosition = true,
            isValidSizeMax = true,
            isValidSizeMin = true
        )
    }
}


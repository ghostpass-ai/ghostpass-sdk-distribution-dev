package com.ghostpasskiosksdk.gopasskiosksdk.data.api

import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.CustomTokenSignInDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.CustomTokenSignInRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.KioskToUserPayloadDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

internal interface FirebaseApi {
    @POST("https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken")
    suspend fun signInWithCustomToken(
        @Query("key") apiKey: String, // Firebase Web API Key
        @Body request: CustomTokenSignInRequest
    ): Response<CustomTokenSignInDto>

    @PATCH
    suspend fun updateSessionState(
        @Url url: String,
        @Query("auth") auth: String,
        @Body data: KioskToUserPayloadDto
    ): Response<Unit>
}
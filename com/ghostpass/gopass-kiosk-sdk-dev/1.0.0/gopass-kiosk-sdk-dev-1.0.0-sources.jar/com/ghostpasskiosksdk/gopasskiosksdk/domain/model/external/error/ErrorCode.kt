package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error

import androidx.annotation.Keep

@Keep
enum class ErrorCode(val externalCode: String, val message: String? = null) {

    // 1. Init Error 0xx
    INVALID_ARGUMENT("GP001"),
    KIOSK_ALREADY_ENROLLED("GP002"),
    KIOSK_NOT_FOUND("GP003"),
    KIOSK_INACTIVE("GP004"),
    KIOSK_INVALID_ID_FORMAT("GP005"),
    INIT_FAILED("GP006", "초기화 중 문제가 발생하였습니다."),
    BLUETOOTH_DISABLED("GP007", "블루투스가 꺼져 있습니다. 설정에서 켜주세요."),
    BLUETOOTH_PERMISSION_DENIED("GP008", "필수 권한이 거부되었습니다. 권한을 허용해주세요."),
    BLUETOOTH_UNSUPPORTED_DEVICE("GP009", "이 기기는 블루투스 비콘 송출을 지원하지 않습니다."),

    // 2. Auth Error 1xx
    AUTH_TIMEOUT("GP101", "인증 시간이 초과되었습니다."),
    AUTH_REJECTED("GP102", "인증에 실패하였습니다."),
    AUTH_ERROR("GP103", "인증 오류가 발생했습니다."),

    // 3. Phone Auth Error 2xx
    PHONE_AUTH_LANDMARK_EXPIRED("GP201", "촬영한 얼굴 정보가 만료되었습니다. 다시 촬영해주세요."),

    // 4. 공용 Error 9xx
    NETWORK_ERROR("GP901", "네트워크 에러가 발생하였습니다."),
    SERVER_ERROR("GP902", "서버 오류가 발생하였습니다."),
    INVALID_API_KEY("GP903"),
    INTERNAL_ERROR("GP904", "내부 오류가 발생하였습니다."),
    RESET_FAILED("GP905", "SDK 초기화 해제 중 일부 자원을 반환하지 못했습니다."),


    UNKNOWN("GP999", "예상치 못한 응답 형식입니다.")
}
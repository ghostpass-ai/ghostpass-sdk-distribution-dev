package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.auth

import kotlinx.serialization.Serializable

@Serializable
internal data class AuthPayloadDto(
    val type: String,
    val result: String
)
package com.ghostpasskiosksdk.gopasskiosksdk.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.PreferenceStorage
import kotlinx.serialization.json.Json
import androidx.core.content.edit
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.LocalDataEncryptor
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog

internal class PreferenceStorageImpl (
    context: Context,
    private val localDataEncryptor: LocalDataEncryptor
) : PreferenceStorage {

    companion object {
        private const val TAG = "PreferenceStorageTAG"
        private const val PREF_NAME = "gopass_sdk_prefs"
        private const val PREF_API_KEY = "api_key"
        private const val PREF_KIOSK_ID = "kiosk_id"
        private const val PREF_BEACON_CONFIG = "beacon_config"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    override fun saveApiKey(apiKey: String) {
        val encryptedApiKey = localDataEncryptor.encrypt(apiKey)
        prefs.edit(commit = true) { putString(PREF_API_KEY, encryptedApiKey) }
    }

    override fun getApiKey(): String? {
        val encrypted = prefs.getString(PREF_API_KEY, null) ?: return null
        return try {
            localDataEncryptor.decrypt(encrypted)
        } catch (e: Exception) {
            errorLog(TAG, "getApiKey error : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.PREF_API_KEY_DECRYPTION_FAILED
            )
        }
    }

    override fun saveKioskId(kioskId: String) {
        val encryptedKioskID = localDataEncryptor.encrypt(kioskId)
        prefs.edit(commit = true) { putString(PREF_KIOSK_ID, encryptedKioskID) }
    }

    override fun getKioskId(): String? {
        val encrypted = prefs.getString(PREF_KIOSK_ID, null) ?: return null
        return try {
            localDataEncryptor.decrypt(encrypted)
        }catch (e : Exception) {
            errorLog(TAG, "getKioskId error : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.PREF_KIOSK_ID_DECRYPTION_FAILED
            )
        }
    }

    override fun saveBeaconConfig(beaconConfig: BeaconConfig) {
        val encoded = Json.encodeToString(beaconConfig)
        val encrypted = localDataEncryptor.encrypt(encoded)
        prefs.edit(commit = true) {
            putString(
                PREF_BEACON_CONFIG,
                encrypted
            )
        }
    }

    override fun getBeaconConfig(): BeaconConfig? {
        val encrypted = prefs.getString(PREF_BEACON_CONFIG, null) ?: return null
        return try {
            val decrypted = localDataEncryptor.decrypt(encrypted)
            Json.decodeFromString<BeaconConfig>(decrypted)
        }catch (e : Exception){
            errorLog(TAG, "getBeaconConfig error : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.PREF_BEACON_CONFIG_DECRYPTION_FAILED
            )
        }
    }
    override fun clearAll() {
        prefs.edit { clear() }
    }
}
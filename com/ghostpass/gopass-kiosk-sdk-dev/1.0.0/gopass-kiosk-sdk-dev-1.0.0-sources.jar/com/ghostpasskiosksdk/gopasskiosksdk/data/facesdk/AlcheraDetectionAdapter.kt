package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk

import com.alcherainc.facesdk.FaceSDK
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper.AlcheraDetectedFace
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper.AlcheraImageFrame
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine.FaceEngineTypes
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthChecks
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthPrecheckResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.FailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceDetectionEngine
import com.ghostpasskiosksdk.gopasskiosksdk.utils.Define
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog

internal class AlcheraDetectionAdapter (
    private val sdkManager: AlcheraSdkManager
) : FaceDetectionEngine {
    companion object{
        const val TAG = "AlcheraDetectionAdapter TAG"
    }

    override fun checkMemory(width: Int, height: Int): FaceAuthPrecheckResult.Failed? {
        val runtime = Runtime.getRuntime()
        val maxMemory = runtime.maxMemory()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val availableMemory = maxMemory - usedMemory
        val expectedImageSize = (width * height * 1.5).toLong()

        if (availableMemory < expectedImageSize * 2) {
            System.gc()
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(),
                reasons = listOf(FailReason.OOM)
            )
        }
        return null
    }

    override fun createInputImage(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotation: Int
    ): FaceEngineTypes.FaceImageFrame {
        val inputImage = FaceSDK.GetInputImageFromNV21Buffer(
            faceImage, width, height, rotation, true
        )
        return AlcheraImageFrame(inputImage)
    }

    override fun detectFirstFace(inputImage: FaceEngineTypes.FaceImageFrame): FaceEngineTypes.DetectedFace? {
        return try {
            val alcheraImage = (inputImage as AlcheraImageFrame).originImage

            val facesResult = sdkManager.faceSdk.DetectFaceInContinuousImage(alcheraImage)

            val firstFace = facesResult?.faces?.firstOrNull()

            firstFace?.let { AlcheraDetectedFace(it) }
        } catch (e: Exception) {
            errorLog(TAG, "detect first face error : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.DETECT_FIRST_FACE_FAILED
            )
        }
    }

    override fun validatePose(face: FaceEngineTypes.DetectedFace): FaceAuthPrecheckResult.Failed? {
        val nativeFace = (face as AlcheraDetectedFace).originFace

        val pv = Define.isValidPose(nativeFace.pose)
        if (!pv.isOk) {
            val reasons = buildList {
                if (!pv.rollOk) add(FailReason.INVALID_POSE_ROLL)
                if (!pv.pitchOk) add(FailReason.INVALID_POSE_PITCH)
                if (!pv.yawOk) add(FailReason.INVALID_POSE_YAW)
            }
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(),
                reasons = reasons
            )
        }
        return null
    }

    override fun validatePosition(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        if (!Define.isValidPosition(nativeImage, nativeFace)) {
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(isValidPose = true),
                reasons = listOf(FailReason.INVALID_POSITION)
            )
        }
        return null
    }

    override fun validateSizeMin(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        if (!Define.isValidSizeMin(nativeImage, nativeFace)) {
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(
                    isValidPose = true,
                    isValidPosition = true
                ),
                reasons = listOf(FailReason.INVALID_SIZE_MIN)
            )
        }
        return null
    }

    override fun validateSizeMax(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        if (!Define.isValidSizeMax(nativeImage, nativeFace)) {
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(
                    isValidPose = true,
                    isValidPosition = true,
                    isValidSizeMin = true),
                reasons = listOf(FailReason.INVALID_SIZE_MAX)
            )
        }
        return null
    }

    override fun validateLandmarkConfidence(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        val confidence = sdkManager.faceSdk.ComputeLandmarkConfidence(nativeImage, nativeFace)
        if (confidence.confidence < Define.VALID_FACE_DETECT_CONFIDENCE_VALUE) {
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks.ALL_PASSED,
                reasons = listOf(FailReason.LOW_LANDMARK_CONFIDENCE)
            )
        }
        return null
    }
}
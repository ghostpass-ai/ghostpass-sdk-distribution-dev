package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.BluetoothStateProvider
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.NetworkStateProvider
import java.util.concurrent.atomic.AtomicBoolean

internal class SystemStateMonitor(
    private val bluetoothStateProvider: BluetoothStateProvider,
    private val networkStateProvider: NetworkStateProvider
) {

    companion object {
        private const val TAG = "SystemStateMonitor TAG"
    }

    val isBluetoothEnabled = bluetoothStateProvider.isEnabled
    val isNetworkAvailable = networkStateProvider.isAvailable

    private val isMonitoring = AtomicBoolean(false)

    fun startMonitoring() {
        if (!isMonitoring.compareAndSet(false, true)) return

        bluetoothStateProvider.startMonitoring()
        networkStateProvider.startMonitoring()
    }

    fun stopMonitoring() {
        if (!isMonitoring.compareAndSet(true, false)) return

        bluetoothStateProvider.stopMonitoring()
        networkStateProvider.stopMonitoring()
    }
}
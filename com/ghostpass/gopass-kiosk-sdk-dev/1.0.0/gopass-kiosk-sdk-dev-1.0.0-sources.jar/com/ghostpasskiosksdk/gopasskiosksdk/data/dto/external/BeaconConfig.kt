package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.external

import kotlinx.serialization.Serializable

@Serializable
data class BeaconConfig(
    val uuid : String,
    val major : Int,
    val minor : Int
)
package com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain

import kotlinx.coroutines.flow.StateFlow

interface NetworkStateProvider {
    val isAvailable: StateFlow<Boolean>
    fun startMonitoring()
    fun stopMonitoring()
}
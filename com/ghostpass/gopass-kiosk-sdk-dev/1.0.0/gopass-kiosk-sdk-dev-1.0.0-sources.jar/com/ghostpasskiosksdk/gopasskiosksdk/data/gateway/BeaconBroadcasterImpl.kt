package com.ghostpasskiosksdk.gopasskiosksdk.data.gateway

import android.Manifest
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.BluetoothStateProvider
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.gateway.BeaconBroadcaster
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.altbeacon.beacon.Beacon
import org.altbeacon.beacon.BeaconParser
import org.altbeacon.beacon.BeaconTransmitter
import kotlin.coroutines.resume

internal class BeaconBroadcasterImpl (
    private val context: Context,
    private val bluetoothStateProvider: BluetoothStateProvider
) : BeaconBroadcaster {
    
    companion object {
        const val TAG = "BeaconBroadcasterTAG"
    }

    private val lock = Any()

    private var beacon: Beacon? = null
    private var transmitter: BeaconTransmitter? = null
    private var lastConfig: BeaconConfig? = null

    @Volatile private var broadcasting = false
    @Volatile private var currentBroadcastInfo: String? = null
    @Volatile private var pauseRequested = false

    override fun currentBroadcastInfo(): String? = currentBroadcastInfo
    override fun isBroadcasting(): Boolean = broadcasting

    override suspend fun start(config: BeaconConfig): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.BLUETOOTH_ADVERTISE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                throw GoPassSdkException.from(error = ErrorCode.BLUETOOTH_PERMISSION_DENIED)
            }
        }

        // 초기 수동 시작 시에만 엄격한 검증 및 Exception 발생
        if (!bluetoothStateProvider.checkBluetoothEnabled()) {
            throw GoPassSdkException.from(error = ErrorCode.BLUETOOTH_DISABLED)
        }
        if (!bluetoothStateProvider.isBleAdvertisingSupported()) {
            throw GoPassSdkException.from(error = ErrorCode.BLUETOOTH_UNSUPPORTED_DEVICE)
        }

        lastConfig = config
        pauseRequested = false
        return startInternal(config)
    }

    private suspend fun startInternal(config: BeaconConfig): Boolean {
        val newInfo = "${config.uuid}:${config.major}:${config.minor}"
        var needStopPrev = false

        synchronized(lock) {
            if (broadcasting && currentBroadcastInfo == newInfo) return true

            if (broadcasting && currentBroadcastInfo != null && currentBroadcastInfo != newInfo) {
                needStopPrev = true
                broadcasting = false
                currentBroadcastInfo = null
            }
        }

        if (needStopPrev) stopInternal(clearConfig = false)

        val builtBeacon = Beacon.Builder()
            .setId1(config.uuid)
            .setId2(config.major.toString())
            .setId3(config.minor.toString())
            .setManufacturer(0x004C)
            .setTxPower(-75)
            .setDataFields(listOf(5L))
            .setBeaconTypeCode(0x0215)
            .build()

        val builtTx = BeaconTransmitter(
            context,
            BeaconParser().setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24")
        ).apply {
            isConnectable = false
            advertiseMode = AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY
            advertiseTxPowerLevel = AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM
        }

        synchronized(lock) {
            beacon = builtBeacon
            transmitter = builtTx
            currentBroadcastInfo = newInfo
        }

        val result = withTimeoutOrNull(3000L) {
            startAdvertisingSuspend(builtTx, builtBeacon)
        } ?: false

        synchronized(lock) {
            broadcasting = result
            if (!result && !pauseRequested) {
                currentBroadcastInfo = null
                transmitter = null
                beacon = null
            }
        }
        return result
    }

    override fun stop(): Boolean {
        pauseRequested = false
        return stopInternal(clearConfig = true)
    }

    private fun stopInternal(clearConfig: Boolean): Boolean {
        val tx: BeaconTransmitter?
        synchronized(lock) {
            tx = transmitter
            if (!broadcasting && tx == null) return false
            broadcasting = false
            currentBroadcastInfo = null

            if (clearConfig) lastConfig = null
        }

        return try {
            tx?.stopAdvertising()
            true
        } catch (e: Exception) {
            errorLog(TAG, "stop failed: $e")
            false
        } finally {
            synchronized(lock) {
                transmitter = null
                beacon = null
            }
        }
    }

    /**
     * 비콘 송출을 일시정지합니다.
     *
     * resume() 진행 중(광고 시작 대기)에 호출되면 [pauseRequested] 플래그를
     * 마킹하여, 광고 시작 콜백([startAdvertisingSuspend])에서 즉시 중단합니다.
     */
    override fun pause(): Boolean {
        debugLog(TAG, "pause() 호출됨")

        val tx: BeaconTransmitter
        synchronized(lock) {
            tx = transmitter ?: run {
                debugLog(TAG, "pause 무시됨: transmitter가 null입니다.")
                return false
            }
            pauseRequested = true
            if (!broadcasting) {
                // resume 진행 중일 수 있음 — 콜백에서 pauseRequested를 확인하여 처리
                debugLog(TAG, "pause: broadcasting=false 상태에서 pauseRequested 마킹 완료")
                return true
            }
            broadcasting = false
        }

        return try {
            tx.stopAdvertising()
            debugLog(TAG, "✅ 비콘 송출 일시정지(pause) 성공!")
            true
        } catch (e: Exception) {
            errorLog(TAG, "pause failed: $e")
            false
        }
    }

    override suspend fun resume(): Boolean {
        val localTx: BeaconTransmitter?
        val localB: Beacon?

        synchronized(lock) {
            pauseRequested = false
            if (broadcasting) return true
            localTx = transmitter
            localB = beacon
        }

        // transmitter/beacon이 없거나 무효화된 경우 → 전체 재생성
        if (localTx == null || localB == null || currentBroadcastInfo == null) {
            return rebuildAndStart()
        }

        // 남아있는 광고 세션 정리
        try {
            if (localTx.isStarted) localTx.stopAdvertising()
        } catch (_: Exception) { }

        val result = withTimeoutOrNull(3000L) {
            startAdvertisingSuspend(localTx, localB)
        } ?: false

        synchronized(lock) { broadcasting = result }

        if (!result) {
            // pause()가 이미 요청된 상태이므로 재시도(rebuildAndStart)를 생략한다.
            // startAdvertisingSuspend 실패와 pause 요청이 동시에 발생해도,
            // 어차피 재시작할 필요가 없으므로 동작상 문제없다.
            if (pauseRequested) {
                debugLog(TAG, "resume 중 pause 요청으로 중단됨")
                return false
            }
            // 기존 transmitter로 재개 실패 → 전체 재생성
            errorLog(TAG, "resume 실패 → transmitter 재생성 시도")
            return rebuildAndStart()
        }

        return true
    }

    /**
     * 기존 transmitter가 무효화된 경우 (BT 스택 재시작 등)
     * stop → start로 전체 재생성한다.
     */
    private suspend fun rebuildAndStart(): Boolean {
        val config = lastConfig ?: return false
        stopInternal(clearConfig = false)
        return startInternal(config)
    }

    private suspend fun startAdvertisingSuspend(
        tx: BeaconTransmitter,
        b: Beacon
    ): Boolean = suspendCancellableCoroutine { cont ->
        val cb = object : AdvertiseCallback() {
            override fun onStartFailure(errorCode: Int) {
                synchronized(lock) { broadcasting = false }
                if (!cont.isCompleted) {
                    errorLog(TAG, "onStartFailure: 비콘 송출 실패")
                    cont.resume(false)
                }
            }

            override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
                val shouldAbort: Boolean
                synchronized(lock) {
                    shouldAbort = pauseRequested
                    broadcasting = !shouldAbort
                }
                if (!cont.isCompleted) {
                    if (shouldAbort) {
                        debugLog(TAG, "onStartSuccess: pause 요청 감지 → 송출 즉시 중단")
                    } else {
                        debugLog(TAG, "onStartSuccess: 비콘 송출 성공")
                    }
                    cont.resume(!shouldAbort)
                }
                if (shouldAbort) {
                    try { tx.stopAdvertising() } catch (_: Exception) {}
                }
            }
        }

        try {
            tx.startAdvertising(b, cb)
        } catch (t: Throwable) {
            errorLog(TAG, "startAdvertising threw: ${t.javaClass.simpleName} / ${t.message}")
            synchronized(lock) { broadcasting = false }
            if (!cont.isCompleted) cont.resume(false)
            return@suspendCancellableCoroutine
        }

        cont.invokeOnCancellation {
            // 취소되면 광고 정리
            try {
                tx.stopAdvertising()
            } catch (_: Exception) {
            }
            synchronized(lock) { broadcasting = false }
        }
    }
}
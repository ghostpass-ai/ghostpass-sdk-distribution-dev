package com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain

import kotlinx.coroutines.flow.StateFlow

interface BluetoothStateProvider {
    val isEnabled: StateFlow<Boolean>
    fun isBleAdvertisingSupported(): Boolean
    fun checkBluetoothEnabled(): Boolean
    fun startMonitoring()
    fun stopMonitoring()
}
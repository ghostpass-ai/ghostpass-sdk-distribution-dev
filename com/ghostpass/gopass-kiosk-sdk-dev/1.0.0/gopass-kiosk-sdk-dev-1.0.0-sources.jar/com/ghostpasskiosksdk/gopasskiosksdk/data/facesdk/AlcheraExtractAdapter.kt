package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk

import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper.AlcheraDetectedFace
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper.AlcheraImageFrame
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine.FaceEngineTypes
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceExtractEngine

internal class AlcheraExtractAdapter (
    private val sdkManager: AlcheraSdkManager
) : FaceExtractEngine {
    override fun extractLandmarkVector(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FloatArray {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        val vector = sdkManager.featureExtension.ExtractFeature(nativeImage, nativeFace).feature_vector
        return vector
    }
}
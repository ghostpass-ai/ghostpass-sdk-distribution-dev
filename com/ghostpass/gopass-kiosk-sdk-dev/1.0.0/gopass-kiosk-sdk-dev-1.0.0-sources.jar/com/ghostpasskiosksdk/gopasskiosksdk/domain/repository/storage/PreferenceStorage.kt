package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.external.KioskId

internal interface PreferenceStorage {
    fun saveApiKey(apiKey: String)
    fun getApiKey(): String?
    fun saveKioskId(kioskId: String)
    fun getKioskId(): String?
    fun saveBeaconConfig(beaconConfig: BeaconConfig)
    fun getBeaconConfig(): BeaconConfig?
    fun clearAll()
}
package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine.FaceEngineTypes

internal interface FaceExtractEngine {
    fun extractLandmarkVector(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FloatArray
}
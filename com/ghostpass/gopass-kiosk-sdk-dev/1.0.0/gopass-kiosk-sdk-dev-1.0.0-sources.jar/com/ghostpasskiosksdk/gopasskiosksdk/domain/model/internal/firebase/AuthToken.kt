package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase

internal data class AuthToken(
    val idToken: String
)
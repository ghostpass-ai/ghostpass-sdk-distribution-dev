package com.ghostpasskiosksdk.gopasskiosksdk.internal.mapper

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.GoPassAuthResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode

internal fun mapAuthExceptionToResult(exception: Exception): GoPassAuthResult.ServerAuthFailed {
    val sdkException = exception as? GoPassSdkException
        ?: GoPassSdkException.from(error = ErrorCode.INTERNAL_ERROR)
    val internalError = sdkException.causeCode?.let(InternalErrorCode::fromCode)
    val mappedErrorCode = resolveAuthErrorCode(sdkException, internalError)

    return GoPassAuthResult.ServerAuthFailed(
        message = sdkException.message.ifBlank {
            mappedErrorCode.message ?: ErrorCode.AUTH_ERROR.message!!
        },
        errorCode = mappedErrorCode
    )
}

private fun resolveAuthErrorCode(
    sdkException: GoPassSdkException,
    internalError: InternalErrorCode?
): ErrorCode {
    ErrorCode.entries.firstOrNull { it.externalCode == sdkException.code }?.let { externalError ->
        return when (externalError) {
            ErrorCode.NETWORK_ERROR,
            ErrorCode.SERVER_ERROR,
            ErrorCode.INVALID_API_KEY,
            ErrorCode.INTERNAL_ERROR,
            ErrorCode.AUTH_TIMEOUT,
            ErrorCode.AUTH_REJECTED,
            ErrorCode.AUTH_ERROR,
            ErrorCode.PHONE_AUTH_LANDMARK_EXPIRED,
            ErrorCode.UNKNOWN -> externalError

            else -> ErrorCode.AUTH_ERROR
        }
    }

    return when (internalError) {
        InternalErrorCode.SSE_NETWORK_TIMEOUT -> ErrorCode.NETWORK_ERROR
        InternalErrorCode.CHANNEL_UPDATE_UNAUTHORIZED,
        InternalErrorCode.CHANNEL_UPDATE_FORBIDDEN,
        InternalErrorCode.CHANNEL_UPDATE_SERVER_ERROR -> ErrorCode.SERVER_ERROR
        InternalErrorCode.INVALID_FORM,
        InternalErrorCode.SSE_INVALID_FORM,
        InternalErrorCode.SSE_AUTH_TOKEN_INVALID,
        InternalErrorCode.SSE_STREAM_UNKNOWN_ERROR -> ErrorCode.INTERNAL_ERROR
        else -> ErrorCode.AUTH_ERROR
    }
}

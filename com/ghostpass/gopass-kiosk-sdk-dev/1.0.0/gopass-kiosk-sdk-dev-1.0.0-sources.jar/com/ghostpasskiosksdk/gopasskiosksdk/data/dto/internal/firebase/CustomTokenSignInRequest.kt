package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase

import kotlinx.serialization.Serializable

@Serializable
internal data class CustomTokenSignInRequest(
    val token: String,
    val returnSecureToken: Boolean = true
)

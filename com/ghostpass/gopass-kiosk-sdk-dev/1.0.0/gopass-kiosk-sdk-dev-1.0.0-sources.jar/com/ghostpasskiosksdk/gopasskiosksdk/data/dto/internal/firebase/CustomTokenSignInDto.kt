package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase

import kotlinx.serialization.Serializable

@Serializable
internal data class CustomTokenSignInDto(
    val idToken: String,
    val refreshToken: String,
    val expiresIn: String,
    val isNewUser: Boolean = false
)

package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import android.content.Context
import android.util.Base64
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager.Companion.HMAC_ALIAS
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager.Companion.TRANSPORT_ALIAS
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.external.KioskId
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionData
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionRequest
import com.ghostpasskiosksdk.gopasskiosksdk.domain.gateway.BeaconBroadcaster
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.getOrThrow
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceEngineManager
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.AuthRepository
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.PreferenceStorage
import com.ghostpasskiosksdk.gopasskiosksdk.domain.validation.validateInitializeArgs
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.useAndWipe
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.wipe
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.StandardIntegrityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException
import javax.crypto.spec.SecretKeySpec

internal class InfrastructureManager(
    private val context: Context,
    private val keyManager: KeyManager,
    private val authRepository: AuthRepository,
    private val cryptoEngine: CryptoEngine,
    private val beaconBroadcaster: BeaconBroadcaster,
    private val preferenceStorage: PreferenceStorage,
    private val faceEngineManager: FaceEngineManager,
    private val authOrchestrator: AuthOrchestrator,
    private val systemStateMonitor: SystemStateMonitor,
    private val screenStateMonitor: ScreenStateMonitor
) {
    companion object {
        const val TAG = "InfrastructureManagerTAG"
        const val PLATFORM = "KIOSK_ANDROID"
        const val AES_INFO = "ghostpass-ecdh-kiosk-v1"
        const val HMAC_INFO = "ghostpass-hmac-key-v1"
        const val TRANSPORT_INFO = "ghostpass-transport-key-v1"
    }

    private val initMutex = Mutex()

    @Volatile
    private var initDeferred: Deferred<Boolean>? = null

    @Volatile
    private var lifecycleScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun initialize(
        apiKey: String,
        kioskId: KioskId,
        beaconConfig: BeaconConfig
    ): Boolean {
        initDeferred?.let { return it.await() }

        val deferred = initMutex.withLock {
            initDeferred?.let { return@withLock it }

            val newDeferred = lifecycleScope.async {
                val isInitialized = performInitialize(apiKey, kioskId, beaconConfig)
                debugLog(TAG, "enroll 및 초기화 성공")
                if (isInitialized) {
                    startSystemStateMonitoring()
                }
                isInitialized
            }
            initDeferred = newDeferred
            newDeferred
        }

        return try {
            deferred.await().also { success ->
                if (!success) throw GoPassSdkException.from(ErrorCode.INIT_FAILED)
            }
        } catch (t: Throwable) {
            initMutex.withLock {
                if (initDeferred === deferred) {
                    initDeferred = null
                }
            }
            throw t
        }
    }

    private suspend fun performInitialize(
        apiKey: String,
        kioskId: KioskId,
        beaconConfig: BeaconConfig
    ): Boolean {
        debugLog(TAG, "initialize: 호출")
        validateInitializeArgs(apiKey, kioskId, beaconConfig)
        // 1. hmac 키가 있는지 조회
        val hasSecretKey = keyManager.hasSecretKey(HMAC_ALIAS)
        debugLog(TAG, "hasSecretKey : $hasSecretKey")
        val normalizedId = "${kioskId.svc}:${kioskId.region}:${kioskId.branch}:${kioskId.seq}"
        debugLog(TAG, "KioskId : $normalizedId")

        val savedKioskId = preferenceStorage.getKioskId()
        debugLog(TAG, "SavedKioskId : $savedKioskId")
        val needsProvision = !hasSecretKey || savedKioskId != normalizedId
        debugLog(TAG, "Need Provision? $needsProvision")

        // 1-a. 없으면 provision 시작
        if (needsProvision) {
            runCatching {
                keyManager.deleteKey(HMAC_ALIAS)
                keyManager.deleteKey(TRANSPORT_ALIAS)
            }
            saveInitializeArgs(apiKey, normalizedId, beaconConfig)
            provision(apiKey, normalizedId, beaconConfig)
        }

        // 2. faceSdk 초기화
        faceEngineManager.initialize()

        // 3. 비콘 송출 시작 (동일 config 재요청은 BeaconBroadcaster 내부에서 idempotent 처리)
        debugLog(TAG, "송출되는 비콘 정보 : ${beaconConfig.uuid}:${beaconConfig.major}:${beaconConfig.minor}")
        val ok = beaconBroadcaster.start(beaconConfig)
        if (!ok) {
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                customMessage = "비콘 송출 시작에 실패하였습니다."
            )
        }

        return true
    }

    private fun startSystemStateMonitoring() {
        systemStateMonitor.startMonitoring()
        screenStateMonitor.startMonitoring { action ->
            if (systemStateMonitor.isNetworkAvailable.value) {
                authOrchestrator.forceReconnect("screen wake: $action")
            }
        }

        lifecycleScope.launch {
            combine(
                systemStateMonitor.isBluetoothEnabled,
                systemStateMonitor.isNetworkAvailable
            ) { bt, network -> Pair(bt, network) }
                .distinctUntilChanged()
                .collect { (btEnabled, networkAvailable) ->
                    warnLog(TAG, "시스템 상태 변경: BT=$btEnabled, Network=$networkAvailable")

                    if (btEnabled && networkAvailable) {
                        beaconBroadcaster.resume()
                    } else {
                        beaconBroadcaster.pause()
                    }

                    if (networkAvailable) {
                        authOrchestrator.startSessionCollection()
                    } else {
                        authOrchestrator.stopSessionCollection()
                    }
                }
        }
    }

    suspend fun reset(): Boolean {
        warnLog(TAG, "SDK reset 시작")

        var teardownException: Throwable? = null

        initMutex.withLock {
            val oldJob = lifecycleScope.coroutineContext[Job]

            lifecycleScope.cancel()

            runCatching { screenStateMonitor.stopMonitoring() }
                .onFailure { e -> if (teardownException == null) teardownException = e }

            runCatching { systemStateMonitor.stopMonitoring() }
                .onFailure { e -> if (teardownException == null) teardownException = e }

            try {
                authOrchestrator.destroy()
            } catch (e: Throwable) {
                if (teardownException == null) teardownException = e
            }

            runCatching { beaconBroadcaster.stop() }
                .onFailure { e -> if (teardownException == null) teardownException = e }

            if (oldJob != null) {
                val isCompleted = withTimeoutOrNull(2000L) {
                    oldJob.join()
                    true
                }

                if (isCompleted == null) {
                    val errMsg =
                        "FATAL: 일부 코루틴이 정상적으로 종료되지 않았습니다. (Memory Leak 및 Zombie 코루틴 위험)"
                    errorLog(TAG, "⚠️ $errMsg")
                    if (teardownException == null) {
                        teardownException = IllegalStateException(errMsg)
                    }
                }
            }

            initDeferred = null
            lifecycleScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        }

        if (teardownException != null) {
            errorLog(TAG, "SDK 자원이 불완전하게 해제되었습니다. 원인: ${teardownException?.message}")
            throw GoPassSdkException.from(error = ErrorCode.RESET_FAILED)
        }

        warnLog(TAG, "SDK reset 완료 — initialize() 재호출 가능")
        return true
    }

    private fun saveInitializeArgs(apiKey: String, kioskId: String, beaconConfig: BeaconConfig) {
        preferenceStorage.saveApiKey(apiKey)
        preferenceStorage.saveKioskId(kioskId)
        preferenceStorage.saveBeaconConfig(beaconConfig)
    }

    private suspend fun provision(apiKey: String, kioskId: String, beaconConfig: BeaconConfig) {
        // 1. ECDH key 합의
        val publicKey = keyManager.generateEcdhKeyPair()

        // 2. integrity 도출을 위한 nonce 획득
        val requestHashBytes = fetchIntegrityChallenge()

        // 3. integrity token 획득
        val integrityToken = fetchIntegrityToken(requestHashBytes)

        val request = ProvisionRequest(
            challenge = requestHashBytes,
            kioskId = kioskId,
            platform = PLATFORM,
            beaconMajor = beaconConfig.major,
            beaconMinor = beaconConfig.minor,
            attestation = integrityToken,
            clientPublicKey = publicKey
        )

        val data = authRepository.provision(request = request).getOrThrow()

        processProvisionResult(apiKey, data)
    }

    private suspend fun fetchIntegrityChallenge(): String {
        val result = authRepository.challenge()
        debugLog(TAG, "fetchIntegrityChallenge result : $result")

        return result.getOrThrow().challenge
    }

    // Google Play Integrity Token 획득
    private suspend fun fetchIntegrityToken(hash: String): String {
        val standardIntegrityManager = IntegrityManagerFactory.createStandard(context)

        val tokenProvider = try {
            standardIntegrityManager.prepareIntegrityToken(
                StandardIntegrityManager.PrepareIntegrityTokenRequest.builder()
                    .setCloudProjectNumber(BuildConfig.CLOUD_PROJECT_NUMBER)
                    .build()
            ).await()
        } catch (e: Exception) {
            errorLog(TAG, "Integrity Prepare 실패: $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.INTEGRITY_PROVIDER_FAILED
            )
        }

        val tokenResponse = try {
            tokenProvider.request(
                StandardIntegrityManager.StandardIntegrityTokenRequest.builder()
                    .setRequestHash(hash)
                    .build()
            ).await()
        } catch (e: IOException) {
            throw GoPassSdkException.from(error = ErrorCode.NETWORK_ERROR)
        } catch (e: Exception) {
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.INTEGRITY_TOKEN_FAILED
            )
        }

        debugLog(TAG, "✅ Integrity attestation token received successfully.")
        return tokenResponse.token()
    }

    private fun processProvisionResult(
        apiKey: String,
        provisionData: ProvisionData
    ) {
        try {
            val serverPubKey = try {
                cryptoEngine.decodeECPublicKey(provisionData.serverPublicKey)
            } catch (e: Exception) {
                errorLog(TAG, "서버 공개키 디코딩 실패 : $e")
                throw GoPassSdkException.from(
                    error = ErrorCode.INIT_FAILED,
                    cause = InternalErrorCode.PUBLIC_KEY_DECODE_FAILED
                )
            }

            val kioskIdBytes = provisionData.kioskId.toByteArray()

            // useAndWipe 연쇄 스코프로 wipe 보장 + 단계별 구체적 에러코드 유지
            // 1. sharedKey 생성
            cryptoEngine.deriveSharedKey(
                key = keyManager.getPrivateKey(),
                serverPublicKey = serverPubKey
            ).useAndWipe { sharedKey ->

                // 2. app secret 복호화를 위한 aesKey 생성
                val aesKey = try {
                    cryptoEngine.hkdf(
                        ikm = sharedKey,
                        salt = kioskIdBytes,
                        info = AES_INFO
                    )
                } catch (e: Exception) {
                    errorLog(TAG, "AES 키 파생 실패 : $e")
                    throw GoPassSdkException.from(
                        error = ErrorCode.INIT_FAILED,
                        cause = InternalErrorCode.AES_KEY_DERIVATION_FAILED
                    )
                }

                aesKey.useAndWipe { aes ->
                    val aadString = "${apiKey.trim()}:${provisionData.kioskId.trim()}"
                    val aadBytes = aadString.toByteArray(Charsets.UTF_8)

                    // 3. KioskSecret 복호화
                    val decryptedBytes = try {
                        cryptoEngine.decryptData(
                            key = SecretKeySpec(aes, "AES"),
                            encryptedBase64 = provisionData.encryptedKioskSecret,
                            aad = aadBytes
                        )
                    } catch (e: Exception) {
                        errorLog(TAG, "KioskSecret 복호화 실패 : $e")
                        throw GoPassSdkException.from(
                            error = ErrorCode.INIT_FAILED,
                            cause = InternalErrorCode.KIOSK_SECRET_DECRYPTION_FAILED
                        )
                    }

                    decryptedBytes.useAndWipe { decrypted ->
                        // ByteArray 반환 버전을 사용하여 immutable String 힙 잔류 방지
                        Base64.encode(decrypted, Base64.NO_WRAP).useAndWipe { kioskSecret ->

                            // 4. hmac_key 파생 및 즉시 StrongBox 주입
                            val hmacKey = try {
                                cryptoEngine.hkdf(
                                    ikm = kioskSecret,
                                    salt = kioskIdBytes,
                                    info = HMAC_INFO
                                )
                            } catch (e: Exception) {
                                errorLog(TAG, "HMAC 키 파생 실패 : $e")
                                throw GoPassSdkException.from(
                                    error = ErrorCode.INIT_FAILED,
                                    cause = InternalErrorCode.HMAC_KEY_DERIVATION_FAILED
                                )
                            }

                            hmacKey.useAndWipe { hmac ->
                                keyManager.importSecretKey(HMAC_ALIAS, hmac)
                            }

                            // 5. transport_key 파생 및 즉시 StrongBox 주입
                            val transportKey = try {
                                cryptoEngine.hkdf(
                                    ikm = kioskSecret,
                                    salt = kioskIdBytes,
                                    info = TRANSPORT_INFO
                                )
                            } catch (e: Exception) {
                                errorLog(TAG, "Transport 키 파생 실패 : $e")
                                throw GoPassSdkException.from(
                                    error = ErrorCode.INIT_FAILED,
                                    cause = InternalErrorCode.TRANSPORT_KEY_DERIVATION_FAILED
                                )
                            }

                            transportKey.useAndWipe { transport ->
                                keyManager.importSecretKey(TRANSPORT_ALIAS, transport)
                            }
                        }
                    }
                }
            }
        } catch (e: GoPassSdkException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "processProvisionResult 예외 발생 : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.UNKNOWN
            )
        }
    }
}

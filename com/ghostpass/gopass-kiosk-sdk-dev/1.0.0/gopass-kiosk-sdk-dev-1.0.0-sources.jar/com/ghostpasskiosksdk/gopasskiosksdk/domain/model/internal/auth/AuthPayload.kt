package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth

internal sealed class AuthPayload {
    data object Success : AuthPayload()
    data object Failed : AuthPayload()
}
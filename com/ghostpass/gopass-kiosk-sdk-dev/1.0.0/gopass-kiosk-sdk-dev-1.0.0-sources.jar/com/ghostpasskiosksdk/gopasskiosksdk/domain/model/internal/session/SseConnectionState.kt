package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException

internal sealed class SseConnectionState {
    data object Disconnected : SseConnectionState()
    data object Connecting : SseConnectionState()
    data object Connected : SseConnectionState()
    data class Error(val exception: GoPassSdkException) : SseConnectionState()
}
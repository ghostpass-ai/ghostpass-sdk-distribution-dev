package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.external

import kotlinx.serialization.Serializable

@Serializable
data class KioskId(
    val svc : String,
    val region : String,
    val branch : String,
    val seq : String
)
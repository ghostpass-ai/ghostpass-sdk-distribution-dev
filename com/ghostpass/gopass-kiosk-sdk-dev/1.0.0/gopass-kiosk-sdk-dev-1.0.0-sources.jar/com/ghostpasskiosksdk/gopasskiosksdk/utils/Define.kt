package com.ghostpasskiosksdk.gopasskiosksdk.utils

import com.alcherainc.facesdk.type.Box
import com.alcherainc.facesdk.type.Face
import com.alcherainc.facesdk.type.InputImage
import com.alcherainc.facesdk.type.Pose

import kotlin.math.abs

internal class Define {
    companion object {
        const val TAG = "Define TAG"
        const val VALID_FACE_DETECT_CONFIDENCE_VALUE = 0.9f

        const val LIVENESS_QUALITY = 63.96f
        const val VALID_FACE_DETECT_LIVENESS_VALUE = 0.3f

        const val CAMERA_PREVIEW_WIDTH = 960
        const val CAMERA_PREVIEW_HEIGHT = 1280

        // 기존 데이터
//        private val YAW_DEGREE = 15.0f
//        private val PITCH_DEGREE = 20.0f
//        private val ROLL_DEGREE = 15.0f

        // 좀 더 정규화된 규정
//        private val YAW_DEGREE = 1.0f
//        private val PITCH_DEGREE = 7.5f
//        private val ROLL_DEGREE = 5.0f

        private val YAW_DEGREE = 2.0f
        private val PITCH_DEGREE = 15.0f
        private val ROLL_DEGREE = 5.0f

//        var VALID_FACE_SIZE_MIN_RATE_ORIENTATION_PORTRAIT = 2.5f  // must be set zero for remove limit
//        var VALID_FACE_SIZE_MAX_RATE_ORIENTATION_PORTRAIT = 1.4f  //defalt : 1.7f

        var VALID_FACE_SIZE_MIN_RATE_ORIENTATION_PORTRAIT = 3f  // must be set zero for remove limit
        var VALID_FACE_SIZE_MAX_RATE_ORIENTATION_PORTRAIT = 2.2f  //defalt : 1.7f

        private val VALID_FACE_WIDTH_POSITION_RATE = 9f
        private val VALID_FACE_HEIGHT_POSITION_RATE = 9f

        data class PoseValidation(
            val rollOk: Boolean,
            val pitchOk: Boolean,
            val yawOk: Boolean,
        ) {
            val isOk get() = rollOk && pitchOk && yawOk
        }

        fun isValidPose(pose: Pose): PoseValidation {
            debugLog(TAG,"roll: ${pose.roll_degree}, pitch: ${pose.pitch_degree}, yaw : ${pose.yaw_degree}")
            val roll = pose.roll_degree
            val pitch = pose.pitch_degree
            val yaw = pose.yaw_degree

            val rollOk = abs(roll) < ROLL_DEGREE
            val pitchOk = abs(pitch) < PITCH_DEGREE
            val yawOk = abs(yaw) < YAW_DEGREE

            // 규칙: 턱 올림 -> pitch 음수, 턱 내림 -> pitch 양수
            // pitch가 기준을 넘어서 실패한 경우, "교정" 안내는 반대로:
            //  pitch 양수(턱 내림 상태) -> 턱을 들어야 함
            //  pitch 음수(턱 올림 상태) -> 턱을 내려야 함
//            val pitchHint = if (!pitchOk) {
//                if (pitch > 0f) PosePitchHint.CHIN_UP else PosePitchHint.CHIN_DOWN
//            } else null

            return PoseValidation(rollOk, pitchOk, yawOk)
        }

        fun isValidPosition(image: InputImage, face: Face): Boolean {
            val box: Box = face.box
            val imageW = image.width
            val imageH = image.height
            val imageCenterX = imageW / 2
            val imageCenterY = imageH / 2
            val faceCenterX = box.x + box.width / 2
            val faceCenterY = box.y + box.height / 2
            val centerDiffX = abs(imageCenterX - faceCenterX)
            val centerDiffY = abs(imageCenterY - faceCenterY)

            debugLog(TAG, "Position: centerDiffX = $centerDiffX, centerDiffY = $centerDiffY")

            val widthRatio: Float = imageW / VALID_FACE_WIDTH_POSITION_RATE
            val heightRatio: Float = imageH / VALID_FACE_HEIGHT_POSITION_RATE

            debugLog(TAG, "Position: centerDiffX / widthRatio = ${centerDiffX/widthRatio}")
            debugLog(TAG, "Position: centerDiffY / heightRatio = ${centerDiffY/heightRatio}")
            return centerDiffX < widthRatio && centerDiffY < heightRatio
        }

        fun isValidSizeMin(image: InputImage, face: Face): Boolean {
            debugLog(TAG, "MIN: image.width = ${image.width}, face.box = ${face.box.width}")
            val imageW = image.width
            return imageW / VALID_FACE_SIZE_MIN_RATE_ORIENTATION_PORTRAIT < face.box.width
        }

        fun isValidSizeMax(image: InputImage, face: Face): Boolean {
            debugLog(TAG, "MAX: image.width = ${image.width}, face.box = ${face.box.width}")
            val imageW = image.width
            return face.box.width < imageW / VALID_FACE_SIZE_MAX_RATE_ORIENTATION_PORTRAIT
        }
    }
}
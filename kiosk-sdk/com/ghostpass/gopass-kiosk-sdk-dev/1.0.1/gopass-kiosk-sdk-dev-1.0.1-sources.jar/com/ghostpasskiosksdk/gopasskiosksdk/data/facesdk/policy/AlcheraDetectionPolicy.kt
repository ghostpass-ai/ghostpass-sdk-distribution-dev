package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.policy

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.FailReason
import kotlin.math.abs

internal object AlcheraDetectionPolicy {
    private const val YAW_DEGREE = 2.0f
    private const val PITCH_DEGREE = 15.0f
    private const val ROLL_DEGREE = 5.0f

    private const val VALID_FACE_WIDTH_POSITION_RATE = 9f
    private const val VALID_FACE_HEIGHT_POSITION_RATE = 9f

    private const val VALID_FACE_SIZE_MIN_RATE_PORTRAIT = 3f
    private const val VALID_FACE_SIZE_MAX_RATE_PORTRAIT = 2.2f

    private const val VALID_FACE_DETECT_CONFIDENCE_VALUE = 0.9f

    fun poseFailures(
        rollDegree: Float,
        pitchDegree: Float,
        yawDegree: Float,
    ): List<FailReason> = buildList {
        if (abs(rollDegree) >= ROLL_DEGREE) add(FailReason.INVALID_POSE_ROLL)
        if (abs(pitchDegree) >= PITCH_DEGREE) add(FailReason.INVALID_POSE_PITCH)
        if (abs(yawDegree) >= YAW_DEGREE) add(FailReason.INVALID_POSE_YAW)
    }

    fun isCentered(
        imageWidth: Int,
        imageHeight: Int,
        faceX: Float,
        faceY: Float,
        faceWidth: Float,
        faceHeight: Float,
    ): Boolean {
        val faceCenterX = faceX + faceWidth / 2
        val faceCenterY = faceY + faceHeight / 2
        val imageCenterX = imageWidth / 2f
        val imageCenterY = imageHeight / 2f
        val diffX = abs(imageCenterX - faceCenterX)
        val diffY = abs(imageCenterY - faceCenterY)
        val limitX = imageWidth / VALID_FACE_WIDTH_POSITION_RATE
        val limitY = imageHeight / VALID_FACE_HEIGHT_POSITION_RATE
        return diffX < limitX && diffY < limitY
    }

    fun isValidMinFaceSize(imageWidth: Int, faceWidth: Float): Boolean =
        imageWidth / VALID_FACE_SIZE_MIN_RATE_PORTRAIT < faceWidth

    fun isValidMaxFaceSize(imageWidth: Int, faceWidth: Float): Boolean =
        faceWidth < imageWidth / VALID_FACE_SIZE_MAX_RATE_PORTRAIT

    fun isValidLandmarkConfidence(confidence: Float): Boolean =
        confidence >= VALID_FACE_DETECT_CONFIDENCE_VALUE
}

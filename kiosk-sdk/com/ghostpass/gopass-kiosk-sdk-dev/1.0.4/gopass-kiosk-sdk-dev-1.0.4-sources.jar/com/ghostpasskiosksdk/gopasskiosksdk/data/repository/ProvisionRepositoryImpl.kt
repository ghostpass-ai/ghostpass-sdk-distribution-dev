package com.ghostpasskiosksdk.gopasskiosksdk.data.repository

import android.content.Context
import android.util.Base64
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager.Companion.HMAC_ALIAS
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager.Companion.TRANSPORT_ALIAS
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionData
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.getOrThrow
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.AuthRepository
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.PreferenceStorage
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.ProvisionRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.useAndWipe
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.StandardIntegrityManager
import kotlinx.coroutines.tasks.await
import java.io.IOException
import javax.crypto.spec.SecretKeySpec

internal class ProvisionRepositoryImpl(
    private val context: Context,
    private val keyManager: KeyManager,
    private val authRepository: AuthRepository,
    private val cryptoEngine: CryptoEngine,
    private val preferenceStorage: PreferenceStorage
) : ProvisionRepository {

    companion object {
        private val TAG = "ProvisionRepository ${BuildConfig.SIGNATURE}"
        private const val PLATFORM = "KIOSK_ANDROID"
        private const val AES_INFO = "ghostpass-ecdh-kiosk-v1"
        private const val HMAC_INFO = "ghostpass-hmac-key-v1"
        private const val TRANSPORT_INFO = "ghostpass-transport-key-v1"
    }

    override suspend fun provisionIfNeeded(
        apiKey: String,
        kioskId: String,
        beaconConfig: BeaconConfig
    ) {
        val hasSecretKey = keyManager.hasSecretKey(HMAC_ALIAS)
        debugLog(TAG, "hasSecretKey : $hasSecretKey")

        val savedKioskId = preferenceStorage.getKioskId()
        debugLog(TAG, "SavedKioskId : $savedKioskId")

        val needsProvision = !hasSecretKey || savedKioskId != kioskId
        debugLog(TAG, "Need Provision? $needsProvision")

        if (needsProvision) {
            runCatching {
                keyManager.deleteKey(HMAC_ALIAS)
                keyManager.deleteKey(TRANSPORT_ALIAS)
            }
            saveInitializeArgs(apiKey, kioskId, beaconConfig)
            provision(apiKey, kioskId, beaconConfig)
        }
    }

    private fun saveInitializeArgs(apiKey: String, kioskId: String, beaconConfig: BeaconConfig) {
        preferenceStorage.saveApiKey(apiKey)
        preferenceStorage.saveKioskId(kioskId)
        preferenceStorage.saveBeaconConfig(beaconConfig)
    }

    private suspend fun provision(apiKey: String, kioskId: String, beaconConfig: BeaconConfig) {
        val publicKey = keyManager.generateEcdhKeyPair()

        val requestHashBytes = fetchIntegrityChallenge()

        val integrityToken = fetchIntegrityToken(requestHashBytes)

        val request = ProvisionRequest(
            challenge = requestHashBytes,
            kioskId = kioskId,
            platform = PLATFORM,
            beaconMajor = beaconConfig.major,
            beaconMinor = beaconConfig.minor,
            attestation = integrityToken,
            clientPublicKey = publicKey
        )

        val data = authRepository.provision(request = request).getOrThrow()

        processProvisionResult(apiKey, data)
    }

    private suspend fun fetchIntegrityChallenge(): String {
        val result = authRepository.challenge()
        debugLog(TAG, "fetchIntegrityChallenge result : $result")

        return result.getOrThrow().challenge
    }

    private suspend fun fetchIntegrityToken(hash: String): String {
        val standardIntegrityManager = IntegrityManagerFactory.createStandard(context)

        val tokenProvider = try {
            standardIntegrityManager.prepareIntegrityToken(
                StandardIntegrityManager.PrepareIntegrityTokenRequest.builder()
                    .setCloudProjectNumber(BuildConfig.CLOUD_PROJECT_NUMBER)
                    .build()
            ).await()
        } catch (e: Exception) {
            errorLog(TAG, "Integrity Prepare 실패: $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.INTEGRITY_PROVIDER_FAILED
            )
        }

        val tokenResponse = try {
            tokenProvider.request(
                StandardIntegrityManager.StandardIntegrityTokenRequest.builder()
                    .setRequestHash(hash)
                    .build()
            ).await()
        } catch (e: IOException) {
            throw GoPassSdkException.from(error = ErrorCode.NETWORK_ERROR)
        } catch (e: Exception) {
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.INTEGRITY_TOKEN_FAILED
            )
        }

        debugLog(TAG, "Integrity attestation token received successfully.")
        return tokenResponse.token()
    }

    private fun processProvisionResult(
        apiKey: String,
        provisionData: ProvisionData
    ) {
        try {
            val serverPubKey = try {
                cryptoEngine.decodeECPublicKey(provisionData.serverPublicKey)
            } catch (e: Exception) {
                errorLog(TAG, "서버 공개키 디코딩 실패 : $e")
                throw GoPassSdkException.from(
                    error = ErrorCode.INIT_FAILED,
                    cause = InternalErrorCode.PUBLIC_KEY_DECODE_FAILED
                )
            }

            val kioskIdBytes = provisionData.kioskId.toByteArray()

            cryptoEngine.deriveSharedKey(
                key = keyManager.getPrivateKey(),
                serverPublicKey = serverPubKey
            ).useAndWipe { sharedKey ->

                val aesKey = try {
                    cryptoEngine.hkdf(
                        ikm = sharedKey,
                        salt = kioskIdBytes,
                        info = AES_INFO
                    )
                } catch (e: Exception) {
                    errorLog(TAG, "AES 키 파생 실패 : $e")
                    throw GoPassSdkException.from(
                        error = ErrorCode.INIT_FAILED,
                        cause = InternalErrorCode.AES_KEY_DERIVATION_FAILED
                    )
                }

                aesKey.useAndWipe { aes ->
                    val aadString = "${apiKey.trim()}:${provisionData.kioskId.trim()}"
                    val aadBytes = aadString.toByteArray(Charsets.UTF_8)

                    val decryptedBytes = try {
                        cryptoEngine.decryptData(
                            key = SecretKeySpec(aes, "AES"),
                            encryptedBase64 = provisionData.encryptedKioskSecret,
                            aad = aadBytes
                        )
                    } catch (e: Exception) {
                        errorLog(TAG, "KioskSecret 복호화 실패 : $e")
                        throw GoPassSdkException.from(
                            error = ErrorCode.INIT_FAILED,
                            cause = InternalErrorCode.KIOSK_SECRET_DECRYPTION_FAILED
                        )
                    }

                    decryptedBytes.useAndWipe { decrypted ->
                        Base64.encode(decrypted, Base64.NO_WRAP).useAndWipe { kioskSecret ->

                            val hmacKey = try {
                                cryptoEngine.hkdf(
                                    ikm = kioskSecret,
                                    salt = kioskIdBytes,
                                    info = HMAC_INFO
                                )
                            } catch (e: Exception) {
                                errorLog(TAG, "HMAC 키 파생 실패 : $e")
                                throw GoPassSdkException.from(
                                    error = ErrorCode.INIT_FAILED,
                                    cause = InternalErrorCode.HMAC_KEY_DERIVATION_FAILED
                                )
                            }

                            hmacKey.useAndWipe { hmac ->
                                keyManager.importSecretKey(HMAC_ALIAS, hmac)
                            }

                            val transportKey = try {
                                cryptoEngine.hkdf(
                                    ikm = kioskSecret,
                                    salt = kioskIdBytes,
                                    info = TRANSPORT_INFO
                                )
                            } catch (e: Exception) {
                                errorLog(TAG, "Transport 키 파생 실패 : $e")
                                throw GoPassSdkException.from(
                                    error = ErrorCode.INIT_FAILED,
                                    cause = InternalErrorCode.TRANSPORT_KEY_DERIVATION_FAILED
                                )
                            }

                            transportKey.useAndWipe { transport ->
                                keyManager.importSecretKey(TRANSPORT_ALIAS, transport)
                            }
                        }
                    }
                }
            }
        } catch (e: GoPassSdkException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "processProvisionResult 예외 발생 : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.UNKNOWN
            )
        }
    }
}

package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth

internal sealed class AuthPayload {
    data class Success(val deviceId: String) : AuthPayload()
    data object Failed : AuthPayload()
}
package com.ghostpasskiosksdk.gopasskiosksdk.data.repository

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.data.api.ProvisionApi
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.challenge.ChallengeData
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.AuthRepository
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.utils.safeApiCall

internal class AuthRepositoryImpl (
    private val enrollmentApi: ProvisionApi
) : AuthRepository {

    companion object {
        val TAG = "AuthRepositoryImpl ${BuildConfig.SIGNATURE}"
    }
    override suspend fun challenge(): ApiResult<ChallengeData> {
        return safeApiCall { enrollmentApi.requestChallenge() }
    }

    override suspend fun provision(request: ProvisionRequest): ApiResult<ProvisionData> {
        return safeApiCall { enrollmentApi.requestProvision(request) }
    }
}
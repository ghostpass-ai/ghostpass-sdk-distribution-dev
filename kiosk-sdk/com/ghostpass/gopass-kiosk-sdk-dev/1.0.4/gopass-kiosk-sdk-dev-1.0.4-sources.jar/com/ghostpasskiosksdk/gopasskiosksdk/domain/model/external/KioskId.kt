package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external

import kotlinx.serialization.Serializable

@Serializable
data class KioskId(
    val svc : String,
    val region : String,
    val branch : String,
    val seq : String
)

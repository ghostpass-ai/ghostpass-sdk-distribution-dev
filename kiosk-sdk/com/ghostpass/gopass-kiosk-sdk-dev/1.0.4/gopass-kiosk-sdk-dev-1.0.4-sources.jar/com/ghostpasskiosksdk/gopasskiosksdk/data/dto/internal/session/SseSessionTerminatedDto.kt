package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session

import kotlinx.serialization.Serializable

@Serializable
internal data class SseSessionTerminatedDto(
    val sessionId: String
)

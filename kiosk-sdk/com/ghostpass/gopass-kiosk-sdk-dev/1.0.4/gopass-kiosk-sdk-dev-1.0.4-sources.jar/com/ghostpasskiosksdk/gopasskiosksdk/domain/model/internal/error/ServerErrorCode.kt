package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode

internal enum class ServerErrorCode(
    val serverCode: String,
    val external: ErrorCode,
    val internal: InternalErrorCode? = null
) {
    // 일반 에러
    KIOSK_ALREADY_ENROLLED("SDK-9200", ErrorCode.KIOSK_ALREADY_ENROLLED),
    KIOSK_NOT_FOUND("SDK-9201", ErrorCode.KIOSK_NOT_FOUND),
    KIOSK_INACTIVE("SDK-9202", ErrorCode.KIOSK_INACTIVE),
    KIOSK_INVALID_ID_FORMAT("SDK-9203", ErrorCode.KIOSK_INVALID_ID_FORMAT),
    KIOSK_DUPLICATED_MAJOR_MINOR("SDK-9205", ErrorCode.KIOSK_DUPLICATED_MAJOR_MINOR),

    // 내부 cause가 필요한 초기화 에러
    INIT_ECDH_FAILED("SDK-9109", ErrorCode.INIT_FAILED, InternalErrorCode.PROVISION_ECDH_FAILED),
    INIT_ATTESTATION_FAILED("SDK-9110", ErrorCode.INIT_FAILED, InternalErrorCode.PROVISION_ATTESTATION_CHALLENGE_INVALID);

    companion object {
        fun fromCode(code: String): ServerErrorCode? = entries.find { it.serverCode == code }
    }
}
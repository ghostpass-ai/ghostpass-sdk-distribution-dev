package com.ghostpasskiosksdk.gopasskiosksdk.domain.validation

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.KioskId
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import java.util.UUID


internal fun validateInitializeArgs(apiKey: String, kioskId: KioskId, beaconConfig: BeaconConfig) {
    fun invalid(msg: String): Nothing =
        throw GoPassSdkException.from(error = ErrorCode.INVALID_ARGUMENT, customMessage = msg)

    if (apiKey.isBlank()) invalid("API 키가 입력되지 않았습니다.")
    if (kioskId.svc.isBlank()) invalid("키오스크 svc가 입력되지 않았습니다.")
    if (kioskId.region.isBlank()) invalid("키오스크 region이 입력되지 않았습니다.")
    if (kioskId.branch.isBlank()) invalid("키오스크 branch가 입력되지 않았습니다.")
    if (kioskId.seq.isBlank()) invalid("키오스크 seq가 입력되지 않았습니다.")

    if (beaconConfig.uuid.isBlank()) invalid("UUID가 입력되지 않았습니다.")

    try {
        UUID.fromString(beaconConfig.uuid)
    } catch (e: IllegalArgumentException) {
        invalid("비콘 UUID 형식이 올바르지 않습니다.")
    }
    if (beaconConfig.major !in 0..65535) invalid("Major 값은 0~65535 사이여야 합니다. (입력값: ${beaconConfig.major})")
    if (beaconConfig.minor !in 0..65535) invalid("Minor 값은 0~65535 사이여야 합니다. (입력값: ${beaconConfig.minor})")
}

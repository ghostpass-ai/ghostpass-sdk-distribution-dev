package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.policy

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.FailReason
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import kotlin.math.abs

internal object AlcheraDetectionPolicy {
    private const val YAW_DEGREE = 30f
    private const val PITCH_DEGREE = 30f
    private const val ROLL_DEGREE = 30f

    private const val VALID_FACE_WIDTH_POSITION_RATE = 5f
    private const val VALID_FACE_HEIGHT_POSITION_RATE = 1f

    private const val VALID_FACE_SIZE_MIN_RATE_PORTRAIT = 4.8f
    private const val VALID_FACE_SIZE_MAX_RATE_PORTRAIT = 2.2f

    private const val VALID_FACE_DETECT_CONFIDENCE_VALUE = 0.9f

    const val TAG = "DetectionPolicy ${BuildConfig.SIGNATURE}"

    fun poseFailures(
        rollDegree: Float,
        pitchDegree: Float,
        yawDegree: Float,
    ): List<FailReason> = buildList {
        infoLog(TAG, "yawDegree = $yawDegree(기준 = $YAW_DEGREE)")
        if (abs(rollDegree) >= ROLL_DEGREE) add(FailReason.INVALID_POSE_ROLL)
        if (abs(pitchDegree) >= PITCH_DEGREE) add(FailReason.INVALID_POSE_PITCH)
        if (abs(yawDegree) >= YAW_DEGREE) add(FailReason.INVALID_POSE_YAW)
    }

    fun isCentered(
        imageWidth: Int,
        imageHeight: Int,
        faceX: Float,
        faceY: Float,
        faceWidth: Float,
        faceHeight: Float,
    ): Boolean {
        infoLog(TAG, "faceX = $faceX, faceY = $faceY, faceWidth = $faceWidth, faceHeight = $faceHeight")
        val faceCenterX = faceX + faceWidth / 2
        val faceCenterY = faceY + faceHeight / 2
        infoLog(TAG, "imageWidth = $imageWidth, imageHeight = $imageHeight")
        val imageCenterX = imageWidth / 2f
        val imageCenterY = imageHeight / 2f
        val diffX = abs(imageCenterX - faceCenterX)
        val diffY = abs(imageCenterY - faceCenterY)
        infoLog(TAG, "diffX = $diffX, diffY = $diffY")
        val limitX = imageWidth / VALID_FACE_WIDTH_POSITION_RATE
        val limitY = imageHeight / VALID_FACE_HEIGHT_POSITION_RATE
        infoLog(TAG, "limitX = $limitX, limitY = $limitY")
        return diffX < limitX && diffY < limitY
    }

    fun isValidMinFaceSize(imageWidth: Int, faceWidth: Float): Boolean {
        infoLog(TAG, "imageWidth = $imageWidth, faceWidth = $faceWidth")
        return imageWidth / VALID_FACE_SIZE_MIN_RATE_PORTRAIT < faceWidth
    }

    fun isValidMaxFaceSize(imageWidth: Int, faceWidth: Float): Boolean =
        faceWidth < imageWidth / VALID_FACE_SIZE_MAX_RATE_PORTRAIT

    fun isValidLandmarkConfidence(confidence: Float): Boolean =
        confidence >= VALID_FACE_DETECT_CONFIDENCE_VALUE
}

package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.KioskId
import com.ghostpasskiosksdk.gopasskiosksdk.domain.gateway.BeaconBroadcaster
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceEngineManager
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.ProvisionRepository
import com.ghostpasskiosksdk.gopasskiosksdk.domain.validation.validateInitializeArgs
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.cancellation.CancellationException

internal class InfrastructureManager(
    private val provisionRepository: ProvisionRepository,
    private val beaconBroadcaster: BeaconBroadcaster,
    private val faceEngineManager: FaceEngineManager,
    private val systemStateCoordinator: SystemStateCoordinator
) {
    companion object {
        private const val TAG = "InfrastructureManager ${BuildConfig.SIGNATURE}"
    }

    private val initMutex = Mutex()

    @Volatile
    private var initDeferred: Deferred<Boolean>? = null

    @Volatile
    private var lifecycleScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun initialize(
        apiKey: String,
        kioskId: KioskId,
        beaconConfig: BeaconConfig
    ): Boolean {
        val deferred = initMutex.withLock {
            initDeferred?.let { return@withLock it }

            val newDeferred = lifecycleScope.async {
                val isInitialized = performInitialize(apiKey, kioskId, beaconConfig)
                debugLog(TAG, "enroll 및 초기화 성공")
                if (isInitialized) {
                    try {
                        systemStateCoordinator.start(lifecycleScope)
                    } catch (e: Throwable) {
                        throw GoPassSdkException.from(
                            error = ErrorCode.INIT_FAILED,
                            customMessage = "시스템 상태 모니터링 시작에 실패하였습니다."
                        )
                    }
                }
                isInitialized
            }
            initDeferred = newDeferred
            newDeferred
        }

        return try {
            deferred.await().also { success ->
                if (!success) throw GoPassSdkException.from(ErrorCode.INIT_FAILED)
            }
        } catch (t: Throwable) {
            initMutex.withLock {
                if (initDeferred === deferred) {
                    initDeferred = null
                }
            }
            if (t is CancellationException && deferred.isCancelled) {
                throw GoPassSdkException.from(
                    error = ErrorCode.INIT_FAILED,
                    customMessage = "SDK가 reset되어 초기화가 취소되었습니다."
                )
            }
            throw t
        }
    }

    private suspend fun performInitialize(
        apiKey: String,
        kioskId: KioskId,
        beaconConfig: BeaconConfig
    ): Boolean {
        debugLog(TAG, "initialize: 호출")
        validateInitializeArgs(apiKey, kioskId, beaconConfig)

        val normalizedId = "${kioskId.svc}:${kioskId.region}:${kioskId.branch}:${kioskId.seq}"
        debugLog(TAG, "KioskId : $normalizedId")

        provisionRepository.provisionIfNeeded(apiKey, normalizedId, beaconConfig)

        faceEngineManager.initialize()

        debugLog(TAG, "송출되는 비콘 정보 : ${beaconConfig.uuid}:${beaconConfig.major}:${beaconConfig.minor}")
        val ok = beaconBroadcaster.start(beaconConfig)
        if (!ok) {
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                customMessage = "비콘 송출 시작에 실패하였습니다."
            )
        }

        return true
    }

    suspend fun reset(): Boolean {
        warnLog(TAG, "SDK reset 시작")

        var teardownException: Throwable? = null

        initMutex.withLock {
            val oldJob = lifecycleScope.coroutineContext[Job]

            lifecycleScope.cancel()

            runCatching { systemStateCoordinator.stop() }
                .onFailure { e -> if (teardownException == null) teardownException = e }

            runCatching { beaconBroadcaster.stop() }
                .onFailure { e -> if (teardownException == null) teardownException = e }

            if (oldJob != null) {
                val isCompleted = withTimeoutOrNull(2000L) {
                    oldJob.join()
                    true
                }

                if (isCompleted == null) {
                    val errMsg =
                        "FATAL: 일부 코루틴이 정상적으로 종료되지 않았습니다. (Memory Leak 및 Zombie 코루틴 위험)"
                    errorLog(TAG, errMsg)
                    if (teardownException == null) {
                        teardownException = IllegalStateException(errMsg)
                    }
                }
            }

            initDeferred = null
            lifecycleScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        }

        if (teardownException != null) {
            errorLog(TAG, "SDK 자원이 불완전하게 해제되었습니다. 원인: ${teardownException?.message}")
            throw GoPassSdkException.from(error = ErrorCode.RESET_FAILED)
        }

        warnLog(TAG, "SDK reset 완료 — initialize() 재호출 가능")
        return true
    }
}

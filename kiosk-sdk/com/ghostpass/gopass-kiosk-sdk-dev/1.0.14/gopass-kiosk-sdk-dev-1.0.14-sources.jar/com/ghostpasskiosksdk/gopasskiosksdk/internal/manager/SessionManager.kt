package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.EphemeralAesKey
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager.Companion.TRANSPORT_ALIAS
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.SdkDiagnosticEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionInfoPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.SessionRepository
import com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase.ExecuteRemoteAuthUseCase
import com.ghostpasskiosksdk.gopasskiosksdk.utils.DiagnosticEventBus
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.verboseLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.wipe
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

internal class SessionManager(
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager,
    private val sessionRepository: SessionRepository,
    private val remoteAuthUseCase: ExecuteRemoteAuthUseCase
) {
    companion object {
        private val TAG = "SessionManager ${BuildConfig.SIGNATURE}"
        internal const val AUTH_PROGRESS_BUFFER_MILLIS = 10_000L
    }

    private val managerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _sessions = MutableStateFlow<Set<SessionData>>(emptySet())
    val sessions: StateFlow<Set<SessionData>> = _sessions

    val connectedDeviceIds: StateFlow<List<String>> = _sessions
        .map { sessions ->
            sessions.sortedByDescending { it.createdAt }.map { it.deviceId }
        }
        .map { deviceIds ->
            infoLog(TAG, "[CONNECTED_DEVICES] $deviceIds (${deviceIds.size}명)")
            deviceIds
        }
        .stateIn(managerScope, SharingStarted.Eagerly, emptyList())

    private val cachedAuthTokens = ConcurrentHashMap<String, AuthToken>()
    private val k2uSeqTracker = ConcurrentHashMap<String, Int>()
    private val sessionTimeoutJobs = ConcurrentHashMap<String, Job>()
    private val sessionInfoFetchJobs = ConcurrentHashMap<String, Job>()

    private val syncLock = Any()
    private var latestSyncedSessionIds: Set<String> = emptySet()

    // ── 세션 페이로드 처리 ──────────────────────────────────────────

    internal suspend fun processSessionPayload(payload: SessionInfoPayload) {
        runCatching {
            synchronized(syncLock) {
                latestSyncedSessionIds = latestSyncedSessionIds + payload.sessionId
            }
            val domainData = withContext(Dispatchers.Default) {
                decryptAndCreateSessionData(
                    sessionId = payload.sessionId,
                    rtdbPath = payload.rtdbPath,
                    encryptedDk = payload.encryptedKioskDk,
                    firebaseToken = payload.firebaseToken,
                    expiresAtMillis = payload.expiresAtMillis,
                    deviceId = payload.deviceId
                )
            }

            var oldToDestroy: SessionData? = null
            _sessions.update { current ->
                oldToDestroy = current.find { it.sessionId == domainData.sessionId }
                current.filterNot { it.sessionId == domainData.sessionId }.toSet() + domainData
            }
            oldToDestroy?.let {
                warnLog(TAG, "중복 세션 감지, 기존 세션 교체: ${domainData.sessionId}")
                it.destroySecurely()
            }
            debugLog(TAG, "sessionId size 업데이트됨 : ${_sessions.value.size}")

            // 세션 생성 즉시 Firebase 인증을 백그라운드로 수행하여 토큰 캐싱
            managerScope.launch(Dispatchers.IO) {
                if (cachedAuthTokens.containsKey(domainData.sessionId)) {
                    debugLog(TAG, "세션 [${domainData.sessionId}] 사전 인증 이미 완료, skip")
                    return@launch
                }
                remoteAuthUseCase.authenticateSessions(setOf(domainData))
                    .forEach { (session, result) ->
                        result.onSuccess { token ->
                            cachedAuthTokens[session.sessionId] = token
                            debugLog(TAG, "세션 [${session.sessionId}] 사전 인증 완료")
                        }.onFailure { e ->
                            errorLog(TAG, "세션 [${session.sessionId}] 사전 인증 실패: ${e.message}")
                            DiagnosticEventBus.emit {
                                SdkDiagnosticEvent.PreAuthFailed(
                                    sessionId = session.sessionId,
                                    errorDetail = e.toString()
                                )
                            }
                        }
                    }
            }

            rescheduleSessionTimeout(domainData.sessionId, domainData.expiresAtMillis)
        }.onFailure { e ->
            errorLog(TAG, "Payload 처리 중 오류 발생: ${e.message}")
            DiagnosticEventBus.emit {
                SdkDiagnosticEvent.SessionPayloadFailed(
                    sessionId = payload.sessionId,
                    errorDetail = e.toString()
                )
            }
        }
    }

    // ── 세션 종료 처리 ──────────────────────────────────────────────

    /**
     * 서버에서 세션 종료(SESSION_TERMINATED) 이벤트를 수신하면
     * 해당 세션을 즉시 제거하고 관련 리소스를 정리한다.
     */
    internal fun processSessionTermination(sessionId: String) {
        synchronized(syncLock) {
            latestSyncedSessionIds = latestSyncedSessionIds - sessionId
        }
        sessionInfoFetchJobs.remove(sessionId)?.cancel()

        var removedSession: SessionData? = null
        _sessions.update { current ->
            removedSession = current.find { it.sessionId == sessionId }
            current.filterNot { it.sessionId == sessionId }.toSet()
        }

        removedSession?.let { session ->
            cleanupSessionResources(session, reason = "session_terminated")
            infoLog(TAG, "세션 종료(SESSION_TERMINATED) 처리 완료: $sessionId, 남은 세션: ${_sessions.value.size}")
        } ?: warnLog(TAG, "SESSION_TERMINATED 수신했으나 해당 세션 없음: $sessionId")
    }

    // ── 세션 동기화 처리 ────────────────────────────────────────────

    /**
     * SESSION_SYNC는 서버의 활성 세션 ID 스냅샷이다.
     * 서버 목록에 없는 로컬 세션은 좀비 세션으로 제거하고,
     * 로컬에 없는 서버 세션은 kiosk-info API로 상세 정보를 보강한다.
     */
    internal fun processSessionSync(serverSessionIds: Set<String>) {
        while (true) {
            synchronized(syncLock) {
                latestSyncedSessionIds = serverSessionIds
            }
            val current = _sessions.value
            val currentSessionIds = current.map { it.sessionId }.toSet()

            if (currentSessionIds == serverSessionIds) {
                debugLog(TAG, "SESSION_SYNC 일치: ${serverSessionIds.size}개")
                return
            }

            val sessionsToKeep = current.filter { it.sessionId in serverSessionIds }.toSet()
            val sessionsToRemove = current.filterNot { it.sessionId in serverSessionIds }

            if (!_sessions.compareAndSet(current, sessionsToKeep)) continue

            sessionsToRemove.forEach { session ->
                cleanupSessionResources(session, reason = "session_sync")
                infoLog(TAG, "SESSION_SYNC 기준 좀비 세션 제거: ${session.sessionId}")
            }

            val missingLocalSessionIds = serverSessionIds - currentSessionIds
            if (missingLocalSessionIds.isNotEmpty()) {
                warnLog(TAG, "SESSION_SYNC에 로컬 미보유 세션 존재: $missingLocalSessionIds")
                fetchMissingKioskInfoFromSync(missingLocalSessionIds)
            }

            infoLog(
                TAG,
                "SESSION_SYNC 처리 완료: before=${currentSessionIds.size}, server=${serverSessionIds.size}, after=${_sessions.value.size}"
            )
            return
        }
    }

    // ── kiosk-info 누락 세션 보강 ───────────────────────────────────

    internal fun fetchMissingKioskInfoFromSync(sessionIds: Set<String>) {
        sessionIds.forEach { sessionId ->
            if (_sessions.value.any { it.sessionId == sessionId }) return@forEach

            val fetchJob = managerScope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) {
                try {
                    when (val result = sessionRepository.fetchKioskInfo(sessionId)) {
                        is ApiResult.Success -> {
                            val payload = result.data
                            if (payload.sessionId != sessionId) {
                                warnLog(TAG, "kiosk-info sessionId 불일치: requested=$sessionId, response=${payload.sessionId}")
                                return@launch
                            }

                            if (synchronized(syncLock) { payload.sessionId !in latestSyncedSessionIds }) {
                                warnLog(TAG, "kiosk-info 수신 후 이미 비활성화된 세션 무시: ${payload.sessionId}")
                                return@launch
                            }

                            if (_sessions.value.any { it.sessionId == payload.sessionId }) {
                                debugLog(TAG, "kiosk-info 수신 전 이미 로컬에 추가된 세션 무시: ${payload.sessionId}")
                                return@launch
                            }

                            debugLog(TAG, "SESSION_SYNC 누락 세션 kiosk-info 조회 성공: ${payload.sessionId}")

                            // processSessionPayload 전에 seq/token pre-seed (race condition 방지)
                            preSeedSeqAndToken(payload)

                            processSessionPayload(payload)

                            // processSessionPayload 실패 시 orphan 정리
                            if (_sessions.value.none { it.sessionId == payload.sessionId }) {
                                cachedAuthTokens.remove(payload.sessionId)
                                k2uSeqTracker.remove(payload.sessionId)
                            }
                        }

                        is ApiResult.Failure -> {
                            val detail = "httpCode=${result.httpCode}, code=${result.code}, message=${result.message}"
                            errorLog(TAG, "SESSION_SYNC 누락 세션 kiosk-info 조회 실패 [$sessionId]: $detail")
                            DiagnosticEventBus.emit {
                                SdkDiagnosticEvent.KioskInfoFetchFailed(sessionId = sessionId, errorDetail = detail)
                            }
                        }

                        is ApiResult.NetworkError -> {
                            val detail = "network: ${result.error.message}"
                            errorLog(TAG, "SESSION_SYNC 누락 세션 kiosk-info 네트워크 오류 [$sessionId]: ${result.error.message}")
                            DiagnosticEventBus.emit {
                                SdkDiagnosticEvent.KioskInfoFetchFailed(sessionId = sessionId, errorDetail = detail)
                            }
                        }
                    }
                } finally {
                    sessionInfoFetchJobs.remove(sessionId)
                }
            }

            val existingJob = sessionInfoFetchJobs.putIfAbsent(sessionId, fetchJob)
            if (existingJob != null) {
                fetchJob.cancel()
                debugLog(TAG, "kiosk-info 조회 중복 요청 무시: $sessionId")
            } else {
                fetchJob.start()
            }
        }
    }

    // ── RTDB seq/token pre-seed ─────────────────────────────────────

    /**
     * processSessionPayload 전에 Firebase 인증 + RTDB kiosk_to_user seq 읽기를 수행하여
     * seq와 token을 미리 세팅한다. _sessions에 세션이 추가되기 전에 실행되므로
     * detection이 실행되어도 올바른 seq를 사용할 수 있다.
     * 실패 시 기존 동작(seq=0부터 시작)으로 graceful degradation.
     */
    private suspend fun preSeedSeqAndToken(payload: SessionInfoPayload) {
        runCatching {
            val authToken = remoteAuthUseCase.authenticateWithToken(payload.firebaseToken)
            cachedAuthTokens[payload.sessionId] = authToken
            debugLog(TAG, "SESSION_SYNC pre-seed 인증 완료: ${payload.sessionId}")

            val lastSeq = remoteAuthUseCase.fetchKioskToUserSeq(payload.rtdbPath, authToken.idToken)
            if (lastSeq != null && lastSeq > 0) {
                initializeSeq(payload.sessionId, lastSeq)
                debugLog(TAG, "SESSION_SYNC seq pre-seed 완료: ${payload.sessionId}, seq=$lastSeq")
            } else {
                debugLog(TAG, "SESSION_SYNC kiosk_to_user 데이터 없음 (신규 세션): ${payload.sessionId}")
            }
        }.onFailure { e ->
            warnLog(TAG, "SESSION_SYNC seq/token pre-seed 실패 (기본값 사용): ${payload.sessionId}, ${e.message}")
        }
    }

    // ── 세션 타임아웃 관리 ──────────────────────────────────────────

    /**
     * 지정된 만료 시각 기준으로 세션 타임아웃 Job을 (재)등록한다.
     * 이미 제거된 세션이면 무시한다.
     */
    internal fun rescheduleSessionTimeout(sessionId: String, expiresAtMillis: Long) {
        if (_sessions.value.none { it.sessionId == sessionId }) return

        val remaining = (expiresAtMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val newJob = managerScope.launch {
            delay(remaining)
            cleanupExpiredSession(sessionId)
        }
        sessionTimeoutJobs.put(sessionId, newJob)?.cancel()
    }

    internal fun cleanupExpiredSession(sessionId: String) {
        var removedSession: SessionData? = null
        _sessions.update { currentSessions ->
            removedSession = currentSessions.find { it.sessionId == sessionId }
            currentSessions.filterNot { it.sessionId == sessionId }.toSet()
        }

        removedSession?.let { session ->
            verboseLog(TAG, "세션 만료(expiresAt 기준) 자동 삭제됨 : ${session.sessionId}")
            cleanupSessionResources(session, reason = "session_expired")
        }
    }

    internal fun cleanupSessionResources(session: SessionData, reason: String = "session_cleanup") {
        cachedAuthTokens.remove(session.sessionId)
        val removedSeq = k2uSeqTracker.remove(session.sessionId)
        if (removedSeq != null) {
            DiagnosticEventBus.emit {
                SdkDiagnosticEvent.SeqTrackerCleared(
                    sessionId = session.sessionId,
                    lastKnownSeq = removedSeq,
                    reason = reason
                )
            }
        }
        sessionTimeoutJobs.remove(session.sessionId)?.cancel()
        sessionInfoFetchJobs.remove(session.sessionId)?.cancel()
        session.destroySecurely()
    }

    // ── auth-progress 관리 ──────────────────────────────────────────

    /**
     * kiosk-to-user 업로드 전, 전체 세션에 대해:
     * 1. 각 세션 타임아웃을 +10초 연장 (인증 완료까지 로컬 타임아웃 보호)
     * 2. auth-progress API를 세션 ID 목록으로 일괄 비동기 호출
     * 버퍼 복원은 launchRemoteAuth의 finally에서 인증 완료 후 수행한다.
     */
    internal fun notifyAuthProgressWithBuffer(sessions: Set<SessionData>) {
        sessions.forEach { session ->
            val bufferedRemaining = session.expiresAtMillis + AUTH_PROGRESS_BUFFER_MILLIS - System.currentTimeMillis()
            debugLog(TAG, "[AUTH_PROGRESS] 버퍼 +${AUTH_PROGRESS_BUFFER_MILLIS}ms 적용 [${session.sessionId}], 연장 후 남은 시간: ${bufferedRemaining}ms")
            rescheduleSessionTimeout(session.sessionId, session.expiresAtMillis + AUTH_PROGRESS_BUFFER_MILLIS)
        }

        managerScope.launch(Dispatchers.IO) {
            val sessionIds = sessions.map { it.sessionId }
            debugLog(TAG, "[AUTH_PROGRESS] API 호출 시작: ${sessionIds.size}개 세션 $sessionIds")

            when (val result = sessionRepository.notifyAuthProgress(sessionIds)) {
                is ApiResult.Success ->
                    debugLog(TAG, "[AUTH_PROGRESS] API 응답 성공: $sessionIds")
                is ApiResult.Failure -> {
                    val detail = "httpCode=${result.httpCode}, code=${result.code}, message=${result.message}"
                    errorLog(TAG, "[AUTH_PROGRESS] API 응답 실패: $detail")
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.AuthProgressResult(sessionIds = sessionIds, success = false, errorDetail = detail)
                    }
                }
                is ApiResult.NetworkError -> {
                    val detail = "network: ${result.error.message}"
                    errorLog(TAG, "[AUTH_PROGRESS] API 응답 미수신 (네트워크 오류): ${result.error.message}")
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.AuthProgressResult(sessionIds = sessionIds, success = false, errorDetail = detail)
                    }
                }
            }
        }
    }

    /**
     * 인증 완료 후 auth-progress 버퍼를 제거하고 원래 expiresAt으로 타임아웃을 복원한다.
     * winner 세션은 이미 제거되었으므로 복원 대상에서 자연스럽게 빠진다.
     */
    internal fun restoreAuthProgressBuffer(sessions: Set<SessionData>) {
        sessions.forEach { session ->
            if (_sessions.value.none { it.sessionId == session.sessionId }) return@forEach

            val remaining = session.expiresAtMillis - System.currentTimeMillis()
            if (remaining <= 0L) {
                warnLog(TAG, "[AUTH_PROGRESS] 버퍼 복원 시 세션 이미 만료 (remaining=${remaining}ms) [${session.sessionId}]")
                cleanupExpiredSession(session.sessionId)
            } else {
                debugLog(TAG, "[AUTH_PROGRESS] 버퍼 제거, 원래 타임아웃 복원 [${session.sessionId}], 남은 시간: ${remaining}ms")
                rescheduleSessionTimeout(session.sessionId, session.expiresAtMillis)
            }
        }
    }

    // ── 복호화 및 세션 데이터 생성 ──────────────────────────────────

    /**
     * 암호화된 세션 키를 복호화하여 도메인 객체로 변환한다.
     * 세션 정보 페이로드와 API 응답(InitiatedSessionDto) 양쪽에서 공통 사용.
     */
    internal fun decryptAndCreateSessionData(
        sessionId: String,
        rtdbPath: String,
        encryptedDk: String,
        firebaseToken: String,
        expiresAtMillis: Long,
        deviceId: String
    ): SessionData {
        val aad = sessionId.toByteArray(Charsets.UTF_8)
        val key = keyManager.getSecretKey(TRANSPORT_ALIAS)

        val decryptedBytes = cryptoEngine.decryptData(
            key = key,
            aad = aad,
            encryptedBase64 = encryptedDk
        )

        return try {
            SessionData(
                sessionId = sessionId,
                rtdbPath = rtdbPath,
                dkKiosk = EphemeralAesKey(decryptedBytes),
                firebaseToken = firebaseToken,
                expiresAtMillis = expiresAtMillis,
                deviceId = deviceId
            )
        } catch (e: Exception) {
            decryptedBytes.wipe()
            throw e
        }
    }

    // ── 토큰/시퀀스 접근자 ──────────────────────────────────────────

    internal fun getCachedAuthToken(sessionId: String): AuthToken? {
        return cachedAuthTokens[sessionId]
    }

    /**
     * 지정된 세션의 k2u 시퀀스를 1 증가시키고 새 값을 반환한다.
     * ConcurrentHashMap.compute()는 API 24+ 전용이므로, minSdk 23 호환을 위해
     * @Synchronized 블록으로 원자적 get/put을 수행한다.
     */
    @Synchronized
    internal fun getAndIncrementSeq(sessionId: String): Int {
        val prev = k2uSeqTracker[sessionId]
        val newSeq = (prev ?: 0) + 1
        k2uSeqTracker[sessionId] = newSeq
        DiagnosticEventBus.emit {
            SdkDiagnosticEvent.SeqComputed(
                sessionId = sessionId,
                previousSeq = prev,
                newSeq = newSeq
            )
        }
        return newSeq
    }

    /**
     * SESSION_SYNC 복구 시, RTDB kiosk_to_user에서 읽어온 마지막 seq로 트래커를 초기화한다.
     * 이미 detection에 의해 더 높은 seq가 세팅된 경우에는 무시한다.
     */
    @Synchronized
    internal fun initializeSeq(sessionId: String, lastKnownSeq: Int) {
        val current = k2uSeqTracker[sessionId]
        if (current == null || current < lastKnownSeq) {
            k2uSeqTracker[sessionId] = lastKnownSeq
            DiagnosticEventBus.emit {
                SdkDiagnosticEvent.SeqRestored(
                    sessionId = sessionId,
                    restoredSeq = lastKnownSeq,
                    previousSeq = current
                )
            }
        }
    }

    // ── winner 세션 제거 ────────────────────────────────────────────

    /**
     * 인증 성공(winner) 세션을 제거하고 관련 리소스를 정리한다.
     * launchRemoteAuth의 finally 블록에서 추출된 로직.
     */
    internal fun removeWinnerSession(sessionId: String) {
        var removedWinner: SessionData? = null
        _sessions.update { current ->
            removedWinner = current.find { it.sessionId == sessionId }
            current.filterNot { it.sessionId == sessionId }.toSet()
        }

        removedWinner?.let { session ->
            cachedAuthTokens.remove(session.sessionId)
            val removedSeq = k2uSeqTracker.remove(session.sessionId)
            if (removedSeq != null) {
                DiagnosticEventBus.emit {
                    SdkDiagnosticEvent.SeqTrackerCleared(
                        sessionId = session.sessionId,
                        lastKnownSeq = removedSeq,
                        reason = "winner_cleanup"
                    )
                }
            }
            sessionTimeoutJobs.remove(session.sessionId)?.cancel()
            session.destroySecurely()
        }
    }

    // ── 세션 요청 위임 ──────────────────────────────────────────────

    internal suspend fun requestSession(deviceId: String) =
        sessionRepository.requestSession(deviceId)

    // ── 안전 파기 확장 ──────────────────────────────────────────────

    internal fun SessionData.destroySecurely() {
        runCatching {
            val ephemeralKey = this.dkKiosk as? EphemeralAesKey
            if (ephemeralKey?.isDestroyed() == false) {
                ephemeralKey.destroy()
                debugLog(TAG, "세션 [${this.sessionId}] dkKiosk 메모리 안전 파기 완료")
            }
        }.onFailure { e ->
            errorLog(TAG, "세션 [${this.sessionId}] dkKiosk 파기 실패: ${e.message}")
        }
    }

    // ── 전체 자원 정리 ──────────────────────────────────────────────

    /**
     * SessionManager의 모든 자원을 정리합니다.
     * managerScope를 취소하므로, 이 인스턴스는 더 이상 사용할 수 없습니다.
     */
    internal fun destroy() {
        sessionTimeoutJobs.values.forEach { it.cancel() }
        sessionTimeoutJobs.clear()
        sessionInfoFetchJobs.values.forEach { it.cancel() }
        sessionInfoFetchJobs.clear()
        cachedAuthTokens.clear()
        k2uSeqTracker.clear()
        synchronized(syncLock) { latestSyncedSessionIds = emptySet() }
        _sessions.value.forEach { session ->
            session.destroySecurely()
        }
        _sessions.value = emptySet()
        managerScope.coroutineContext[Job]?.cancel()
        warnLog(TAG, "SessionManager 전체 자원 정리 완료")
    }
}

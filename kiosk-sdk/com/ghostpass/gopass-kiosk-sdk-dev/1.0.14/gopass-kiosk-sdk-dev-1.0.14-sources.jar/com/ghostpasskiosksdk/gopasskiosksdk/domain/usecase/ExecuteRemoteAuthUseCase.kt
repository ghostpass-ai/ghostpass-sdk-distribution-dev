package com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.SdkDiagnosticEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemoteStateChannelRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.DiagnosticEventBus
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog

internal class ExecuteRemoteAuthUseCase (
    private val remoteChannelRepository: RemoteStateChannelRepository
) {
    companion object {
        val TAG = "RTDB 작업 ${BuildConfig.SIGNATURE}"
    }

    suspend fun authenticateSessions(
        sessions: Set<SessionData>
    ): Map<SessionData, Result<AuthToken>> {
        infoLog(TAG, "🔐 세션 사전 인증 시작: ${sessions.size}개")
        return remoteChannelRepository.authenticateSessions(sessions)
    }

    suspend fun authenticateWithToken(firebaseToken: String): AuthToken {
        return remoteChannelRepository.authenticateWithToken(firebaseToken)
    }

    suspend fun fetchKioskToUserSeq(rtdbPath: String, idToken: String): Int? {
        return remoteChannelRepository.fetchKioskToUserSeq(rtdbPath, idToken)
    }

    suspend operator fun invoke(
        sessionPayloads: Map<SessionData, EncryptedSessionPayload>,
        preAuthTokens: Map<SessionData, Result<AuthToken>>,
        timeoutMs: Long = 7000L
    ): SessionIdEvent {
        infoLog(TAG, "👾 RTDB 업데이트 시작")

        val authenticatedTokens = mutableMapOf<SessionData, AuthToken>()

        preAuthTokens.forEach { (session, result) ->
            result.onSuccess { token ->
                authenticatedTokens[session] = token
            }.onFailure { e ->
                errorLog(TAG, "세션(${session.sessionId}) 인증 실패: ${e.message}")
                DiagnosticEventBus.emit {
                    SdkDiagnosticEvent.SessionAuthDropped(
                        sessionId = session.sessionId,
                        phase = "pre_auth_token",
                        errorDetail = e.toString()
                    )
                }
            }
        }

        if (authenticatedTokens.isEmpty()) {
            return SessionIdEvent.Failed(FaceAuthFailReason.UPDATE_FAILED)
        }

        // 인증된 세션만 RTDB 일괄 업데이트
        val authenticatedPayloads = sessionPayloads.filterKeys { it in authenticatedTokens }
        val updateStart = System.currentTimeMillis()
        val updateResults = remoteChannelRepository.updateKioskSecureData(authenticatedPayloads, authenticatedTokens)
        debugLog(TAG, "updateKioskSecureData 소요시간: ${System.currentTimeMillis() - updateStart}ms")

        val successSessions = mutableSetOf<SessionData>()
        val tokenMap = mutableMapOf<String, AuthToken>()

        updateResults.forEach { (session, result) ->
            result.onSuccess {
                successSessions.add(session)
                authenticatedTokens[session]?.let { token ->
                    tokenMap[session.sessionId] = token
                } ?: errorLog(TAG, "예상치 못한 null: ${session.sessionId}")
            }.onFailure { e ->
                errorLog(TAG, "세션(${session.sessionId}) 업데이트 실패: ${e.message}")
                DiagnosticEventBus.emit {
                    SdkDiagnosticEvent.SessionAuthDropped(
                        sessionId = session.sessionId,
                        phase = "rtdb_update",
                        errorDetail = e.toString()
                    )
                }
            }
        }

        if (successSessions.isEmpty()) {
            return SessionIdEvent.Failed(FaceAuthFailReason.UPDATE_FAILED)
        }

        // updateKioskSecureData(PATCH)가 위에서 완전히 완료된 뒤에만 observeSessionId(SSE)를 시작한다.
        // RtdbChannelWarmupManager는 세션당 idle 커넥션 1개만 미리 데우므로, PATCH가 데운 커넥션을
        // SSE가 그대로 재사용하는 이 순차 구조가 깨지면(PATCH/SSE 병렬화) 둘 중 하나는 warm-up 안 된
        // 커넥션으로 시작해 DNS+TCP+TLS 재수립 비용이 되살아난다.
        var authEvent: SessionIdEvent = SessionIdEvent.Failed(FaceAuthFailReason.TIMEOUT)
        try {
            val sessionsForObserve = successSessions.toSet()
            val tokensForObserve = tokenMap.toMap()
            val expectedSeqMap = sessionsForObserve.mapNotNull { session ->
                sessionPayloads[session]?.let { payload -> session.sessionId to payload.seq }
            }.toMap()
            authEvent = remoteChannelRepository.observeSessionId(
                sessionIds = sessionsForObserve,
                tokenMap = tokensForObserve,
                expectedSeqMap = expectedSeqMap,
                timeoutMs = timeoutMs
            )
        } finally {
            debugLog(TAG, "[FINALLY] authEvent=$authEvent")
            logWinnerSession(authEvent)
            tokenMap.clear()
            successSessions.clear()
        }
        return authEvent
    }

    private fun logWinnerSession(authEvent: SessionIdEvent) {
        val winnerId = (authEvent as? SessionIdEvent.Success)?.sessionId
        if (winnerId != null) {
            debugLog(TAG, "승리 세션 확인: $winnerId")
        }
    }

}

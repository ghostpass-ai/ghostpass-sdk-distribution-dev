package com.ghostpasskiosksdk.gopasskiosksdk.core.network.infra

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Proxy
import okhttp3.Call
import okhttp3.Connection
import okhttp3.EventListener
import okhttp3.Handshake
import okhttp3.Protocol
import okhttp3.Response

/**
 * [디버그 빌드 전용] GopassSDK ConnDiagEventListener 이식.
 * 인증 창(k2u PATCH + u2k observe)의 요청별 커넥션 출처 판별:
 * - [ACQUIRED][NEW]가 동반되면 → 커넥션 수립(DNS+TCP+TLS) 비용 (세션 도착 시 pre-warm이 해결책)
 * - [ACQUIRED][REUSED]인데도 느리면 → 서버/경로 측 지연
 * - REUSED 후 무응답/타임아웃 → NAT 무음 절단(stale socket) 의심
 *
 * 주의: okhttp-sse는 EventSource 연결 시 EventListener를 강제 제거하므로 SSE 콜에는
 * 이 리스너가 동작하지 않는다. SSE 커넥션 진단은 RemoteStateChannelRepositoryImpl의
 * [SSE_CONN] network interceptor가 담당한다.
 */
internal class ConnDiagEventListenerFactory(
    private val clientLabel: String
) : EventListener.Factory {
    override fun create(call: Call): EventListener = ConnDiagEventListener(clientLabel)
}

private class ConnDiagEventListener(
    private val clientLabel: String
) : EventListener() {

    companion object {
        private val TAG = "ConnDiag ${BuildConfig.SIGNATURE}"
    }

    private var callStartNanos = 0L
    private var connectStartNanos = 0L
    private var secureStartNanos = 0L
    private var dnsStartNanos = 0L
    private var newConnection = false
    private var requestLine = "?"

    private fun sinceCallStartMs() = (System.nanoTime() - callStartNanos) / 1_000_000

    private fun sinceMs(startNanos: Long) = (System.nanoTime() - startNanos) / 1_000_000

    override fun callStart(call: Call) {
        callStartNanos = System.nanoTime()
        // 주의: query에 auth 토큰이 있으므로 encodedPath만 로깅
        requestLine = "${call.request().method} ${call.request().url.encodedPath}"
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CALL_START] $requestLine")
    }

    override fun dnsStart(call: Call, domainName: String) {
        dnsStartNanos = System.nanoTime()
    }

    override fun dnsEnd(call: Call, domainName: String, inetAddressList: List<java.net.InetAddress>) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][DNS] ${sinceMs(dnsStartNanos)}ms 소요 (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun connectStart(call: Call, inetSocketAddress: InetSocketAddress, proxy: Proxy) {
        newConnection = true
        connectStartNanos = System.nanoTime()
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CONN_NEW] TCP 연결 시작 (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun secureConnectStart(call: Call) {
        secureStartNanos = System.nanoTime()
    }

    override fun secureConnectEnd(call: Call, handshake: Handshake?) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][TLS] handshake ${sinceMs(secureStartNanos)}ms 소요 (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun connectEnd(call: Call, inetSocketAddress: InetSocketAddress, proxy: Proxy, protocol: Protocol?) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CONN_DONE] 수립 완료 ${sinceMs(connectStartNanos)}ms 소요, protocol=$protocol (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun connectFailed(call: Call, inetSocketAddress: InetSocketAddress, proxy: Proxy, protocol: Protocol?, ioe: IOException) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CONN_FAIL] ${sinceMs(connectStartNanos)}ms 후 실패: ${ioe.message} (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun connectionAcquired(call: Call, connection: Connection) {
        val kind = if (newConnection) "NEW" else "REUSED"
        warnLog(
            TAG,
            "[CONN_DIAG][$clientLabel][ACQUIRED][$kind] conn=${System.identityHashCode(connection)} " +
                "protocol=${connection.protocol()} (+${sinceCallStartMs()}ms) $requestLine"
        )
    }

    override fun responseHeadersEnd(call: Call, response: Response) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][RESP] code=${response.code} protocol=${response.protocol} (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun callEnd(call: Call) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CALL_END] total=${sinceCallStartMs()}ms newConn=$newConnection $requestLine")
    }

    override fun callFailed(call: Call, ioe: IOException) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CALL_FAIL] total=${sinceCallStartMs()}ms newConn=$newConnection ${ioe.message} $requestLine")
    }
}

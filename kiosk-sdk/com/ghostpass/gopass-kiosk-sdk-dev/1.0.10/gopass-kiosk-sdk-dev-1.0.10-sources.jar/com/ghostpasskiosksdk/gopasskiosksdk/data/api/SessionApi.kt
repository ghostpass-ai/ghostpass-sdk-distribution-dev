package com.ghostpasskiosksdk.gopasskiosksdk.data.api

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResponse
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.AuthProgressRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.InitiatedSessionDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.InitiatedSessionRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

internal interface SessionApi {
    companion object {
        const val PREFIX = "api/v1/sessions"
    }
    @POST("$PREFIX/kiosk-initiated")
    suspend fun requestSession(
        @Body request: InitiatedSessionRequest
    ) : Response<ApiResponse<InitiatedSessionDto>>

    @POST("$PREFIX/auth-progress")
    suspend fun notifyAuthProgress(
        @Body request: AuthProgressRequest
    ) : Response<ApiResponse<String>>
}

package com.ghostpasskiosksdk.gopasskiosksdk.data.mapper

import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.SessionInfoDto
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionInfoPayload

internal fun SessionInfoDto.toDomain(): SessionInfoPayload {
    return SessionInfoPayload(
        sessionId = sessionId,
        rtdbPath = rtdbPath,
        encryptedKioskDk = encryptedKioskDk,
        firebaseToken = firebaseToken,
        expiresAtMillis = parseExpiresAtMillis(expiresAt),
        deviceId = deviceId
    )
}

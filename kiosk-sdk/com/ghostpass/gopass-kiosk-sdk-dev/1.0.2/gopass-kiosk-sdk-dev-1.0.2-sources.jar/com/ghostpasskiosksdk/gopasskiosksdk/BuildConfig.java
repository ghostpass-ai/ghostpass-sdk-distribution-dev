/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.ghostpasskiosksdk.gopasskiosksdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.ghostpasskiosksdk.gopasskiosksdk";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "dev";
  // Field from product flavor: dev
  public static final String API_KEY = "bd409065025ccc16f3fa00dd431c3d2e479c02020ea522fd90ae9e07d45a126a";
  // Field from product flavor: dev
  public static final String BASE_URL = "https://newdev.ghostpass.ai/";
  // Field from product flavor: dev
  public static final long CLOUD_PROJECT_NUMBER = 552464157469L;
  // Field from product flavor: dev
  public static final String FB_API_KEY = "AIzaSyC94NBiktKi8sdgWe2kZvs7GltZjxSVWA0";
  // Field from product flavor: dev
  public static final String FB_APP_ID = "1:507647761857:android:a7c29fb3c7ce240fd96340";
  // Field from product flavor: dev
  public static final String FB_DB_URL = "https://gpass-dev-cd816-default-rtdb.asia-southeast1.firebasedatabase.app";
  // Field from product flavor: dev
  public static final String FB_PROJECT_ID = "gpass-dev-cd816";
  // Field from product flavor: dev
  public static final String UUID = "550e8400-e29b-41d4-a716-446655440000";
}

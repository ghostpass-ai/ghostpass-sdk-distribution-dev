package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session

import java.security.Key

internal data class SessionData(
    val sessionId: String,
    val rtdbPath: String,
    val dkKiosk: Key,
    val firebaseToken: String,
    val expiresAtMillis: Long,
    val deviceId: String,
    val createdAt: Long = System.currentTimeMillis()
)
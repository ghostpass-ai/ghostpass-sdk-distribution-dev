package com.ghostpasskiosksdk.gopasskiosksdk.core.network.utils

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResponse
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.utils.SafeApiCall.TAG
import com.ghostpasskiosksdk.gopasskiosksdk.utils.verboseLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json.Default.decodeFromString
import retrofit2.Response

private object SafeApiCall {
    val TAG = "SafeApiCall ${BuildConfig.SIGNATURE}"
}

internal suspend fun <T> safeApiCall(
    call: suspend () -> Response<ApiResponse<T>>
): ApiResult<T> {
    return try {
        val resp = call()
        val httpCode = resp.code()
        verboseLog(TAG, "response : $resp")

        if (resp.isSuccessful) {
            val body = resp.body()
                ?: return ApiResult.Failure(httpCode, code = "EMPTY_BODY", message = "Empty response body")
            warnLog(TAG, "success body : $body")
            return if (body.success) {
                body.data?.let { ApiResult.Success(it, body.message) }
                    ?: ApiResult.Failure(httpCode, code = body.code ?: "MISSING_DATA", message = body.message)
            } else {
                ApiResult.Failure(httpCode, code = body.code, message = body.message)
            }
        }

        val raw = resp.errorBody()?.string()
        if (raw.isNullOrBlank()) {
            ApiResult.Failure(httpCode, message = "HTTP error with empty body")
        } else {
            try {
                val err = decodeFromString<ApiResponse<Unit>>(raw)
                warnLog(TAG, "error Body : $err")
                ApiResult.Failure(httpCode, code = err.code, message = err.message)
            } catch (se: SerializationException) {
                ApiResult.Failure(httpCode, code = "PARSE_ERROR", message = se.message)
            }
        }
    } catch (t: Throwable) {
        ApiResult.NetworkError(t)
    }
}
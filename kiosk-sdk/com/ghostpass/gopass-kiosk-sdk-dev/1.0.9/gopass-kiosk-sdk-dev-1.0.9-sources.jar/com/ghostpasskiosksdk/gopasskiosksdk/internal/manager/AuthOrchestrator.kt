package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import android.view.Surface
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.NetworkStateProvider
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.EphemeralAesKey
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager.Companion.TRANSPORT_ALIAS
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.auth.FaceVectorPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.domain.gateway.BeaconBroadcaster
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.FailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.GoPassAuthResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SseConnectionState
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthPrecheckResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SseEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SseSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.getOrThrow
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemotePathRepository
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.SessionRepository
import com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase.ExecuteRemoteAuthUseCase
import com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase.PrepareFaceAuthUseCase
import com.ghostpasskiosksdk.gopasskiosksdk.internal.mapper.mapAuthExceptionToResult
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.verboseLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.wipe
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json.Default.encodeToString
import java.io.IOException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.pow

internal class AuthOrchestrator(
    private val remoteAuthUseCase: ExecuteRemoteAuthUseCase,
    private val remotePathRepository: RemotePathRepository,
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager,
    private val prepareFaceAuthUseCase: PrepareFaceAuthUseCase,
    private val beaconBroadcaster: BeaconBroadcaster,
    private val networkStateProvider: NetworkStateProvider,
    private val sessionRepository: SessionRepository
) {
    companion object {
        private val TAG = "AuthOrchestrator ${BuildConfig.SIGNATURE}"
        private const val AUTH_PROGRESS_BUFFER_MILLIS = 10_000L
        private const val LANDMARK_EXPIRY_MILLIS = 30_000L
        private const val PHONE_AUTH_RESULT_TIMEOUT_MILLIS = 8_000L
        private const val MAX_EXPONENTIAL_BACKOFF_MS = 30_000L
        private const val AUTH_ERROR_DELAY_MS = 60_000L
    }

    // 번호 인증용 랜드마크 임시 보관소
    // destroy()가 코루틴 시퀀스 밖에서 clearPendingLandmark()를 호출할 수 있으므로
    // @Volatile로 스레드 간 가시성을 보장한다.
    @Volatile
    private var pendingLandmark: FloatArray? = null
    @Volatile
    private var landmarkTimestamp: Long = 0L

    private val orchestratorScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _sessionIds = MutableStateFlow<Set<SessionData>>(emptySet())
    private var collectionJob: Job? = null

    private val _sseConnectionState =
        MutableStateFlow<SseConnectionState>(SseConnectionState.Disconnected)
    val sseConnectionState = _sseConnectionState.asStateFlow()

    val connectedDeviceIds: StateFlow<List<String>> = _sessionIds
        .map { sessions ->
            sessions.sortedByDescending { it.createdAt }.map { it.deviceId }
        }
        .map { deviceIds ->
            infoLog(TAG, "[CONNECTED_DEVICES] $deviceIds (${deviceIds.size}명)")
            deviceIds
        }
        .stateIn(orchestratorScope, SharingStarted.Eagerly, emptyList())

    // 상태 관리 플래그
    private val cachedAuthTokens = ConcurrentHashMap<String, AuthToken>()
    private val k2uSeqTracker = ConcurrentHashMap<String, Int>()
    private val isProcessingInFlight = AtomicBoolean(false)
    private val isRemoteAuthInFlight = AtomicBoolean(false)
    private val sessionTimeoutJobs = ConcurrentHashMap<String, Job>()

    // 백그라운드 인증 결과 저장소
    // launchRemoteAuth()에서 write → execute()에서 read+null
    @Volatile
    private var pendingAuthResult: GoPassAuthResult? = null

    @Volatile
    private var isDestroyed = false
    @Volatile
    private var hasEstablishedSseConnection = false

    // @Synchronized: collectionJob의 읽기-취소-재할당 복합 연산을 원자적으로 보호
    // AtomicBoolean: handleStreamCompletion()이 @Synchronized 블록 밖(onCompletion 콜백)에서
    //               isSseCollecting 상태를 안전하게 전이하기 위해 lock-free 원자성 사용
    private val isSseCollecting = AtomicBoolean(false)

    /**
     * SSE 연결을 중단합니다.
     */
    @Synchronized
    fun stopSessionCollection() {
        isSseCollecting.set(false)
        collectionJob?.cancel()
        collectionJob = null
        _sseConnectionState.value = SseConnectionState.Disconnected
        debugLog(TAG, "SSE 세션 수집 중단됨")
    }

    /**
     * SSE 연결을 시작합니다. (Public Entry Point)
     */
    @Synchronized
    fun startSessionCollection(force: Boolean = false): Boolean {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 SSE 수집 시작 요청은 무시됩니다.")
            return false
        }
        debugLog(
            TAG,
            "startSessionCollection 호출됨! orchestratorScope isActive: ${orchestratorScope.isActive}, force=$force"
        )

        val hasActiveCollection = isSseCollecting.get() && collectionJob?.isActive == true
        if (hasActiveCollection && !force) {
            debugLog(TAG, "이미 SSE 수집이 진행 중입니다.")
            return true
        }

        // force: 강제 재연결 요청 시 기존 연결을 파기하고 재시작
        // isSseCollecting == true && collectionJob 비활성: 좀비 상태 복구 (플래그는 true인데 실제 Job이 죽은 경우)
        // collectionJob?.isActive != true: Job이 없거나 이미 완료된 경우 정리
        if (force || isSseCollecting.get() || collectionJob?.isActive != true) {
            collectionJob?.cancel()
            collectionJob = null
            isSseCollecting.set(false)
        }

        if (!isSseCollecting.compareAndSet(false, true)) {
            debugLog(TAG, "SSE 수집 상태 전환에 실패했습니다.")
            return collectionJob?.isActive == true
        }

        return try {
            collectionJob = observeSseFlow()
            true
        } catch (e: Exception) {
            isSseCollecting.set(false)
            handleFatalError(e)
            false
        }
    }

    /**
     * SSE Flow 파이프라인 조립 및 실행 (Private)
     */
    private fun observeSseFlow(): Job {
        return orchestratorScope.launch {
            var reconnectAttempt = 0L
            val runningJob = currentCoroutineContext()[Job]

            while (currentCoroutineContext().isActive && !isDestroyed && isSseCollecting.get()) {
                _sseConnectionState.value = SseConnectionState.Connecting
                debugLog(TAG, "SSE Flow 수집 시작")

                try {
                    remotePathRepository.observePaths()
                        .flowOn(Dispatchers.IO)
                        .collect { event ->
                            when (event) {
                                is SseEvent.Connected -> {
                                    _sseConnectionState.value = SseConnectionState.Connected
                                    hasEstablishedSseConnection = true
                                    reconnectAttempt = 0L
                                    debugLog(TAG, "SSE 연결 확인됨")
                                }

                                is SseEvent.Heartbeat -> {
                                    debugLog(TAG, "SSE Heartbeat 수신")
                                }

                                is SseEvent.SessionCreated -> {
                                    if (_sseConnectionState.value != SseConnectionState.Connected) {
                                        _sseConnectionState.value = SseConnectionState.Connected
                                        hasEstablishedSseConnection = true
                                        reconnectAttempt = 0L
                                    }
                                    processSessionPayload(event.payload)
                                }

                                is SseEvent.SessionTerminated -> {
                                    processSessionTermination(event.sessionId)
                                }
                            }
                        }

                    if (!isSseCollecting.get()) {
                        break
                    }

                    _sseConnectionState.value = SseConnectionState.Disconnected
                    val delayTime = nextReconnectDelay(null, reconnectAttempt++)
                    warnLog(TAG, "SSE 재연결 예약됨 (${delayTime}ms 후)")
                    delay(delayTime)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    handleStreamError(e)
                    if (!isSseCollecting.get() || isDestroyed) {
                        break
                    }

                    val delayTime = nextReconnectDelay(e, reconnectAttempt++)
                    warnLog(TAG, "SSE 재연결 예약됨 (${delayTime}ms 후)")
                    delay(delayTime)
                }
            }

            if (collectionJob === runningJob) {
                isSseCollecting.set(false)
                if (!isDestroyed && _sseConnectionState.value !is SseConnectionState.Error) {
                    _sseConnectionState.value = SseConnectionState.Disconnected
                }
            }
        }
    }

    private suspend fun processSessionPayload(payload: SseSessionPayload) {
        runCatching {
            val domainData = withContext(Dispatchers.Default) {
                decryptAndCreateSessionData(
                    sessionId = payload.sessionId,
                    rtdbPath = payload.rtdbPath,
                    encryptedDk = payload.encryptedKioskDk,
                    firebaseToken = payload.firebaseToken,
                    expiresAtMillis = payload.expiresAtMillis,
                    deviceId = payload.deviceId
                )
            }

            var oldToDestroy: SessionData? = null
            _sessionIds.update { current ->
                oldToDestroy = current.find { it.sessionId == domainData.sessionId }
                current.filterNot { it.sessionId == domainData.sessionId }.toSet() + domainData
            }
            oldToDestroy?.let {
                warnLog(TAG, "중복 세션 감지, 기존 세션 교체: ${domainData.sessionId}")
                it.destroySecurely()
            }
            debugLog(TAG, "sessionId size 업데이트됨 : ${_sessionIds.value.size}")

            // 세션 생성 즉시 Firebase 인증을 백그라운드로 수행하여 토큰 캐싱
            orchestratorScope.launch(Dispatchers.IO) {
                remoteAuthUseCase.authenticateSessions(setOf(domainData))
                    .forEach { (session, result) ->
                        result.onSuccess { token ->
                            cachedAuthTokens[session.sessionId] = token
                            debugLog(TAG, "세션 [${session.sessionId}] 사전 인증 완료")
                        }.onFailure { e ->
                            errorLog(TAG, "세션 [${session.sessionId}] 사전 인증 실패: ${e.message}")
                        }
                    }
            }

            rescheduleSessionTimeout(domainData.sessionId, domainData.expiresAtMillis)
        }.onFailure { e ->
            errorLog(TAG, "Payload 처리 중 오류 발생: ${e.message}")
        }
    }

    /**
     * 서버에서 세션 종료(SESSION_TERMINATED) 이벤트를 수신하면
     * 해당 세션을 즉시 제거하고 관련 리소스를 정리한다.
     */
    private fun processSessionTermination(sessionId: String) {
        var removedSession: SessionData? = null
        _sessionIds.update { current ->
            removedSession = current.find { it.sessionId == sessionId }
            current.filterNot { it.sessionId == sessionId }.toSet()
        }

        removedSession?.let { session ->
            cachedAuthTokens.remove(session.sessionId)
            k2uSeqTracker.remove(session.sessionId)
            sessionTimeoutJobs.remove(session.sessionId)?.cancel()
            session.destroySecurely()
            infoLog(TAG, "세션 종료(SESSION_TERMINATED) 처리 완료: $sessionId, 남은 세션: ${_sessionIds.value.size}")
        } ?: warnLog(TAG, "SESSION_TERMINATED 수신했으나 해당 세션 없음: $sessionId")
    }

    // ── 세션 타임아웃 관리 ──────────────────────────────────────────

    /**
     * 지정된 만료 시각 기준으로 세션 타임아웃 Job을 (재)등록한다.
     * 이미 제거된 세션이면 무시한다.
     */
    private fun rescheduleSessionTimeout(sessionId: String, expiresAtMillis: Long) {
        if (_sessionIds.value.none { it.sessionId == sessionId }) return

        val remaining = (expiresAtMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val newJob = orchestratorScope.launch {
            delay(remaining)
            cleanupExpiredSession(sessionId)
        }
        sessionTimeoutJobs.put(sessionId, newJob)?.cancel()
    }

    private fun cleanupExpiredSession(sessionId: String) {
        var removedSession: SessionData? = null
        _sessionIds.update { currentSessions ->
            removedSession = currentSessions.find { it.sessionId == sessionId }
            currentSessions.filterNot { it.sessionId == sessionId }.toSet()
        }

        removedSession?.let { session ->
            verboseLog(TAG, "세션 만료(expiresAt 기준) 자동 삭제됨 : ${session.sessionId}")
            cachedAuthTokens.remove(session.sessionId)
            k2uSeqTracker.remove(session.sessionId)
            sessionTimeoutJobs.remove(session.sessionId)
            session.destroySecurely()
        }
    }

    /**
     * kiosk-to-user 업로드 전, 전체 세션에 대해:
     * 1. 각 세션 타임아웃을 +10초 연장 (auth-progress 호출 보호)
     * 2. auth-progress API를 세션 ID 목록으로 일괄 비동기 호출
     * 3. 응답 수신 후 각 세션 타임아웃을 원래 expiresAt으로 복원 (남은 시간 ≤ 0이면 즉시 만료)
     */
    private fun notifyAuthProgressWithBuffer(sessions: Set<SessionData>) {
        sessions.forEach { session ->
            val bufferedRemaining = session.expiresAtMillis + AUTH_PROGRESS_BUFFER_MILLIS - System.currentTimeMillis()
            debugLog(TAG, "[AUTH_PROGRESS] 버퍼 +${AUTH_PROGRESS_BUFFER_MILLIS}ms 적용 [${session.sessionId}], 연장 후 남은 시간: ${bufferedRemaining}ms")
            rescheduleSessionTimeout(session.sessionId, session.expiresAtMillis + AUTH_PROGRESS_BUFFER_MILLIS)
        }

        orchestratorScope.launch(Dispatchers.IO) {
            val sessionIds = sessions.map { it.sessionId }
            debugLog(TAG, "[AUTH_PROGRESS] API 호출 시작: ${sessionIds.size}개 세션 $sessionIds")

            when (val result = sessionRepository.notifyAuthProgress(sessionIds)) {
                is ApiResult.Success ->
                    debugLog(TAG, "[AUTH_PROGRESS] API 응답 성공: $sessionIds")
                is ApiResult.Failure ->
                    errorLog(TAG, "[AUTH_PROGRESS] API 응답 실패: httpCode=${result.httpCode}, code=${result.code}, message=${result.message}")
                is ApiResult.NetworkError ->
                    errorLog(TAG, "[AUTH_PROGRESS] API 응답 미수신 (네트워크 오류): ${result.error.message}")
            }

            sessions.forEach { session ->
                val remaining = session.expiresAtMillis - System.currentTimeMillis()
                if (remaining <= 0L) {
                    warnLog(TAG, "[AUTH_PROGRESS] 버퍼 복원 시 세션 이미 만료 (remaining=${remaining}ms) [${session.sessionId}]")
                    cleanupExpiredSession(session.sessionId)
                } else {
                    debugLog(TAG, "[AUTH_PROGRESS] 버퍼 제거, 원래 타임아웃 복원 [${session.sessionId}], 남은 시간: ${remaining}ms")
                    rescheduleSessionTimeout(session.sessionId, session.expiresAtMillis)
                }
            }
        }
    }

    /**
     * 암호화된 세션 키를 복호화하여 도메인 객체로 변환한다.
     * SSE 페이로드(SseSessionPayload)와 API 응답(InitiatedSessionDto) 양쪽에서 공통 사용.
     */
    private fun decryptAndCreateSessionData(
        sessionId: String,
        rtdbPath: String,
        encryptedDk: String,
        firebaseToken: String,
        expiresAtMillis: Long,
        deviceId: String
    ): SessionData {
        val aad = sessionId.toByteArray(Charsets.UTF_8)
        val key = keyManager.getSecretKey(TRANSPORT_ALIAS)

        val decryptedBytes = cryptoEngine.decryptData(
            key = key,
            aad = aad,
            encryptedBase64 = encryptedDk
        )

        return try {
            SessionData(
                sessionId = sessionId,
                rtdbPath = rtdbPath,
                dkKiosk = EphemeralAesKey(decryptedBytes),
                firebaseToken = firebaseToken,
                expiresAtMillis = expiresAtMillis,
                deviceId = deviceId
            )
        } catch (e: Exception) {
            decryptedBytes.wipe()
            throw e
        }
    }

    /**
     * SSE 스트림 에러 핸들링
     */
    private fun handleStreamError(e: Throwable) {
        val sdkException = when (e) {
            is GoPassSdkException -> e
            is UnknownHostException,
            is IOException -> GoPassSdkException.from(
                error = ErrorCode.NETWORK_ERROR,
                cause = InternalErrorCode.SSE_NETWORK_TIMEOUT
            )

            else -> GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.SSE_STREAM_UNKNOWN_ERROR
            )
        }

        errorLog(TAG, "❌ SSE Stream Error 잡힘: ${sdkException.message}")
        _sseConnectionState.value = SseConnectionState.Error(sdkException)
    }

    fun forceReconnect(reason: String): Boolean {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 SSE 강제 재연결 요청은 무시됩니다. ($reason)")
            return false
        }
        if (!orchestratorScope.isActive) {
            warnLog(TAG, "SSE 강제 재연결 실패: scope가 이미 종료됨 ($reason)")
            return false
        }

        warnLog(TAG, "SSE 강제 재연결 수행: $reason")
        return startSessionCollection(force = true)
    }

    private fun nextReconnectDelay(cause: Throwable?, attempt: Long): Long {
        val cappedAttempt = if (attempt > 20) 20 else attempt.toInt()
        val isAuthError = cause is GoPassSdkException &&
            cause.causeCode == InternalErrorCode.SSE_AUTH_TOKEN_INVALID.code

        return when {
            isAuthError -> AUTH_ERROR_DELAY_MS
            else -> minOf(
                1000L * (2.0.pow((cappedAttempt + 1).toDouble())).toLong(),
                MAX_EXPONENTIAL_BACKOFF_MS
            )
        }
    }

    /**
     * Flow 실행 전 발생한 치명적 예외 핸들링
     */
    private fun handleFatalError(e: Exception) {
        errorLog(TAG, "Failed to start SSE: ${e.message}")
        val sdkException = e as? GoPassSdkException
            ?: GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.UNKNOWN
            )
        _sseConnectionState.value = SseConnectionState.Error(sdkException)
    }

    /**
     * 얼굴 인식부터 서버 인증까지의 전체 시퀀스 실행
     *
     * 얼굴 검증 통과 시 [GoPassAuthResult.Authenticating]을 즉시 반환하고,
     * 원격 인증은 백그라운드([launchRemoteAuth])로 실행한다.
     * 이후 호출에서 [pendingAuthResult]를 통해 최종 결과를 전달한다.
     */
    suspend fun execute(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotation: Int,
    ): GoPassAuthResult = withContext(Dispatchers.Default) {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 인증 요청은 거부됩니다.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.AUTH_ERROR,
                message = ErrorCode.AUTH_ERROR.message!!
            )
        }

        // 백그라운드 인증 결과가 준비되었으면 즉시 반환
        pendingAuthResult?.let { result ->
            pendingAuthResult = null
            debugLog(TAG, "백그라운드 인증 결과 반환: $result")
            return@withContext result
        }

        // 서버 인증이 백그라운드에서 진행 중이면 Authenticating 반환
        if (isRemoteAuthInFlight.get()) {
            return@withContext GoPassAuthResult.Authenticating
        }

        if (!networkStateProvider.isAvailable.value) {
            warnLog(TAG, "네트워크 단절 감지됨. 인증 시도 거부.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.NETWORK_ERROR, // GP901
                message = "기기 네트워크 연결이 끊어졌습니다."
            )
        }

        if (shouldBlockAuthBecauseSseUnavailable()) {
            warnLog(TAG, "SSE 연결 불안정 상태 감지됨. 인증 시도 거부.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.NETWORK_ERROR,
                message = ErrorCode.NETWORK_ERROR.message!!
            )
        }

        if (_sessionIds.value.isEmpty()) {
            return@withContext GoPassAuthResult.PrecheckGuide(listOf(FailReason.NO_SESSION))
        }

        if (!isProcessingInFlight.compareAndSet(false, true)) {
            return@withContext GoPassAuthResult.PrecheckGuide(listOf(FailReason.ALREADY_IN_PROGRESS))
        }

        // compareAndSet 직후 try 진입 — 사이에 코드 없음 (OOM 고착 방지)
        try {
            val surfaceRotation = mapToSurfaceRotation(rotation)
            val precheckResult = prepareFaceAuthUseCase.execute(
                faceImage = faceImage,
                width = width,
                height = height,
                rotation = surfaceRotation
            )

            if (precheckResult is FaceAuthPrecheckResult.Failed) {
                isProcessingInFlight.set(false)
                return@withContext GoPassAuthResult.PrecheckGuide(precheckResult.reasons)
            }

            val successPrecheck = precheckResult as FaceAuthPrecheckResult.Success
            debugLog(TAG, "landmark size : ${successPrecheck.landmark.size}")

            // 원격 인증을 백그라운드로 분리
            // isProcessingInFlight는 true 유지 → launchRemoteAuth의 finally에서 해제
            isRemoteAuthInFlight.set(true)
            launchRemoteAuth(successPrecheck)

            return@withContext GoPassAuthResult.Authenticating
        } catch (e: Exception) {
            isProcessingInFlight.set(false)
            errorLog(TAG, "execute precheck error: $e")
            return@withContext handleAuthException(e)
        }
    }

    private fun shouldBlockAuthBecauseSseUnavailable(): Boolean {
        return when (_sseConnectionState.value) {
            is SseConnectionState.Error -> true
            SseConnectionState.Connected -> false
            SseConnectionState.Connecting,
            SseConnectionState.Disconnected -> hasEstablishedSseConnection
        }
    }

    /**
     * 원격 인증을 백그라운드로 실행한다.
     * 결과는 [pendingAuthResult]에 저장되며, 다음 [execute] 호출 시 반환된다.
     * [isProcessingInFlight]는 이 메서드 완료 시 false로 전환된다.
     */
    private fun launchRemoteAuth(successPrecheck: FaceAuthPrecheckResult.Success) {
        orchestratorScope.launch(Dispatchers.Default) {
            var winnerSessionId: String? = null
            try {
                beaconBroadcaster.pause()

                // 1. 캐싱된 토큰 수집 (세션 생성 시 사전 인증된 토큰 활용, 미캐싱 세션은 즉시 인증)
                val currentSessions = _sessionIds.value
                val uncachedSessions = currentSessions.filter { !cachedAuthTokens.containsKey(it.sessionId) }
                val freshTokens = if (uncachedSessions.isNotEmpty()) {
                    warnLog(TAG, "미캐싱 세션 ${uncachedSessions.size}개 즉시 인증 시도")
                    remoteAuthUseCase.authenticateSessions(uncachedSessions.toSet())
                } else emptyMap()

                val preAuthTokens = currentSessions.associateWith { session ->
                    cachedAuthTokens[session.sessionId]?.let { Result.success(it) }
                        ?: freshTokens[session]
                        ?: Result.failure(GoPassSdkException.from(
                            error = ErrorCode.INTERNAL_ERROR,
                            cause = InternalErrorCode.FB_AUTH_NULL
                        ))
                }

                // 2. auth-progress 비동기 호출 (타임아웃 +10초 버퍼 적용, 응답 후 복원)
                notifyAuthProgressWithBuffer(currentSessions)

                // 3. 암호화 + RTDB 업데이트 + 관찰
                val sessionPayloads = currentSessions.associateWith { session ->
                    val currentSeq =
                        k2uSeqTracker.compute(session.sessionId) { _, prev -> (prev ?: 0) + 1 } ?: 1
                    encryptLandmark(successPrecheck.landmark, session, currentSeq)
                }

                val authResult = remoteAuthUseCase(sessionPayloads, preAuthTokens)
                if (authResult is SessionIdEvent.Success) {
                    winnerSessionId = authResult.sessionId
                }
                pendingAuthResult = mapAuthResult(authResult)
            } catch (e: Exception) {
                errorLog(TAG, "launchRemoteAuth error: $e")
                pendingAuthResult = handleAuthException(e)
            } finally {
                // 승리 세션만 제거, 실패 세션은 타임아웃까지 유지
                if (winnerSessionId != null) {
                    var removedWinner: SessionData? = null
                    _sessionIds.update { current ->
                        removedWinner = current.find { it.sessionId == winnerSessionId }
                        current.filterNot { it.sessionId == winnerSessionId }.toSet()
                    }

                    removedWinner?.let { session ->
                        cachedAuthTokens.remove(session.sessionId)
                        k2uSeqTracker.remove(session.sessionId)
                        sessionTimeoutJobs.remove(session.sessionId)?.cancel()
                        session.destroySecurely()
                    }
                }
                beaconBroadcaster.resume()
                // pendingAuthResult 세팅 후 플래그 해제 (순서 중요: happens-before)
                isRemoteAuthInFlight.set(false)
                isProcessingInFlight.set(false)
                warnLog(TAG, "백그라운드 인증 시퀀스 완료 sessionId size : ${_sessionIds.value.size}")
            }
        }
    }

    // ── 공통 유틸 (detection / phoneAuth 공유) ─────────────────────

    private fun encryptLandmark(
        landmark: FloatArray,
        session: SessionData,
        seq: Int
    ): EncryptedSessionPayload {
        val aadString = "${session.sessionId}:${seq}:k2u"
        debugLog(TAG, "aadString : $aadString")
        val aad = aadString.toByteArray(Charsets.UTF_8)

        val payloadDto = FaceVectorPayloadDto(
            vector = landmark,
            timestamp = System.currentTimeMillis()
        )

        val plainTextJson = encodeToString(payloadDto)
        val finalPayload = cryptoEngine.encrypt(
            plainText = plainTextJson,
            key = session.dkKiosk,
            aad = aad
        )
        return EncryptedSessionPayload(encryptedData = finalPayload, seq = seq)
    }

    private fun mapAuthResult(authResult: SessionIdEvent): GoPassAuthResult {
        return when (authResult) {
            is SessionIdEvent.Success -> {
                debugLog(TAG, "인증 성공 sessionId: ${authResult.sessionId}")
                GoPassAuthResult.Success(deviceId = authResult.deviceId)
            }
            is SessionIdEvent.Failed -> {
                debugLog(TAG, "인증 실패: ${authResult.reason}")
                val errorCode = if (authResult.reason == FaceAuthFailReason.TIMEOUT) {
                    ErrorCode.AUTH_TIMEOUT
                } else {
                    ErrorCode.AUTH_REJECTED
                }
                GoPassAuthResult.ServerAuthFailed(
                    message = errorCode.message ?: ErrorCode.AUTH_ERROR.message!!,
                    errorCode = errorCode
                )
            }
        }
    }

    private fun handleAuthException(e: Exception): GoPassAuthResult {
        val result = mapAuthExceptionToResult(e)
        val sdkException = e as? GoPassSdkException
            ?: GoPassSdkException.from(error = ErrorCode.INTERNAL_ERROR)
        errorLog(
            TAG,
            "인증 중 예외 발생: code=${sdkException.code}, causeCode=${sdkException.causeCode}, mapped=${result.errorCode.externalCode}, message=${sdkException.message}"
        )
        return result
    }

    private fun mapToSurfaceRotation(degrees: Int): Int {
        return when (degrees) {
            270 -> Surface.ROTATION_270
            0 -> Surface.ROTATION_0
            90 -> Surface.ROTATION_90
            180 -> Surface.ROTATION_180
            else -> Surface.ROTATION_270
        }
    }

    // ── Phone Auth Step 1: 랜드마크 추출 및 임시 보관 ──────────────────────

    /**
     * 얼굴 검증 → 랜드마크 추출 → 내부 보관 (번호 인증 전반부)
     * 성공 시 [GoPassAuthResult.Success]를 반환하며, 이후 [executePhoneAuth]를 호출하면 된다.
     */
    suspend fun prepareLandmarkForPhoneAuth(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotation: Int
    ): GoPassAuthResult = withContext(Dispatchers.Default) {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 preparePhoneAuth 요청은 거부됩니다.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.AUTH_ERROR,
                message = ErrorCode.AUTH_ERROR.message!!
            )
        }

        infoLog(TAG, "Phone Auth Step 1 (preparePhoneAuth) 호출")

        if (!networkStateProvider.isAvailable.value) {
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.NETWORK_ERROR,
                message = ErrorCode.NETWORK_ERROR.message!!
            )
        }

        if (!isProcessingInFlight.compareAndSet(false, true)) {
            return@withContext GoPassAuthResult.PrecheckGuide(listOf(FailReason.ALREADY_IN_PROGRESS))
        }

        try {
            val surfaceRotation = mapToSurfaceRotation(rotation)
            val precheckResult = prepareFaceAuthUseCase.execute(
                faceImage = faceImage,
                width = width,
                height = height,
                rotation = surfaceRotation
            )

            if (precheckResult is FaceAuthPrecheckResult.Failed) {
                return@withContext GoPassAuthResult.PrecheckGuide(precheckResult.reasons)
            }

            val successPrecheck = precheckResult as FaceAuthPrecheckResult.Success
            debugLog(TAG, "Phone Auth 랜드마크 추출 성공, size: ${successPrecheck.landmark.size}")

            clearPendingLandmark()
            pendingLandmark = successPrecheck.landmark.copyOf()
            landmarkTimestamp = System.currentTimeMillis()

            GoPassAuthResult.Success(deviceId = "")
        } finally {
            isProcessingInFlight.set(false)
        }
    }

    // ── Phone Auth Step 2: 세션 생성 + 랜드마크 업로드 + 인증 관찰 ──────

    /**
     * 보관된 랜드마크 + deviceId 로 세션 생성 → 암호화 전송 → 인증 결과 관찰 (번호 인증 후반부)
     * [prepareLandmarkForPhoneAuth]가 먼저 성공해야 하며, 30초 내 호출되어야 한다.
     */
    suspend fun executePhoneAuth(
        deviceId: String
    ): GoPassAuthResult = withContext(Dispatchers.Default) {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 submitPhoneAuth 요청은 거부됩니다.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.AUTH_ERROR,
                message = ErrorCode.AUTH_ERROR.message!!
            )
        }

        infoLog(TAG, "Phone Auth Step 2 (submitPhoneAuth) 호출")

        // 1. 랜드마크 유효성 검증
        val landmark = pendingLandmark ?: return@withContext GoPassAuthResult.ServerAuthFailed(
            errorCode = ErrorCode.AUTH_ERROR,
            message = ErrorCode.AUTH_ERROR.message!!
        )

        val elapsed = System.currentTimeMillis() - landmarkTimestamp
        if (elapsed > LANDMARK_EXPIRY_MILLIS) {
            clearPendingLandmark()
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.PHONE_AUTH_LANDMARK_EXPIRED,
                message = ErrorCode.PHONE_AUTH_LANDMARK_EXPIRED.message!!
            )
        }

        if (!networkStateProvider.isAvailable.value) {
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.NETWORK_ERROR,
                message = ErrorCode.NETWORK_ERROR.message!!
            )
        }

        if (!isProcessingInFlight.compareAndSet(false, true)) {
            return@withContext GoPassAuthResult.PrecheckGuide(listOf(FailReason.ALREADY_IN_PROGRESS))
        }

        var session: SessionData? = null
        var beaconPaused = false
        try {
            // 2. kiosk-initiated API 호출 → 세션 생성
            val payload = sessionRepository.requestSession(deviceId).getOrThrow()

            // 3. 세션 복호화 (encryptedDk → EphemeralAesKey)
            session = decryptAndCreateSessionData(
                sessionId = payload.sessionId,
                rtdbPath = payload.rtdbPath,
                encryptedDk = payload.encryptedDk,
                firebaseToken = payload.firebaseToken,
                expiresAtMillis = payload.expiresAtMillis,
                deviceId = deviceId
            )
            debugLog(TAG, "Phone Auth 세션 생성 완료: sessionId=${session.sessionId}")

            beaconBroadcaster.pause()
            beaconPaused = true

            // 4. 인증 + 랜드마크 암호화 + 5. kiosk_to_user 업데이트 + user_to_kiosk SSE 관찰
            val encryptedPayload = encryptLandmark(landmark, session, seq = 1)
            val preAuthTokens = remoteAuthUseCase.authenticateSessions(setOf(session))
            mapAuthResult(
                remoteAuthUseCase(
                    sessionPayloads = mapOf(session to encryptedPayload),
                    preAuthTokens = preAuthTokens,
                    timeoutMs = PHONE_AUTH_RESULT_TIMEOUT_MILLIS
                )
            )
        } catch (e: Exception) {
            errorLog(TAG, "executePhoneAuth error : $e")
            handleAuthException(e)
        } finally {
            clearPendingLandmark()
            session?.destroySecurely()
            isProcessingInFlight.set(false)
            if (beaconPaused) beaconBroadcaster.resume()
            warnLog(TAG, "Phone Auth 시퀀스 완료")
        }
    }

    // ── Phone Auth 유틸 ──────────────────────────────────────────────

    private fun clearPendingLandmark() {
        pendingLandmark.wipe()
        pendingLandmark = null
        landmarkTimestamp = 0L
    }

    /**
     * 오케스트레이터의 모든 자원을 정리합니다. (reset 용도)
     * * ⚠️ 주의: 이 메서드를 호출하면 내부 CoroutineScope가 취소되므로,
     * 이 인스턴스는 더 이상 사용할 수 없습니다. (재사용 시 코루틴 실행 무시됨)
     * 재시작이 필요한 경우 [AuthOrchestrator] 인스턴스를 새로 생성해야 합니다.
     * 단순히 SSE 연결만 끊으려면 [stopSessionCollection]을 사용하세요.
     */
    fun destroy() {
        if (isDestroyed) {
            warnLog(TAG, "AuthOrchestrator destroy 중복 호출은 무시됩니다.")
            return
        }

        isDestroyed = true
        stopSessionCollection()
        sessionTimeoutJobs.values.forEach { it.cancel() }
        sessionTimeoutJobs.clear()
        cachedAuthTokens.clear()
        k2uSeqTracker.clear()
        hasEstablishedSseConnection = false
        _sessionIds.value.forEach { session ->
            session.destroySecurely()
        }
        _sessionIds.value = emptySet()
        clearPendingLandmark()
        pendingAuthResult = null
        isRemoteAuthInFlight.set(false)
        isProcessingInFlight.set(false)
        remoteAuthUseCase.destroy()
        prepareFaceAuthUseCase.reset()
        orchestratorScope.coroutineContext[Job]?.cancel()
        warnLog(TAG, "AuthOrchestrator 전체 자원 정리 완료")
    }

    private fun SessionData.destroySecurely() {
        runCatching {
            val ephemeralKey = this.dkKiosk as? EphemeralAesKey
            if (ephemeralKey?.isDestroyed() == false) {
                ephemeralKey.destroy()
                debugLog(TAG, "세션 [${this.sessionId}] dkKiosk 메모리 안전 파기 완료")
            }
        }.onFailure { e ->
            errorLog(TAG, "세션 [${this.sessionId}] dkKiosk 파기 실패: ${e.message}")
        }
    }
}

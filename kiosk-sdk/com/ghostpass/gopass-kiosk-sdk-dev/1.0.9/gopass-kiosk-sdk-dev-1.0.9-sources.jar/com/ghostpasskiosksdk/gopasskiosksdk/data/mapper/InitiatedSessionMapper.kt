package com.ghostpasskiosksdk.gopasskiosksdk.data.mapper

import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.InitiatedSessionDto
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.InitiatedSessionPayload

internal fun InitiatedSessionDto.toDomain(): InitiatedSessionPayload {
    return InitiatedSessionPayload(
        sessionId = sessionId,
        rtdbPath = rtdbPath,
        encryptedDk = encryptedDk,
        firebaseToken = firebaseToken,
        expiresAtMillis = parseExpiresAtMillis(expiresAt)
    )
}

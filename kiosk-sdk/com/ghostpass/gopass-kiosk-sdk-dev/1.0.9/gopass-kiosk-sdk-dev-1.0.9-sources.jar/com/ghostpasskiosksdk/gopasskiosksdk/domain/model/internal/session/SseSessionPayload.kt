package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session

internal data class SseSessionPayload(
    val sessionId: String,
    val rtdbPath: String,
    val encryptedKioskDk: String,
    val firebaseToken: String,
    val expiresAtMillis: Long,
    val deviceId: String
)
package com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.SdkDiagnosticEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemoteStateChannelRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.DiagnosticEventBus
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

internal class ExecuteRemoteAuthUseCase (
    private val remoteChannelRepository: RemoteStateChannelRepository
) {
    companion object {
        val TAG = "RTDB 작업 ${BuildConfig.SIGNATURE}"
    }

    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun authenticateSessions(
        sessions: Set<SessionData>
    ): Map<SessionData, Result<AuthToken>> {
        infoLog(TAG, "🔐 세션 사전 인증 시작: ${sessions.size}개")
        return remoteChannelRepository.authenticateSessions(sessions)
    }

    suspend operator fun invoke(
        sessionPayloads: Map<SessionData, EncryptedSessionPayload>,
        preAuthTokens: Map<SessionData, Result<AuthToken>>,
        timeoutMs: Long = 5000L
    ): SessionIdEvent {
        infoLog(TAG, "👾 RTDB 업데이트 시작")

        val authenticatedTokens = mutableMapOf<SessionData, AuthToken>()

        preAuthTokens.forEach { (session, result) ->
            result.onSuccess { token ->
                authenticatedTokens[session] = token
            }.onFailure { e ->
                errorLog(TAG, "세션(${session.sessionId}) 인증 실패: ${e.message}")
                DiagnosticEventBus.emit {
                    SdkDiagnosticEvent.SessionAuthDropped(
                        sessionId = session.sessionId,
                        phase = "pre_auth_token",
                        errorDetail = e.toString()
                    )
                }
            }
        }

        if (authenticatedTokens.isEmpty()) {
            return SessionIdEvent.Failed(FaceAuthFailReason.UPDATE_FAILED)
        }

        // 인증된 세션만 RTDB 일괄 업데이트
        val authenticatedPayloads = sessionPayloads.filterKeys { it in authenticatedTokens }
        val updateStart = System.currentTimeMillis()
        val updateResults = remoteChannelRepository.updateKioskSecureData(authenticatedPayloads, authenticatedTokens)
        debugLog(TAG, "updateKioskSecureData 소요시간: ${System.currentTimeMillis() - updateStart}ms")

        val successSessions = mutableSetOf<SessionData>()
        val tokenMap = mutableMapOf<String, AuthToken>()

        updateResults.forEach { (session, result) ->
            result.onSuccess {
                successSessions.add(session)
                authenticatedTokens[session]?.let { token ->
                    tokenMap[session.sessionId] = token
                } ?: errorLog(TAG, "예상치 못한 null: ${session.sessionId}")
            }.onFailure { e ->
                errorLog(TAG, "세션(${session.sessionId}) 업데이트 실패: ${e.message}")
                DiagnosticEventBus.emit {
                    SdkDiagnosticEvent.SessionAuthDropped(
                        sessionId = session.sessionId,
                        phase = "rtdb_update",
                        errorDetail = e.toString()
                    )
                }
            }
        }

        if (successSessions.isEmpty()) {
            return SessionIdEvent.Failed(FaceAuthFailReason.UPDATE_FAILED)
        }

        var authEvent: SessionIdEvent = SessionIdEvent.Failed(FaceAuthFailReason.TIMEOUT)
        try {
            val sessionsForObserve = successSessions.toSet()
            val tokensForObserve = tokenMap.toMap()
            val expectedSeqMap = sessionsForObserve.mapNotNull { session ->
                sessionPayloads[session]?.let { payload -> session.sessionId to payload.seq }
            }.toMap()
            authEvent = remoteChannelRepository.observeSessionId(
                sessionIds = sessionsForObserve,
                tokenMap = tokensForObserve,
                expectedSeqMap = expectedSeqMap,
                timeoutMs = timeoutMs
            )
        } finally {
            val sessionsToClean = successSessions.toSet()
            val tokensForClean = tokenMap.toMap()
            debugLog(TAG, "[FINALLY] sessionsToClean=${sessionsToClean.size}, authEvent=$authEvent")
            logWinnerSession(authEvent)
            clearUserToKioskBackground(sessionsToClean, tokensForClean)
            clearKioskToUserBackground(sessionsToClean, tokensForClean)
            tokenMap.clear()
            successSessions.clear()
        }
        return authEvent
    }

    private fun logWinnerSession(authEvent: SessionIdEvent) {
        val winnerId = (authEvent as? SessionIdEvent.Success)?.sessionId
        if (winnerId != null) {
            debugLog(TAG, "승리 세션 확인: $winnerId")
        }
    }

    private fun clearUserToKioskBackground(
        sessions: Set<SessionData>,
        tokenMap: Map<String, AuthToken>
    ) {
        backgroundScope.launch {
            remoteChannelRepository.clearUserToKioskData(sessions, tokenMap)
        }
    }

    private fun clearKioskToUserBackground(
        sessions: Set<SessionData>,
        tokenMap: Map<String, AuthToken>
    ) {
        backgroundScope.launch {
            remoteChannelRepository.clearKioskToUserData(sessions, tokenMap)
        }
    }

    /**
     * 내부 백그라운드 스코프를 취소하여 진행 중인 RTDB 정리 코루틴을 정리합니다.
     * 호출 후 이 인스턴스의 백그라운드 작업은 더 이상 실행되지 않습니다.
     */
    fun destroy() {
        backgroundScope.coroutineContext[Job]?.cancel()
    }
}

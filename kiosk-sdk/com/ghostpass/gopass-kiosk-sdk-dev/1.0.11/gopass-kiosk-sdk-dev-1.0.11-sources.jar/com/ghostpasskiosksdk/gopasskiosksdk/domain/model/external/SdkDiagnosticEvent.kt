package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external

import androidx.annotation.Keep

@Keep
sealed class SdkDiagnosticEvent {
    abstract val timestamp: Long

    /** k2uSeqTracker.compute 호출 시 */
    @Keep
    data class SeqComputed(
        val sessionId: String,
        val previousSeq: Int?,
        val newSeq: Int,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** RTDB kiosk_to_user PATCH 결과 (세션별) */
    @Keep
    data class RtdbWriteResult(
        val sessionId: String,
        val seq: Int,
        val success: Boolean,
        val errorDetail: String? = null,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** RTDB 노드 DELETE 실행 */
    @Keep
    data class RtdbClearExecuted(
        val sessionId: String,
        val node: String,
        val success: Boolean,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** k2uSeqTracker 항목 제거됨 */
    @Keep
    data class SeqTrackerCleared(
        val sessionId: String,
        val lastKnownSeq: Int?,
        val reason: String,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** auth-progress API 호출 결과 */
    @Keep
    data class AuthProgressResult(
        val sessionIds: List<String>,
        val success: Boolean,
        val errorDetail: String? = null,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** 세션 사전 인증(Firebase signIn) 실패 */
    @Keep
    data class PreAuthFailed(
        val sessionId: String,
        val errorDetail: String?,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** SSE session-created 페이로드 처리 실패 (복호화/상태 업데이트 등) */
    @Keep
    data class SessionPayloadFailed(
        val sessionId: String,
        val errorDetail: String?,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** SESSION_SYNC 누락 세션 kiosk-info API 조회 실패 */
    @Keep
    data class KioskInfoFetchFailed(
        val sessionId: String,
        val errorDetail: String?,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** 인증 파이프라인에서 세션 제외됨 (토큰 없음, RTDB write 실패 등) */
    @Keep
    data class SessionAuthDropped(
        val sessionId: String,
        val phase: String,
        val errorDetail: String?,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()

    /** user_to_kiosk 관찰 중 에러 (SSE 파싱/복호화/연결 실패) */
    @Keep
    data class ObserveError(
        val sessionId: String,
        val reason: String,
        val errorDetail: String?,
        override val timestamp: Long = System.currentTimeMillis()
    ) : SdkDiagnosticEvent()
}

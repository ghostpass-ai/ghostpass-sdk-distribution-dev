package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode

sealed class GoPassAuthResult {
    // 1. 얼굴 인식 단계 피드백 (카메라 UI 가이드용)
    data class PrecheckGuide(val reasons: List<FailReason>) : GoPassAuthResult()

    // 2. 얼굴 검증 통과 후 서버 인증이 백그라운드에서 진행 중
    data object Authenticating : GoPassAuthResult()

    // 3. 서버 인증까지 완전히 통과했을 때 (최종 성공)
    data class Success(val deviceId: String) : GoPassAuthResult()

    // 4. 서버 인증 실패 (얼굴은 통과했으나 앱에서 거절, 타임아웃 등 네트워크 이슈)
    data class ServerAuthFailed(val message: String, val errorCode: ErrorCode) : GoPassAuthResult()
}
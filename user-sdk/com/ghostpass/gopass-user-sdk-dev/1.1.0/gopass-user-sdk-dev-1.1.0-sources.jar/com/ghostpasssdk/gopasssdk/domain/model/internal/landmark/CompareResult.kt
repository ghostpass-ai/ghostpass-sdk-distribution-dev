package com.ghostpasssdk.gopasssdk.domain.model.internal.landmark

internal data class CompareResult(
    val isSuccess: Boolean,
    val similarityScore: Float
)

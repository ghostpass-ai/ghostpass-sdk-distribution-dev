package com.ghostpasssdk.gopasssdk.data.engine.monitor

import android.bluetooth.le.ScanResult
import java.nio.ByteBuffer
import java.util.UUID

internal data class IBeaconData(
    val uuid: UUID,
    val major: Int,
    val minor: Int,
    val txPower: Int
)

internal object IBeaconParser {
    const val APPLE_COMPANY_ID = 0x004C

    fun parse(result: ScanResult): IBeaconData? {
        val scanRecord = result.scanRecord ?: return null
        val manufacturerData = scanRecord.getManufacturerSpecificData(APPLE_COMPANY_ID) ?: return null
        return parse(manufacturerData)
    }

    fun parse(manufacturerData: ByteArray): IBeaconData? {
        // iBeacon manufacturer specific data (Apple company ID 이후):
        // Byte 0: 비콘 타입 (0x02)
        // Byte 1: 데이터 길이 (0x15 = 21)
        // Bytes 2-17: UUID (16 bytes)
        // Bytes 18-19: Major (2 bytes, big-endian)
        // Bytes 20-21: Minor (2 bytes, big-endian)
        // Byte 22: TX Power (1 byte, signed)
        if (manufacturerData.size < 23) return null
        if (manufacturerData[0] != 0x02.toByte() || manufacturerData[1] != 0x15.toByte()) return null

        val uuidBuffer = ByteBuffer.wrap(manufacturerData, 2, 16)
        val uuid = UUID(uuidBuffer.long, uuidBuffer.long)

        val major = ((manufacturerData[18].toInt() and 0xFF) shl 8) or
                (manufacturerData[19].toInt() and 0xFF)
        val minor = ((manufacturerData[20].toInt() and 0xFF) shl 8) or
                (manufacturerData[21].toInt() and 0xFF)
        val txPower = manufacturerData[22].toInt()

        return IBeaconData(uuid, major, minor, txPower)
    }
}

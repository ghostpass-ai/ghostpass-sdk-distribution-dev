package com.ghostpasssdk.gopasssdk.core.security.infra

import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager

internal class LocalDataEncryptor(
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager
) {
    fun encrypt(plainText: String): String {
        return encryptWithAlias(plainText, KeyManager.LOCAL_ID_KEY_ALIAS)
    }

    fun decrypt(encryptedBase64: String): String {
        return decryptWithAlias(encryptedBase64, KeyManager.LOCAL_ID_KEY_ALIAS)
    }

    fun decryptLegacy(encryptedBase64: String): String {
        return decryptWithAlias(encryptedBase64, KeyManager.MASTER_KEY_ALIAS)
    }

    fun encryptStrongBox(plainText: String): String {
        return encryptWithAlias(plainText, KeyManager.MASTER_KEY_ALIAS)
    }

    fun decryptStrongBox(encryptedBase64: String): String {
        return decryptWithAlias(encryptedBase64, KeyManager.MASTER_KEY_ALIAS)
    }

    private fun encryptWithAlias(plainText: String, alias: String): String {
        val key = keyManager.getSecretKey(alias)
        val emptyAad = ByteArray(0)
        return cryptoEngine.encrypt(plainText, key, emptyAad)
    }

    private fun decryptWithAlias(encryptedBase64: String, alias: String): String {
        val key = keyManager.getSecretKey(alias)
        val emptyAad = ByteArray(0)
        val decryptedBytes = cryptoEngine.decryptData(key, encryptedBase64, emptyAad)
        return String(decryptedBytes, Charsets.UTF_8)
    }
}

package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.AuthToken
import com.ghostpasssdk.gopasssdk.domain.model.internal.landmark.FaceVectorPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.utils.infoLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

internal class ProcessSessionUseCase(
    private val realtimeSessionRepository: RealtimeSessionRepository
) {

    companion object {
        private val TAG = "ProcessSessionUseCase ${BuildConfig.SIGNATURE}"
    }

    /**
     * Firebase 인증을 선행 실행한다. 세션 복호화 직후 async로 호출하여
     * 세션 셋업과 병렬로 인증 토큰을 획득한다.
     */
    suspend fun preloadFirebaseAuth(firebaseToken: String): AuthToken =
        withContext(Dispatchers.IO) {
            realtimeSessionRepository.authenticate(firebaseToken)
        }

    suspend fun execute(
        session: DecryptedSession,
        preloadedAuthToken: AuthToken? = null
    ): Pair<Flow<FaceVectorPayload>, String> =
        withContext(Dispatchers.IO) {
            val authToken = preloadedAuthToken ?: run {
                infoLog(TAG, "1️⃣ 실시간 세션(REST) 로그인 시도...")
                realtimeSessionRepository.authenticate(session.firebaseToken).also {
                    infoLog(TAG, "   -> 로그인 성공! ID Token 획득")
                }
            }

            infoLog(TAG, "2️⃣ RTDB 경로 SSE 관찰 시작... (상태값 변경 대기 중)")
            val facePayloadFlow = realtimeSessionRepository.observeAndDecryptFacePayload(
                rtdbPath = session.rtdbPath,
                idToken = authToken.idToken,
                sessionId = session.sessionId,
                dkUser = session.dkUser
            )

            return@withContext Pair(facePayloadFlow, authToken.idToken)
        }
}
package com.ghostpasssdk.gopasssdk.data.api

import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.HEADER_SIGNED_CONTEXT
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.SIGNED_CONTEXT_SESSION
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResponse
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionDto
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionRequest
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionResultDto
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionResultRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path

internal interface SessionApi {
    companion object {
        private const val PREFIX = "api/v1"
    }

    @Headers("${HEADER_SIGNED_CONTEXT}: ${SIGNED_CONTEXT_SESSION}")
    @POST("${PREFIX}/sessions")
    suspend fun requestSession(@Body body: SessionRequest): Response<ApiResponse<SessionDto>>

    @Headers("${HEADER_SIGNED_CONTEXT}: ${SIGNED_CONTEXT_SESSION}")
    @DELETE("${PREFIX}/sessions/{sessionId}")
    suspend fun deleteSession(@Path("sessionId") sessionId: String): Response<ApiResponse<Unit>>

    @Headers("${HEADER_SIGNED_CONTEXT}: ${SIGNED_CONTEXT_SESSION}")
    @POST("${PREFIX}/sessions/{sessionId}/result")
    suspend fun submitSessionResult(
        @Path("sessionId") sessionId: String,
        @Body body: SessionResultRequest
    ): Response<ApiResponse<SessionResultDto>>
}

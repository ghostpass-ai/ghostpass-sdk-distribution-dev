package com.ghostpasssdk.gopasssdk.core.security.domain

import java.security.PrivateKey
import javax.crypto.SecretKey


internal interface KeyManager {
    companion object {
        const val HMAC_ALIAS = "GP_HMAC_KEY"
        const val TRANSPORT_ALIAS = "GP_TRANSPORT_KEY"
        const val MASTER_KEY_ALIAS = "GP_MASTER_KEY"
        const val LOCAL_ID_KEY_ALIAS = "GP_LOCAL_ID_KEY"
    }

    /**
     * 지정된 별칭(Alias)에 해당하는 비밀키(SecretKey)를 가져옵니다.
     * @throws GoPassSdkException 키가 존재하지 않을 경우 발생
     */
    fun getSecretKey(alias: String): SecretKey

    /**
     * 외부에서 전달받은 비밀키(HMAC, TRANSPORT 등)를 안전한 저장소에 주입(Import)합니다.
     */
    fun importSecretKey(alias: String, keyBytes: ByteArray)

    /**
     * ECDH(타원곡선 디피-헬만) 키 쌍을 생성하고, 생성된 공개키(Public Key)를 Base64 문자열로 반환합니다.
     * 개인키(Private Key)는 내부 저장소에 안전하게 보관됩니다.
     */
    fun generateEcdhKeyPair(): String

    /**
     * 지정된 별칭의 키가 저장소에 존재하는지 확인합니다.
     */
    fun hasSecretKey(alias: String): Boolean

    /**
     * 내부 저장소에 보관된 ECDH 개인키(Private Key)를 가져옵니다.
     */
    fun getPrivateKey(): PrivateKey

    /**
     * 지정된 별칭의 키를 저장소에서 영구적으로 삭제합니다.
     */
    fun deleteKey(alias: String)
}

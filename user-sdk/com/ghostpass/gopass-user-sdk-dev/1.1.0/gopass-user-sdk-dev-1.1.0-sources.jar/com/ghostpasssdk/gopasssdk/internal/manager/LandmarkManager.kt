package com.ghostpasssdk.gopasssdk.internal.manager

import android.view.Surface
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.model.external.BioDataFrameStatus
import com.ghostpasssdk.gopasssdk.domain.model.external.HasBioDataResult
import com.ghostpasssdk.gopasssdk.domain.model.external.CaptureGuide
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceExtractResult
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.FaceRegisterUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StartProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StopProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.infoLog
import kotlin.coroutines.cancellation.CancellationException


internal class LandmarkManager(
    private val faceRegisterUseCase: FaceRegisterUseCase,
    private val landmarkRepository: LandmarkRepository,
    private val identityRepository: IdentityRepository,
    private val startProximityMonitorUseCase: StartProximityMonitorUseCase,
    private val stopProximityMonitorUseCase: StopProximityMonitorUseCase,
    private val proximityObserver: ProximityObserver
) {
    companion object {
        private val TAG = "LandmarkManager ${BuildConfig.SIGNATURE}"
    }

    suspend fun saveLandmark(
        faceImage: ByteArray,
        width: Int,
        height: Int,
        rotation: Int
    ): BioDataFrameStatus {

        if (landmarkRepository.hasLandmark()) {
            ensureProximityMonitoringStarted()
            return BioDataFrameStatus.Success
        }

        val surfaceRotation =  mapToSurfaceRotation(rotation)

        val extractResult = faceRegisterUseCase.execute(
            faceImage = faceImage,
            width = width,
            height = height,
            rotation = surfaceRotation
        )

        return when (extractResult) {
            is FaceExtractResult.Success -> {
                landmarkRepository.saveLandmark(extractResult.landmark)
                try {
                    identityRepository.saveRegisteredAt(System.currentTimeMillis())
                } catch (e: Exception) {
                    landmarkRepository.deleteLandmark()
                    throw e
                }
                ensureProximityMonitoringStarted()
                BioDataFrameStatus.Success
            }

            is FaceExtractResult.Continue -> {
                if (extractResult.reason == CaptureGuide.ALREADY_COMPLETED) {
                    BioDataFrameStatus.Success
                } else {
                    BioDataFrameStatus.ContinueCapture(extractResult.reason)
                }
            }
        }
    }

    suspend fun deleteLandmark(): Boolean {
        infoLog(TAG, "[REMOVE_BIO] 생체 데이터 삭제 시작")

        // 1. 랜드마크 파일 삭제 (인증 수단 즉시 제거 — critical)
        val isDeleted = landmarkRepository.deleteLandmark()
        infoLog(TAG, "[REMOVE_BIO] 랜드마크 파일 삭제 결과: $isDeleted")

        if (isDeleted) {
            // 2. 등록 타임스탬프 제거
            identityRepository.clearRegisteredAt()
            // 3. 얼굴 등록 상태 초기화
            faceRegisterUseCase.resetCompletedState()
            // 4. 세션 전체 초기화 (서버 삭제 + 로컬 정리 — handleServiceDestroyed 전에 ID 캡처)
            proximityObserver.purgeAllSessions()
            // 5. 비콘 서비스 중지 (handleServiceDestroyed 와도 이미 정리 완료)
            try {
                val isStopped = stopProximityMonitorUseCase.execute()
                infoLog(TAG, "[REMOVE_BIO] 비콘 스캔 중지 결과: $isStopped")
            } catch (e: Exception) {
                errorLog(TAG, "[REMOVE_BIO] 비콘 스캔 중지 중 에러 발생: ${e.message}")
            }
        }

        infoLog(TAG, "[REMOVE_BIO] 생체 데이터 삭제 완료")
        return isDeleted
    }

    fun getHasBioDataResult(): HasBioDataResult = landmarkRepository.getHasBioDataResult()

    private suspend fun ensureProximityMonitoringStarted() {
        try {
            val isStarted = startProximityMonitorUseCase.execute()
            debugLog(TAG, "비콘 스캔 시작 요청 결과: $isStarted")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "비콘 스캔 시작 실패 (등록 결과에 영향 없음): ${e.message}")
        }
    }

    private fun mapToSurfaceRotation(degrees: Int): Int {
        return when (degrees) {
            270 -> Surface.ROTATION_270
            0 -> Surface.ROTATION_0
            90 -> Surface.ROTATION_90
            180 -> Surface.ROTATION_180
            else -> Surface.ROTATION_270
        }
    }

}

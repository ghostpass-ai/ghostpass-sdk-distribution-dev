package com.ghostpasssdk.gopasssdk.core.security.infra

import android.annotation.SuppressLint
import com.ghostpasssdk.gopasssdk.BuildConfig
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.security.keystore.KeyProtection
import android.security.keystore.StrongBoxUnavailableException
import android.util.Base64
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager.Companion.HMAC_ALIAS
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager.Companion.LOCAL_ID_KEY_ALIAS
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager.Companion.MASTER_KEY_ALIAS
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.utils.errorLog
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.spec.ECGenParameterSpec
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec

internal class AndroidKeyManager(
    private val context: Context
) : KeyManager {
    companion object {
        private val TAG = "KeyManager ${BuildConfig.SIGNATURE}"
        private const val PROVIDER = "AndroidKeyStore"
        private const val ECDH_ALIAS = "GP_ECDH_KEY"
        private const val AES_KEY_SIZE = 256
        private const val EC_CURVE_NAME = "secp256r1"
    }

    private val keyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    // API 31 미만 기기에서 ECDH 키쌍을 메모리에 임시 보관
    private var tempEcdhPrivateKey: PrivateKey? = null

    override fun getSecretKey(alias: String): SecretKey {
        return (keyStore.getKey(alias, null) as? SecretKey)
            ?: when (alias) {
                MASTER_KEY_ALIAS -> generateAesKey(alias, useStrongBox = true)
                LOCAL_ID_KEY_ALIAS -> generateAesKey(alias, useStrongBox = false)
                else -> {
                    errorLog(TAG, "$alias 키를 찾을 수 없습니다")
                    throw GoPassException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        internalCode = InternalErrorCode.SECRET_KEY_NOT_FOUND
                    )
                }
            }
    }

    private fun generateAesKey(alias: String, useStrongBox: Boolean): SecretKey {
        return try {
            KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER).apply {
                init(
                    KeyGenParameterSpec.Builder(
                        alias,
                        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(AES_KEY_SIZE)
                        .apply { if (useStrongBox) setStrongBoxIfPossible() }
                        .build())
            }.generateKey()
        } catch (e: Exception) {
            errorLog(TAG, "$alias AES 키 생성 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INTERNAL_ERROR,
                internalCode = InternalErrorCode.MASTER_KEY_GENERATION_FAILED
            )
        }
    }

    override fun importSecretKey(alias: String, keyBytes: ByteArray) {
        try {
            val secretKey = SecretKeySpec(
                keyBytes,
                if (alias == HMAC_ALIAS) KeyProperties.KEY_ALGORITHM_HMAC_SHA256
                else KeyProperties.KEY_ALGORITHM_AES
            )

            val purpose = if (alias == HMAC_ALIAS) KeyProperties.PURPOSE_SIGN
            else KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT

            val builder = KeyProtection.Builder(purpose)
                .apply { setStrongBoxIfPossible() }
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)

            keyStore.setEntry(alias, KeyStore.SecretKeyEntry(secretKey), builder.build())

        } catch (@SuppressLint("NewApi") e: StrongBoxUnavailableException) {
            // 하드웨어 칩셋(Secure Enclave/StrongBox) 지원 불가 또는 용량 부족
            errorLog(TAG, "$alias Secure Enclave 키 생성/저장 실패: $e")
            val causeCode = if (alias == HMAC_ALIAS) InternalErrorCode.HMAC_KEY_SE_KEY_FAILED
            else InternalErrorCode.TRANSPORT_KEY_SE_KEY_FAILED

            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = causeCode
            )
        } catch (e: Exception) {
            // 그 외 Keystore 저장 실패
            errorLog(TAG, "$alias 일반 Keystore 저장 실패: $e")
            val causeCode = if (alias == HMAC_ALIAS) InternalErrorCode.HMAC_KEY_SAVE_FAILED
            else InternalErrorCode.TRANSPORT_KEY_SAVE_FAILED

            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = causeCode
            )
        }
    }

    override fun generateEcdhKeyPair(): String {
        return try {
            val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, PROVIDER)

            val purpose = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                KeyProperties.PURPOSE_AGREE_KEY
            } else {
                // API 31 미만은 AGREE_KEY 상수 존재 X
                KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
            }

            val spec = KeyGenParameterSpec.Builder(ECDH_ALIAS, purpose)
                .setAlgorithmParameterSpec(ECGenParameterSpec(EC_CURVE_NAME))
                .build()

            kpg.initialize(spec)

            val keyPair = kpg.generateKeyPair()

            // [수정됨] API 31 미만일 경우 메모리에 Private Key를 임시 보관하는 로직 추가
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                tempEcdhPrivateKey = keyPair.private
            }

            Base64.encodeToString(keyPair.public.encoded, Base64.NO_WRAP)

        } catch (e: Exception) {
            errorLog(TAG, "ECDH 키 생성 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.ECDH_KEY_GENERATION_FAILED
            )
        }
    }

    override fun hasSecretKey(alias: String): Boolean {
        return keyStore.containsAlias(alias) && keyStore.isKeyEntry(alias)
    }

    override fun getPrivateKey(): PrivateKey {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            val key = tempEcdhPrivateKey ?: throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.PRIVATE_KEY_NOT_FOUND
            )
            tempEcdhPrivateKey = null
            return key
        }
        return try {
            keyStore.getKey(ECDH_ALIAS, null) as PrivateKey
        } catch (e: Exception) {
            errorLog(TAG,"ECDH 개인키를 찾을 수 없습니다.: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.PRIVATE_KEY_NOT_FOUND
            )
        }
    }

    override fun deleteKey(alias: String) {
        if (keyStore.containsAlias(alias)) {
            keyStore.deleteEntry(alias)
        }
    }

    private fun <T> T.setStrongBoxIfPossible(): T {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val hasStrongBox = context.packageManager.hasSystemFeature(
                PackageManager.FEATURE_STRONGBOX_KEYSTORE
            )
            if (hasStrongBox) {
                when (this) {
                    is KeyGenParameterSpec.Builder -> {
                        // 키 생성은 API 28부터 StrongBox 지원
                        this.setIsStrongBoxBacked(true)
                    }

                    is KeyProtection.Builder -> {
                        // 외부 키 주입(Import)은 API 31(S)부터 StrongBox 지원
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            this.setIsStrongBoxBacked(true)
                        }
                    }
                }
            }
        }
        return this
    }
}

package com.ghostpasssdk.gopasssdk.domain.usecase.session

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

internal class SessionSequenceTracker {

    private val sequences = ConcurrentHashMap<String, AtomicInteger>()

    /**
     * kioskSeq가 현재 로컬 seq보다 큰 경우에만 갱신하고 true를 반환한다.
     * 같거나 작으면 리플레이/stale로 간주하여 false를 반환한다.
     */
    fun tryAdvance(sessionId: String, kioskSeq: Int): Boolean {
        val counter = sequences.computeIfAbsent(sessionId) { AtomicInteger(0) }
        val previous = counter.getAndUpdate { current ->
            if (kioskSeq > current) kioskSeq else current
        }
        return kioskSeq > previous
    }

    fun currentSeq(sessionId: String): Int {
        return sequences[sessionId]?.get() ?: 0
    }

    fun clear(sessionId: String) {
        sequences.remove(sessionId)
    }

    fun destroy() {
        sequences.clear()
    }
}

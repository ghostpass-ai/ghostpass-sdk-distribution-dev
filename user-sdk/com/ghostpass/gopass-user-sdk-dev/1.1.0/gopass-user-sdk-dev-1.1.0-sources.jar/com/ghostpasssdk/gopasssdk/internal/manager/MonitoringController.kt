package com.ghostpasssdk.gopasssdk.internal.manager

import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.repository.storage.MonitoringPolicyRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StartProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StopProximityMonitorUseCase

/**
 * 호스트앱의 명시적 startMonitoring/stopMonitoring 요청 처리 전담.
 *
 * 호스트 경로에서만 억제 flag를 조작한다 — SDK 내부의 start/stop
 * (initialize, reset, removeBioData)은 이 클래스를 거치지 않고
 * UseCase를 직접 호출하므로 flag가 변경되지 않는다.
 */
internal class MonitoringController(
    private val monitoringPolicyRepository: MonitoringPolicyRepository,
    private val startMonitorUseCase: StartProximityMonitorUseCase,
    private val stopMonitorUseCase: StopProximityMonitorUseCase
) {

    @Throws(GoPassException::class)
    suspend fun startMonitoring() {
        // 호스트의 명시적 start — 억제 의도를 start 성공 여부와 무관하게 먼저 철회
        // (권한 오류 등으로 start가 실패해도, 이후 내부 start가 정상 동작해야 함)
        monitoringPolicyRepository.clearSuppression()
        startMonitorUseCase.execute()
    }

    @Throws(GoPassException::class)
    suspend fun stopMonitoring() {
        // 호스트의 명시적 stop — FGS 종료 성공 여부와 무관하게 억제 의도를 먼저 기록
        // (stop이 타임아웃돼도 내부 start 억제 + 서비스 방어 체크가 뒷수습)
        monitoringPolicyRepository.suppressByHost()
        stopMonitorUseCase.execute()
    }
}

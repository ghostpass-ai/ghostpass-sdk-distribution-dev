package com.ghostpasssdk.gopasssdk.data.engine.face

import com.alcherainc.facesdk.type.InputImage
import com.ghostpasssdk.gopasssdk.data.engine.face.capability.FaceLivenessCapability
import com.ghostpasssdk.gopasssdk.data.engine.face.wrapper.AlcheraDetectedFace
import com.ghostpasssdk.gopasssdk.data.engine.face.wrapper.AlcheraImageFrame
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceLivenessEngine
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceEngineTypes
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.LivenessResult
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal class AlcheraLivenessAdapter(
    private val capability: FaceLivenessCapability
) : FaceLivenessEngine {

    private companion object {
        private val TAG = "AlcheraLivenessAdapter ${BuildConfig.SIGNATURE}"
        private const val LIVENESS_QUALITY = 63.96f
        private const val VALID_FACE_DETECT_LIVENESS_VALUE = 0.9030f
        private const val LIVENESS_TX_FAIL_LIMIT = 3
    }

    private val mutex = Mutex()
    private var livenessTxFailCount = 0
    private val livenessArray = ArrayList<InputImage>(4)

    override suspend fun evaluate(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): LivenessResult = mutex.withLock {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        val faceQuality = capability.estimateFaceQuality(nativeImage, nativeFace, false)
        debugLog(TAG, "livenessArray : ${livenessArray.size} faceQuality : ${faceQuality.quality}")

        if (faceQuality.quality >= LIVENESS_QUALITY) {
            debugLog(TAG,"퀄리티 초과로 add")
            // 추출한 원본 객체를 배열에 저장
            livenessArray.add(nativeImage)
        }

        // 아직 4장 안 모임
        if (livenessArray.size < 4) return LivenessResult.Collecting

        val resultLive = capability.checkLivenessFromBGRImage(
            livenessArray[0],
            livenessArray[1],
            livenessArray[2],
            livenessArray[3],
            nativeFace
        )

        // 이번 4장 평가 끝 -> 다음 평가 준비
        livenessArray.clear()
        capability.resetInputBGRLivenessChecker()

        val passed = resultLive.confidence > VALID_FACE_DETECT_LIVENESS_VALUE
        debugLog(TAG, "PAD 결과 : $passed, confidence = ${resultLive.confidence}")

        return if (passed) {
            livenessTxFailCount = 0
            LivenessResult.Passed
        } else {
            livenessTxFailCount += 1

            if (livenessTxFailCount >= LIVENESS_TX_FAIL_LIMIT) {
                livenessTxFailCount = 0
                LivenessResult.TxFailed
            } else {
                LivenessResult.NotConfirmed // confidence 미달로 재시도
            }
        }
    }

}
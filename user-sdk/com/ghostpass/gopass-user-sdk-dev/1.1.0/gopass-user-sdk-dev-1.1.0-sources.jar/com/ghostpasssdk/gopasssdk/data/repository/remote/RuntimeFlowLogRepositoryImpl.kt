package com.ghostpasssdk.gopasssdk.data.repository.remote

import android.os.Build
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.core.network.utils.safeApiCallNoData
import com.ghostpasssdk.gopasssdk.data.api.RuntimeFlowLogApi
import com.ghostpasssdk.gopasssdk.data.dto.errorlog.RuntimeFlowLogRequest
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RuntimeFlowLogRepository

internal class RuntimeFlowLogRepositoryImpl(
    private val runtimeFlowLogApi: RuntimeFlowLogApi
) : RuntimeFlowLogRepository {

    override suspend fun reportError(
        sessionId: String?,
        errorCode: String,
        errorMessage: String
    ): ApiResult<Unit> {
        val request = RuntimeFlowLogRequest(
            sessionId = sessionId,
            errorCode = errorCode,
            errorMessage = errorMessage,
            sdkVersion = BuildConfig.SDK_VERSION,
            platform = PLATFORM,
            osVersion = Build.VERSION.RELEASE,
            clientTimestamp = System.currentTimeMillis()
        )
        return safeApiCallNoData { runtimeFlowLogApi.reportErrorLog(request) }
    }

    companion object {
        private const val PLATFORM = "ANDROID"
    }
}

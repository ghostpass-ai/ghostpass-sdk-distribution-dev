package com.ghostpasssdk.gopasssdk.domain.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult

internal interface RuntimeFlowLogRepository {
    suspend fun reportError(
        sessionId: String?,
        errorCode: String,
        errorMessage: String
    ): ApiResult<Unit>
}

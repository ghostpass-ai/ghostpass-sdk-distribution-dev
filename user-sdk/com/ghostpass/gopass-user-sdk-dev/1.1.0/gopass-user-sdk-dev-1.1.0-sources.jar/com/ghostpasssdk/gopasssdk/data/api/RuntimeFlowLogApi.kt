package com.ghostpasssdk.gopasssdk.data.api

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResponse
import com.ghostpasssdk.gopasssdk.data.dto.errorlog.RuntimeFlowLogRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

internal interface RuntimeFlowLogApi {
    companion object {
        private const val PREFIX = "api/v1/sdk"
    }

    @POST("$PREFIX/error-logs")
    suspend fun reportErrorLog(@Body body: RuntimeFlowLogRequest): Response<ApiResponse<Unit>>
}

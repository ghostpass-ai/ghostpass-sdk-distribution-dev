package com.ghostpasssdk.gopasssdk.core.network.utils

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.coroutines.delay

private val TAG = "RetryApiCall ${BuildConfig.SIGNATURE}"

/**
 * [ApiResult]를 반환하는 API 호출을 지수 백오프로 재시도한다.
 *
 * @param maxRetries 최대 재시도 횟수 (기본 3)
 * @param initialDelayMs 첫 번째 재시도 전 대기 시간 (기본 1000ms)
 * @param shouldRetry 재시도 조건 판별. 기본값은 NetworkError만 재시도
 * @param call 실행할 API 호출
 * @return 최종 [ApiResult]
 */
internal suspend fun <T> retryApiCall(
    maxRetries: Int = 3,
    initialDelayMs: Long = 1_000L,
    shouldRetry: (ApiResult<T>) -> Boolean = { it is ApiResult.NetworkError },
    call: suspend () -> ApiResult<T>
): ApiResult<T> {
    var delayMs = initialDelayMs

    for (attempt in 1..maxRetries) {
        val result = call()

        if (result is ApiResult.Success || !shouldRetry(result)) {
            return result
        }

        if (attempt < maxRetries) {
            warnLog(TAG, "API 재시도 예정 ($attempt/$maxRetries), ${delayMs}ms 후")
            delay(delayMs)
            delayMs *= 2
        } else {
            errorLog(TAG, "API 최종 실패 (${maxRetries}회 시도)")
        }
    }

    return call()
}

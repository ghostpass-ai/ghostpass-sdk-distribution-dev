package com.ghostpasssdk.gopasssdk.data.repository.storage

import android.content.Context
import com.ghostpasssdk.gopasssdk.BuildConfig
import androidx.core.content.edit
import com.ghostpasssdk.gopasssdk.core.security.infra.LocalDataEncryptor
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog

internal class IdentityRepositoryImpl(
    context: Context,
    private val localDataEncryptor: LocalDataEncryptor
) : IdentityRepository {

    companion object {
        private val TAG = "IdentityRepositoryImpl ${BuildConfig.SIGNATURE}"
        private const val PREF_NAME = "user_identity_prefs"

        // Legacy pref keys (MASTER_KEY / StrongBox 암호화)
        private const val PREF_API_KEY = "api_key"
        private const val PREF_BEACON_UUID = "beacon_uuid"
        private const val PREF_INSTALL_ID = "install_id"
        private const val PREF_DEVICE_ID = "device_id"
        private const val PREF_IDENTITY_ID = "identity_id"
        private const val PREF_REGISTERED_AT = "registered_at"

        // V2 pref keys (LOCAL_ID_KEY / TEE 암호화)
        private const val PREF_API_KEY_V2 = "api_key_v2"
        private const val PREF_BEACON_UUID_V2 = "beacon_uuid_v2"
        private const val PREF_INSTALL_ID_V2 = "install_id_v2"
        private const val PREF_DEVICE_ID_V2 = "device_id_v2"
        private const val PREF_IDENTITY_ID_V2 = "identity_id_v2"
        private const val PREF_REGISTERED_AT_V2 = "registered_at_v2"
    }

    private val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    // ==========================================
    // Save Methods — TEE 키로 v2 슬롯에 저장
    // ==========================================

    override fun saveApiKey(apiKey: String) {
        saveField(
            plainText = apiKey,
            prefKey = PREF_API_KEY_V2,
            label = "API KEY",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            encryptFailedCode = InternalErrorCode.API_KEY_ENCRYPT_FAILED,
            saveFailedCode = InternalErrorCode.API_KEY_SAVE_FAILED,
            systemExceptionCode = InternalErrorCode.API_KEY_SYSTEM_EXCEPTION
        )
    }

    override fun saveBeaconUuid(beaconUuid: String) {
        saveField(
            plainText = beaconUuid,
            prefKey = PREF_BEACON_UUID_V2,
            label = "BEACON UUID",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            encryptFailedCode = InternalErrorCode.BEACON_UUID_ENCRYPT_FAILED,
            saveFailedCode = InternalErrorCode.BEACON_UUID_SAVE_FAILED,
            systemExceptionCode = InternalErrorCode.BEACON_UUID_SYSTEM_EXCEPTION
        )
    }

    override fun saveInstallId(installId: String) {
        saveField(
            plainText = installId,
            prefKey = PREF_INSTALL_ID_V2,
            label = "INSTALL ID",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            encryptFailedCode = InternalErrorCode.INSTALL_ID_ENCRYPT_FAILED,
            saveFailedCode = InternalErrorCode.INSTALL_ID_SAVE_FAILED,
            systemExceptionCode = InternalErrorCode.INSTALL_ID_SYSTEM_EXCEPTION
        )
    }

    override fun saveDeviceId(deviceId: String) {
        saveField(
            plainText = deviceId,
            prefKey = PREF_DEVICE_ID_V2,
            label = "DEVICE ID",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            encryptFailedCode = InternalErrorCode.DEVICE_ID_ENCRYPT_FAILED,
            saveFailedCode = InternalErrorCode.DEVICE_ID_SAVE_FAILED,
            systemExceptionCode = InternalErrorCode.DEVICE_ID_SYSTEM_EXCEPTION
        )
    }

    override fun saveIdentityId(identityId: String) {
        saveField(
            plainText = identityId,
            prefKey = PREF_IDENTITY_ID_V2,
            label = "IDENTITY ID",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            encryptFailedCode = InternalErrorCode.IDENTITY_ID_ENCRYPT_FAILED,
            saveFailedCode = InternalErrorCode.IDENTITY_ID_SAVE_FAILED,
            systemExceptionCode = InternalErrorCode.IDENTITY_ID_SYSTEM_EXCEPTION
        )
    }

    override fun saveRegisteredAt(registeredAt: Long) {
        saveField(
            plainText = registeredAt.toString(),
            prefKey = PREF_REGISTERED_AT_V2,
            label = "REGISTERED_AT",
            errorCode = ErrorCode.REGISTER_BIO_DATA_FAILED,
            encryptFailedCode = InternalErrorCode.BIO_DATA_ENCRYPT_FAILED,
            saveFailedCode = InternalErrorCode.BIO_DATA_SAVE_FAILED,
            systemExceptionCode = InternalErrorCode.BIO_DATA_SAVE_FAILED
        )
    }

    // ==========================================
    // Get Methods — v2(TEE) 우선, legacy fallback + 마이그레이션
    // ==========================================

    override fun getApiKey(): String? {
        val result = getField(
            v2PrefKey = PREF_API_KEY_V2,
            legacyPrefKey = PREF_API_KEY,
            label = "API KEY",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            decryptFailedCode = InternalErrorCode.API_KEY_DECRYPT_FAILED
        )
        migrateAllLegacyFieldsIfNeeded()
        return result
    }

    override fun getBeaconUuid(): String? {
        return getField(
            v2PrefKey = PREF_BEACON_UUID_V2,
            legacyPrefKey = PREF_BEACON_UUID,
            label = "BEACON UUID",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            decryptFailedCode = InternalErrorCode.BEACON_UUID_DECRYPT_FAILED
        )
    }

    override fun getInstallId(): String? {
        return getField(
            v2PrefKey = PREF_INSTALL_ID_V2,
            legacyPrefKey = PREF_INSTALL_ID,
            label = "INSTALL ID",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            decryptFailedCode = InternalErrorCode.INSTALL_ID_DECRYPT_FAILED
        )
    }

    override fun getDeviceId(): String? {
        return getField(
            v2PrefKey = PREF_DEVICE_ID_V2,
            legacyPrefKey = PREF_DEVICE_ID,
            label = "DEVICE ID",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            decryptFailedCode = InternalErrorCode.DEVICE_ID_DECRYPT_FAILED
        )
    }

    override fun getIdentityId(): String? {
        return getField(
            v2PrefKey = PREF_IDENTITY_ID_V2,
            legacyPrefKey = PREF_IDENTITY_ID,
            label = "IDENTITY ID",
            errorCode = ErrorCode.INITIALIZATION_FAILED,
            decryptFailedCode = InternalErrorCode.IDENTITY_ID_DECRYPT_FAILED
        )
    }

    override fun getRegisteredAt(): Long? {
        val result = getField(
            v2PrefKey = PREF_REGISTERED_AT_V2,
            legacyPrefKey = PREF_REGISTERED_AT,
            label = "REGISTERED_AT",
            errorCode = ErrorCode.INTERNAL_ERROR,
            decryptFailedCode = InternalErrorCode.BIO_DATA_DECRYPT_FAILED
        ) ?: return null
        return result.toLong()
    }

    // ==========================================
    // Clear Methods
    // ==========================================

    override fun clearRegisteredAt() {
        prefs.edit(commit = true) {
            remove(PREF_REGISTERED_AT)
            remove(PREF_REGISTERED_AT_V2)
        }
    }

    override fun clearIdentity() {
        prefs.edit { clear() }
    }

    // ==========================================
    // Private — 통합 헬퍼
    // ==========================================

    private fun saveField(
        plainText: String,
        prefKey: String,
        label: String,
        errorCode: ErrorCode,
        encryptFailedCode: InternalErrorCode,
        saveFailedCode: InternalErrorCode,
        systemExceptionCode: InternalErrorCode
    ) {
        val encrypted = try {
            localDataEncryptor.encrypt(plainText)
        } catch (e: Exception) {
            errorLog(TAG, "$label 암호화 실패: $e")
            throw GoPassException.from(
                error = errorCode,
                internalCode = encryptFailedCode
            )
        }

        try {
            val isSaved = prefs.edit()
                .putString(prefKey, encrypted)
                .commit()

            if (!isSaved) {
                errorLog(TAG, "$label 디스크 쓰기 실패 (commit=false)")
                throw GoPassException.from(
                    error = errorCode,
                    internalCode = saveFailedCode
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "$label 저장 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = errorCode,
                internalCode = systemExceptionCode
            )
        }
    }

    private fun getField(
        v2PrefKey: String,
        legacyPrefKey: String,
        label: String,
        errorCode: ErrorCode,
        decryptFailedCode: InternalErrorCode
    ): String? {
        // 1) v2 슬롯 우선 (TEE 키)
        prefs.getString(v2PrefKey, null)?.let { encrypted ->
            try {
                return localDataEncryptor.decrypt(encrypted)
            } catch (e: Exception) {
                errorLog(TAG, "$label v2 복호화 실패, legacy fallback 시도: $e")
                if (!prefs.contains(legacyPrefKey)) {
                    throw GoPassException.from(
                        error = errorCode,
                        internalCode = decryptFailedCode
                    )
                }
            }
        }

        // 2) Legacy 슬롯 (MASTER_KEY / StrongBox)
        val legacyEncrypted = prefs.getString(legacyPrefKey, null) ?: return null
        val plainText = try {
            localDataEncryptor.decryptLegacy(legacyEncrypted)
        } catch (e: Exception) {
            errorLog(TAG, "$label legacy 복호화 실패: $e")
            throw GoPassException.from(
                error = errorCode,
                internalCode = decryptFailedCode
            )
        }

        // 3) v2로 마이그레이션
        migrateField(v2PrefKey, legacyPrefKey, plainText, label)
        return plainText
    }

    private fun migrateField(
        v2PrefKey: String,
        legacyPrefKey: String,
        plainText: String,
        label: String
    ) {
        try {
            val encrypted = localDataEncryptor.encrypt(plainText)
            val isSaved = prefs.edit()
                .putString(v2PrefKey, encrypted)
                .commit()

            if (!isSaved) {
                errorLog(TAG, "$label v2 마이그레이션 저장 실패 (commit=false)")
                return
            }

            val verified = localDataEncryptor.decrypt(encrypted)
            if (verified != plainText) {
                prefs.edit(commit = true) {
                    remove(v2PrefKey)
                }
                errorLog(TAG, "$label v2 마이그레이션 검증 실패")
            } else {
                prefs.edit(commit = true) { remove(legacyPrefKey) }
                debugLog(TAG, "$label v2 마이그레이션 완료 (legacy 제거)")
            }
        } catch (e: Exception) {
            errorLog(TAG, "$label v2 마이그레이션 실패, legacy 값 반환 유지: $e")
        }
    }

    private fun migrateLegacyFieldIfNeeded(
        v2PrefKey: String,
        legacyPrefKey: String,
        label: String
    ) {
        if (prefs.contains(v2PrefKey)) return
        val legacyEncrypted = prefs.getString(legacyPrefKey, null) ?: return

        val plainText = try {
            localDataEncryptor.decryptLegacy(legacyEncrypted)
        } catch (e: Exception) {
            errorLog(TAG, "$label 동반 마이그레이션을 위한 legacy 복호화 실패, skip: $e")
            return
        }

        migrateField(v2PrefKey, legacyPrefKey, plainText, label)
    }

    private fun migrateAllLegacyFieldsIfNeeded() {
        migrateLegacyFieldIfNeeded(PREF_API_KEY_V2, PREF_API_KEY, "API KEY")
        migrateLegacyFieldIfNeeded(PREF_BEACON_UUID_V2, PREF_BEACON_UUID, "BEACON UUID")
        migrateLegacyFieldIfNeeded(PREF_INSTALL_ID_V2, PREF_INSTALL_ID, "INSTALL ID")
        migrateLegacyFieldIfNeeded(PREF_DEVICE_ID_V2, PREF_DEVICE_ID, "DEVICE ID")
        migrateLegacyFieldIfNeeded(PREF_IDENTITY_ID_V2, PREF_IDENTITY_ID, "IDENTITY ID")
        migrateLegacyFieldIfNeeded(PREF_REGISTERED_AT_V2, PREF_REGISTERED_AT, "REGISTERED_AT")
    }
}

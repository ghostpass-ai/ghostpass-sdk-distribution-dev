package com.ghostpasssdk.gopasssdk.domain.usecase.errorlog

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.RuntimeFlowErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RuntimeFlowLogRepository
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * 런타임 에러를 서버에 fire-and-forget으로 보고한다.
 * 실패해도 SDK 동작에 영향을 주지 않는다.
 */
internal class RuntimeFlowErrorReporter(
    private val repository: RuntimeFlowLogRepository
) {
    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun report(
        errorCode: RuntimeFlowErrorCode,
        message: String,
        sessionId: String? = null
    ) {
        backgroundScope.launch {
            runCatching {
                val result = repository.reportError(
                    sessionId = sessionId,
                    errorCode = errorCode.code,
                    errorMessage = message
                )
                when (result) {
                    is ApiResult.Success -> warnLog(TAG, "에러 로그 전송 완료: ${errorCode.code}")
                    is ApiResult.Failure -> errorLog(TAG, "에러 로그 전송 실패: code=${result.code}, message=${result.message}")
                    is ApiResult.NetworkError -> errorLog(TAG, "에러 로그 전송 네트워크 실패: ${result.error.message}")
                }
            }
        }
    }

    fun destroy() {
        backgroundScope.coroutineContext[Job]?.cancel()
    }

    companion object {
        private val TAG = "RuntimeFlowErrorReporter ${BuildConfig.SIGNATURE}"
    }
}

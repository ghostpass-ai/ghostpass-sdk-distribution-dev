package com.ghostpasssdk.gopasssdk.data.engine.monitor

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.errorLog
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

@OptIn(ExperimentalCoroutinesApi::class)
internal object BeaconServiceEvents {

    private val TAG = "BeaconServiceEvents ${BuildConfig.SIGNATURE}"

    // ==========================================
    // 1. 스캔 시작 관련 이벤트 (Scan Start)
    // ==========================================
    private val _scanStarted = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val scanStarted = _scanStarted.asSharedFlow()

    private val _scanStartFailed = MutableSharedFlow<String>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val scanStartFailed = _scanStartFailed.asSharedFlow()

    private val _monitorReady = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val monitorReady = _monitorReady.asSharedFlow()

    internal fun notifyScanStarted() {
        _scanStopped.resetReplayCache()
        _scanStarted.tryEmit(Unit)
    }

    internal fun notifyScanStartFailed(reason: String) {
        _scanStartFailed.tryEmit(reason)
    }

    internal fun notifyMonitorReady() {
        _monitorReady.tryEmit(Unit)
    }

    internal fun clearScanStartEvents() {
        _scanStarted.resetReplayCache()
        _scanStartFailed.resetReplayCache()
        _monitorReady.resetReplayCache()
    }


    // ==========================================
    // 2. 스캔 중단 관련 이벤트 (Scan Stop)
    // ==========================================
    private val _scanStopped = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val scanStopped = _scanStopped.asSharedFlow()

    internal fun notifyScanStopped() {
        _scanStopped.tryEmit(Unit)
    }

    internal fun clearScanStopEvents() {
        _scanStopped.resetReplayCache()
    }


    // ==========================================
    // 3. 비콘 가시성 이벤트 (Beacon Visibility)
    // ==========================================
    data class BeaconAppearedEvent(val major: Int, val minor: Int, val rssi: Int)

    private val _beaconAppeared = MutableSharedFlow<BeaconAppearedEvent>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val beaconAppeared = _beaconAppeared.asSharedFlow()

    private val _beaconLost = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val beaconLost = _beaconLost.asSharedFlow()

    internal fun notifyBeaconAppeared(major: Int, minor: Int, rssi: Int) {
        _beaconLost.resetReplayCache()
        _beaconAppeared.tryEmit(BeaconAppearedEvent(major, minor, rssi))
    }

    internal fun notifyBeaconLost() {
        _beaconAppeared.resetReplayCache()
        _beaconLost.tryEmit(Unit)
    }

    internal fun clearBeaconVisibilityEvents() {
        _beaconAppeared.resetReplayCache()
        _beaconLost.resetReplayCache()
    }


    // ==========================================
    // 4. 서비스 완전 종료/파기 관련 이벤트 (Destroy)
    // ==========================================
    private val _serviceDestroyed = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val serviceDestroyed = _serviceDestroyed.asSharedFlow()

    internal fun notifyServiceDestroyed() {
        val success = _serviceDestroyed.tryEmit(Unit)
        if (!success) {
            errorLog(TAG, "Destroy 이벤트 발송 실패 (버퍼 가득 참)")
        }
    }

    internal fun clearDestroyEvents() {
        _serviceDestroyed.resetReplayCache()
    }

    // SDK reset 시 모든 Replay 캐시를 비워 재초기화 시 Stale 이벤트 수신 방지
    internal fun resetAllCaches() {
        _scanStarted.resetReplayCache()
        _scanStartFailed.resetReplayCache()
        _monitorReady.resetReplayCache()
        _scanStopped.resetReplayCache()
        _beaconAppeared.resetReplayCache()
        _beaconLost.resetReplayCache()
        _serviceDestroyed.resetReplayCache()
    }


    // ==========================================
    // 5. 비콘 기기 감지 이벤트 (Detect)
    // ==========================================
    private val _beaconDetected = MutableSharedFlow<BeaconDetectionEvent>(
        extraBufferCapacity = 32,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val beaconDetected = _beaconDetected.asSharedFlow()

    internal fun notifyBeaconDetected(major: Int, minor: Int, rssi: Int) {
        val success = _beaconDetected.tryEmit(BeaconDetectionEvent(major, minor, rssi))
        if (!success) {
            errorLog(TAG, "비콘 감지 이벤트 발송 실패 (버퍼 오버플로우)")
        }
    }

    data class BeaconDetectionEvent(val major: Int, val minor: Int, val rssi: Int)


    // ==========================================
    // 6. 비콘 개별 침묵 이벤트 (Per-Beacon Silence)
    // ==========================================
    private val _beaconSilent = MutableSharedFlow<BeaconSilentEvent>(
        extraBufferCapacity = 32,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val beaconSilent = _beaconSilent.asSharedFlow()

    internal fun notifyBeaconSilent(major: Int, minor: Int) {
        _beaconSilent.tryEmit(BeaconSilentEvent(major, minor))
    }

    data class BeaconSilentEvent(val major: Int, val minor: Int)
}

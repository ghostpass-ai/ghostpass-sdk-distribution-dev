package com.ghostpasssdk.gopasssdk.domain.model.external.error

import androidx.annotation.Keep

@Keep
enum class ErrorCode(val externalCode: String, val message: String? = null) {

    // ---------------------------------------------------------
    // 0xx: 기기 환경 및 권한 (Environment & Permission)
    // ---------------------------------------------------------
    BLUETOOTH_DISABLED("GP001", "블루투스를 활성화해주세요."),
    BLUETOOTH_PERMISSION_DENIED("GP002", "블루투스 권한이 필요합니다."),
    LOCATION_PERMISSION_DENIED("GP003", "위치 서비스 권한이 필요합니다."),
    LOCATION_PERMISSION_INSUFFICIENT("GP004", "위치 서비스 권한이 부족합니다."),
    BEACON_UUID_NOT_FOUND("GP005", "인증 정보를 확인할 수 없습니다."),
    NETWORK_DISCONNECTED("GP006", "네트워크 연결을 확인해주세요."),

    // ---------------------------------------------------------
    // 1xx: 초기화 및 공통 (Initialization & Common)
    // ---------------------------------------------------------
    INITIALIZATION_FAILED("GP101", "초기화를 실패했습니다."),
    UPDATE_SDK("GP102", "SDK 버전이 최신이 아닙니다."),
    INVALID_PARAMETERS("GP103", "요청 파라미터가 올바르지 않습니다."),
    MONITORING_STOP_FAILED("GP104", "비콘 모니터링 중지에 실패했습니다."),

    // ---------------------------------------------------------
    // 2xx: 생체 데이터 (Bio Data)
    // ---------------------------------------------------------
    REGISTER_BIO_DATA_FAILED("GP201", "생체 데이터 등록에 실패했습니다."),
    REMOVE_BIO_DATA_FAILED("GP202", "생체 데이터 삭제에 실패했습니다."),
    INVALID_IMAGE_BYTES("IN-203", "입력 이미지 바이트가 올바르지 않습니다."),
    LIVENESS_NOT_SATISFIED("IN-204", "라이브니스 검증에 실패했습니다."),

    // ---------------------------------------------------------
    // 3xx: Reset
    // ---------------------------------------------------------
    RESET_FAILED("GP301", "SDK 초기화 해제에 실패했습니다."),

    // ---------------------------------------------------------
    // 4xx: HandsFree
    // ---------------------------------------------------------
    DELEGATE_AUTH_SESSION_FAILED("GP401", "핸즈프리 인증 처리에 실패했습니다."),

    // ---------------------------------------------------------
    // 9xx: 서버 및 시스템 (Server & System)
    // ---------------------------------------------------------
    SDK_SERVICE_NOT_FOUND("GP901", "SDK 서비스를 찾을 수 없습니다."),
    SDK_SERVICE_INACTIVE("GP902", "비활성화된 SDK 서비스입니다."),
    SDK_SERVICE_CODE_DUPLICATE("GP903", "이미 사용 중인 서비스 코드입니다."),
    SDK_API_KEY_DUPLICATE("GP904", "이미 사용 중인 API Key입니다."),
    SERVER_ERROR("GP905", "서버의 응답이 비정상적입니다."),

    // (참고) 기존 코드에 있던 예기치 못한 내부 에러용 Fallback
    INTERNAL_ERROR("GP906", "SDK 내부 처리 중 오류가 발생했습니다.")
}
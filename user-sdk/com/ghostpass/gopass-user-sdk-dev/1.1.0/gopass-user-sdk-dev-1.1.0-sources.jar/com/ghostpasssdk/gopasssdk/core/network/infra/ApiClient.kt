package com.ghostpasssdk.gopasssdk.core.network.infra

import android.os.Build
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.security.infra.RequestSigner
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.infoLog
import kotlinx.serialization.json.Json
import okhttp3.ConnectionSpec
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.TlsVersion
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

internal class ApiClient(
    private val json: Json,
    private val requestSigner: RequestSigner,
    private val identityRepository: IdentityRepository
) {
    companion object {
        private val TAG = "ApiClient ${BuildConfig.SIGNATURE}"

        // 내부 플래그 헤더
        internal const val HEADER_SKIP_API_KEY = "X-Skip-Api-Key"
        internal const val HEADER_SKIP_SIGNATURE = "X-Skip-Signature"
        internal const val HEADER_SIGNED_CONTEXT = "X-Internal-Signed-Context"
        private const val SKIP_SIGNATURE_VALUE = "true"
        internal const val SIGNED_CONTEXT_CONFIRM = "confirm"
        internal const val SIGNED_CONTEXT_CONFIG = "config"
        internal const val SIGNED_CONTEXT_SESSION = "session"

        // 콘텐츠 타입
        private const val CONTENT_TYPE_JSON = "application/json"
    }

    fun getSecureClientBuilder(): OkHttpClient.Builder = OkHttpClient.Builder()
        .connectionSpecs(
            listOf(
                ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                    .tlsVersions(TlsVersion.TLS_1_3, TlsVersion.TLS_1_2)
                    .build()
            )
        )
        .addInterceptor { chain ->
            try {
                val request = chain.request()
                val (ts, nonce) = buildMeta()

                val skipApiKey = request.header(HEADER_SKIP_API_KEY) == SKIP_SIGNATURE_VALUE
                val skipSignature = skipApiKey || request.header(HEADER_SKIP_SIGNATURE) == SKIP_SIGNATURE_VALUE
                val signedContext = SignedContext.from(request.header(HEADER_SIGNED_CONTEXT))

                // 기본 헤더 세팅
                val requestBuilder = request.newBuilder().apply {
                    removeHeader(HEADER_SKIP_API_KEY)
                    removeHeader(HEADER_SKIP_SIGNATURE)
                    removeHeader(HEADER_SIGNED_CONTEXT)
                    header("X-Timestamp", ts)
                    header("X-Nonce", nonce)

                    if (request.header("Accept") == null) {
                        header("Accept", CONTENT_TYPE_JSON)
                    }
                }

                if (!skipApiKey) {
                    val currentApiKey = identityRepository.getApiKey()
                        ?: throw ApiClientException(
                            GoPassException.from(
                                error = ErrorCode.INTERNAL_ERROR,
                                internalCode = InternalErrorCode.API_KEY_NOT_FOUND
                            )
                        )
                    requestBuilder.header("X-API-Key", currentApiKey)
                }

                if (!skipSignature) {
                    if (signedContext != null) {
                        ensureHmacReady(signedContext)
                        val currentDeviceId = requireDeviceId(signedContext)
                        requestBuilder.header("X-Device-Id", currentDeviceId)
                        addSignatureHeader(request, requestBuilder, ts, nonce)
                    } else if (requestSigner.isAvailable()) {
                        identityRepository.getDeviceId()
                            ?.takeIf { it.isNotBlank() }
                            ?.let { currentDeviceId ->
                                requestBuilder.header("X-Device-Id", currentDeviceId)
                            }
                        addSignatureHeader(request, requestBuilder, ts, nonce)
                    }
                }

                chain.proceed(requestBuilder.build())
            } catch (e: ApiClientException) {
                throw e
            } catch (e: java.io.IOException) {
                throw e
            } catch (e: Exception) {
                throw ApiClientException(
                    if (e is GoPassException) e
                    else GoPassException.from(error = ErrorCode.INTERNAL_ERROR)
                )
            }
        }

    private fun ensureHmacReady(context: SignedContext) {
        if (!requestSigner.isAvailable()) {
            throw ApiClientException(
                GoPassException.from(
                    error = ErrorCode.INTERNAL_ERROR,
                    internalCode = context.missingHmacCode
                )
            )
        }
    }

    private fun requireDeviceId(context: SignedContext): String {
        val deviceId = identityRepository.getDeviceId()
        if (deviceId.isNullOrBlank()) {
            throw ApiClientException(
                GoPassException.from(
                    error = ErrorCode.INTERNAL_ERROR,
                    internalCode = context.missingDeviceIdCode
                )
            )
        }
        return deviceId
    }

    private fun addSignatureHeader(
        request: Request,
        requestBuilder: Request.Builder,
        timestamp: String,
        nonce: String
    ) {
        val bodyString = request.body?.let { body ->
            val buffer = okio.Buffer()
            body.writeTo(buffer)
            buffer.readUtf8()
        } ?: ""
        infoLog(TAG, "request body : $bodyString")

        val bodyHash = requestSigner.hashBody(bodyString)
        val stringToSign =
            "${request.method}\n${request.url.encodedPath}\n$timestamp\n$nonce\n$bodyHash"
        debugLog(TAG, "stringToSign : $stringToSign")

        val signature = requestSigner.sign(stringToSign)

        requestBuilder.header("X-Signature", signature)
    }

    private fun buildMeta(): Pair<String, String> {
        val timestamp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Instant.now().toString()
        } else {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.KOREA).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            sdf.format(Date())
        }
        val nonce = UUID.randomUUID().toString()
        return timestamp to nonce
    }

    fun buildRetrofit(baseUrl: String, okHttpClient: OkHttpClient): Retrofit {
        val contentType = CONTENT_TYPE_JSON.toMediaType()
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
    }

    private enum class SignedContext(
        val rawValue: String,
        val missingHmacCode: InternalErrorCode,
        val missingDeviceIdCode: InternalErrorCode
    ) {
        CONFIRM(
            rawValue = SIGNED_CONTEXT_CONFIRM,
            missingHmacCode = InternalErrorCode.HMAC_KEY_LOAD_FOR_CONFIRM_FAILED,
            missingDeviceIdCode = InternalErrorCode.DEVICE_ID_LOAD_FOR_CONFIRM_FAILED
        ),
        CONFIG(
            rawValue = SIGNED_CONTEXT_CONFIG,
            missingHmacCode = InternalErrorCode.HMAC_KEY_LOAD_FOR_CONFIG_FAILED,
            missingDeviceIdCode = InternalErrorCode.DEVICE_ID_LOAD_FOR_CONFIG_FAILED
        ),
        SESSION(
            rawValue = SIGNED_CONTEXT_SESSION,
            missingHmacCode = InternalErrorCode.SESSION_HMAC_KEY_LOAD_FAILED,
            missingDeviceIdCode = InternalErrorCode.SESSION_DEVICE_ID_LOAD_FAILED
        );

        companion object {
            fun from(rawValue: String?): SignedContext? {
                return entries.firstOrNull { it.rawValue == rawValue }
            }
        }
    }
}

package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager
import com.ghostpasssdk.gopasssdk.core.security.infra.EphemeralAesKey
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.RuntimeFlowErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import com.ghostpasssdk.gopasssdk.domain.usecase.errorlog.RuntimeFlowErrorReporter
import com.ghostpasssdk.gopasssdk.utils.wipe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class DecryptSessionUseCase(
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager,
    private val errorReporter: RuntimeFlowErrorReporter
) {
    suspend fun execute(encrypted: EncryptedSession): DecryptedSession = withContext(Dispatchers.IO) {
        var decryptedBytes: ByteArray? = null
        val aad = encrypted.sessionId.toByteArray(Charsets.UTF_8)

        val key = try {
            keyManager.getSecretKey(KeyManager.TRANSPORT_ALIAS)
        } catch (e: Exception) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.TRANSPORT_KEY_LOAD_FAILED,
                message = e.message ?: "transport key load failed",
                sessionId = encrypted.sessionId
            )
            throw e
        }

        try {
            decryptedBytes = try {
                cryptoEngine.decryptData(
                    key = key,
                    aad = aad,
                    encryptedBase64 = encrypted.encryptedDk
                )
            } catch (e: IllegalArgumentException) {
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.DK_BASE64_DECODE_FAILED,
                    message = e.message ?: "DK base64 decode failed",
                    sessionId = encrypted.sessionId
                )
                throw e
            } catch (e: Exception) {
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.DK_AES_GCM_DECRYPT_FAILED,
                    message = e.message ?: "DK AES-GCM decrypt failed",
                    sessionId = encrypted.sessionId
                )
                throw e
            }

            val ephemeralKey = EphemeralAesKey(decryptedBytes)
            decryptedBytes = null

            DecryptedSession(
                sessionId = encrypted.sessionId,
                rtdbPath = encrypted.rtdbPath,
                dkUser = ephemeralKey,
                firebaseToken = encrypted.firebaseToken,
                expiresAtMillis = encrypted.expiresAtMillis,
                beaconMajor = encrypted.beaconMajor,
                beaconMinor = encrypted.beaconMinor
            )
        } finally {
            decryptedBytes.wipe()
        }
    }
}

package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.RuntimeFlowErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.UserToKioskPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.core.network.utils.retryApiCall
import com.ghostpasssdk.gopasssdk.domain.usecase.errorlog.RuntimeFlowErrorReporter
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json.Default.encodeToString

internal class UpdateSessionResultUseCase(
    private val realtimeSessionRepository: RealtimeSessionRepository,
    private val sessionRepository: SessionRepository,
    private val cryptoEngine: CryptoEngine,
    private val identityRepository: IdentityRepository,
    private val errorReporter: RuntimeFlowErrorReporter
) {
    companion object {
        private val TAG = "UpdateSessionUseCase ${BuildConfig.SIGNATURE}"
        private const val STATUS_SUCCESS = "SUCCESS"
        private const val STATUS_FAIL = "FAIL"
        private const val TYPE = "AUTH_RESULT"
    }

    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * RTDB user_to_kiosk에 인증 결과를 암호화하여 전송한다.
     * RTDB 기록 성공 = 인증 흐름 성공. /result 서버 보고는 포함하지 않는다.
     */
    suspend fun execute(session: DecryptedSession, idToken: String, isSuccess: Boolean, seq: Int, preloadedDeviceId: String? = null): Boolean {
        return try {
            val finalStatus = if (isSuccess) STATUS_SUCCESS else STATUS_FAIL
            val startNanos = System.nanoTime()
            val deviceId = preloadedDeviceId ?: identityRepository.getDeviceId()

            if (deviceId == null) {
                errorLog(TAG, "deviceID null")
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.DEVICE_ID_NULL,
                    message = "deviceId null",
                    sessionId = session.sessionId
                )
                return false
            }

            if (deviceId.isBlank()) {
                errorLog(TAG, "deviceID blank")
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.DEVICE_ID_BLANK,
                    message = "deviceId blank",
                    sessionId = session.sessionId
                )
                return false
            }

            val deviceIdElapsed = (System.nanoTime() - startNanos) / 1_000_000
            debugLog(TAG, "[FACE_AUTH][RESULT] deviceID load 완료 (${deviceIdElapsed}ms)")

            val payloadMap = mapOf(
                "type" to TYPE,
                "result" to finalStatus,
                "deviceId" to deviceId
            )

            val plaintext = encodeToString(payloadMap)

            val aadString = "${session.sessionId}:$seq:u2k"
            val aadBytes = aadString.toByteArray(Charsets.UTF_8)

            val encryptStartNanos = System.nanoTime()
            val encryptedData = try {
                cryptoEngine.encrypt(
                    plainText = plaintext,
                    aad = aadBytes,
                    key = session.dkUser
                )
            } catch (e: Exception) {
                errorLog(TAG, "결과 암호화 실패: ${e.message}")
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.RESULT_ENCRYPT_FAILED,
                    message = "결과 암호화 실패: ${e.message}",
                    sessionId = session.sessionId
                )
                return false
            }
            val encryptElapsed = (System.nanoTime() - encryptStartNanos) / 1_000_000
            debugLog(TAG, "[FACE_AUTH][RESULT] 결과 암호화 완료 (${encryptElapsed}ms)")

            val updatePayload = UserToKioskPayload(
                payload = encryptedData,
                seq = seq
            )

            val uploadStartNanos = System.nanoTime()
            val result = realtimeSessionRepository.updateSession(
                path = session.rtdbPath,
                authToken = idToken,
                data = updatePayload
            )
            val uploadElapsed = (System.nanoTime() - uploadStartNanos) / 1_000_000

            if (result.isSuccess) {
                val totalElapsed = (System.nanoTime() - startNanos) / 1_000_000
                warnLog(TAG, "[FACE_AUTH][RESULT] user_to_kiosk 전송 완료 (${uploadElapsed}ms, total=${totalElapsed}ms)")
                true
            } else {
                errorLog(TAG, "❌ [서버 전송 실패] 에러: ${result.exceptionOrNull()?.message}")
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.RTDB_WRITE_FAILED,
                    message = "RTDB write 실패: ${result.exceptionOrNull()?.message}",
                    sessionId = session.sessionId
                )
                false
            }

        } catch (e: Exception) {
            errorLog(TAG, "🚨 암호화 또는 전송 중 치명적 에러: ${e.message}")
            false
        }
    }

    /**
     * deviceId를 미리 로드한다. 얼굴 비교와 병렬 실행 시 사용.
     */
    fun preloadDeviceId(): String? = identityRepository.getDeviceId()

    /**
     * 서버에 인증 결과를 보고한다. 지수 백오프로 최대 3회 재시도.
     * best-effort: 실패해도 인증 흐름에 영향을 주지 않는다.
     */
    suspend fun submitSessionResultWithRetry(sessionId: String, isSuccess: Boolean, similarityScore: Float) {
        val result = retryApiCall { sessionRepository.submitResult(sessionId, isSuccess, similarityScore) }
        when (result) {
            is ApiResult.Success -> warnLog(
                TAG,
                "😆 result API 호출 완료: sessionId=$sessionId, status=${result.data.status}, failCount=${result.data.failCount}"
            )
            is ApiResult.Failure -> {
                errorLog(TAG, "📋 result 보고 최종 실패: code=${result.code}, message=${result.message}")
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.RESULT_REPORT_FAILED,
                    message = "result API 실패: code=${result.code}, message=${result.message}",
                    sessionId = sessionId
                )
            }
            is ApiResult.NetworkError -> {
                errorLog(TAG, "📋 result 보고 최종 네트워크 실패: ${result.error.message}")
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.RESULT_REPORT_FAILED,
                    message = "result 보고 네트워크 실패: ${result.error.message}",
                    sessionId = sessionId
                )
            }
        }
    }

    /**
     * 독립 스코프에서 /result 서버 보고를 fire-and-forget으로 수행한다.
     * 세션 스코프 취소/타임아웃과 무관하게 보고가 완료되도록 보장한다.
     */
    fun submitSessionResultBackground(sessionId: String, isSuccess: Boolean, similarityScore: Float) {
        backgroundScope.launch {
            submitSessionResultWithRetry(sessionId, isSuccess, similarityScore)
        }
    }

    fun destroy() {
        backgroundScope.coroutineContext[Job]?.cancel()
    }
}

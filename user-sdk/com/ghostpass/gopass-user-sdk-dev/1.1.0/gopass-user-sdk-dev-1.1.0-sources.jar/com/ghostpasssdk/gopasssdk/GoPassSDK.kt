package com.ghostpasssdk.gopasssdk

import android.content.Context
import androidx.annotation.Keep
import com.ghostpasssdk.gopasssdk.domain.model.external.BioDataFrameStatus
import com.ghostpasssdk.gopasssdk.domain.model.external.HasBioDataResult
import com.ghostpasssdk.gopasssdk.domain.model.external.InitResult
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.internal.di.SdkContainer

@Keep
object GoPassSDK {

    suspend fun initialize(apiKey: String, context: Context): InitResult {
        val container = SdkContainer.getOrCreate(context)
        return container.infrastructureManager.initialize(apiKey)
    }

    fun hasBioData(): HasBioDataResult {
        return SdkContainer.requireInstance().landmarkManager.getHasBioDataResult()
    }

    suspend fun registerBioData(
        faceImage: ByteArray,
        width: Int,
        height: Int,
        rotation: Int
    ): BioDataFrameStatus {
        return SdkContainer.requireInstance().landmarkManager.saveLandmark(
            faceImage = faceImage,
            width = width,
            height = height,
            rotation = rotation
        )
    }

    suspend fun removeBioData(): Boolean {
        return SdkContainer.requireInstance().landmarkManager.deleteLandmark()
    }

    suspend fun reset() {
        try {
            SdkContainer.requireInstance().infrastructureManager.reset()
        } finally {
            SdkContainer.destroyInstance()
        }
    }

    @Throws(GoPassException::class)
    suspend fun startMonitoring() {
        SdkContainer.requireInstance().monitoringController.startMonitoring()
    }

    @Throws(GoPassException::class)
    suspend fun stopMonitoring() {
        SdkContainer.requireInstance().monitoringController.stopMonitoring()
    }

    @Throws(GoPassException::class)
    suspend fun registerFcmToken(token: String) {
        SdkContainer.requireInstance().infrastructureManager.registerFcmToken(token)
    }

    @Throws(GoPassException::class)
    suspend fun delegateAuthSession(session: String, context: Context) {
        val container = SdkContainer.getOrCreate(context)
        container.infrastructureManager.delegateAuthSession(session)
    }
}

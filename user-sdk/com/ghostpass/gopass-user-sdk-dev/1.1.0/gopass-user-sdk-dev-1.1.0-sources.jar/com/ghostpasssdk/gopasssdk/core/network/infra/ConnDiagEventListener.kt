package com.ghostpasssdk.gopasssdk.core.network.infra

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.warnLog
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Proxy
import okhttp3.Call
import okhttp3.Connection
import okhttp3.EventListener
import okhttp3.Handshake
import okhttp3.Protocol
import okhttp3.Response

/**
 * [임시 진단용 — 검증 후 롤백 예정]
 * tail latency 원인 검증: "서버/경로 측 지연" vs "커넥션 수립(TCP+TLS) 비용" 가설 판별.
 * - tail 요청에 [CONN_NEW]가 동반되면 → 커넥션 수립 비용이 원인 (pre-warm이 해결책)
 * - [ACQUIRED][REUSED]인데도 tail이면 → 서버/경로 측 지연 (hedge 유지 근거)
 * - protocol=h2로 확인되면 drain 근거(http/1.1 취소 시 폐기)도 재검토 대상
 */
internal class ConnDiagEventListenerFactory(
    private val clientLabel: String
) : EventListener.Factory {
    override fun create(call: Call): EventListener = ConnDiagEventListener(clientLabel)
}

private class ConnDiagEventListener(
    private val clientLabel: String
) : EventListener() {

    companion object {
        private val TAG = "ConnDiag ${BuildConfig.SIGNATURE}"
    }

    private var callStartNanos = 0L
    private var connectStartNanos = 0L
    private var secureStartNanos = 0L
    private var dnsStartNanos = 0L
    private var newConnection = false
    private var requestLine = "?"

    private fun sinceCallStartMs() = (System.nanoTime() - callStartNanos) / 1_000_000

    private fun sinceMs(startNanos: Long) = (System.nanoTime() - startNanos) / 1_000_000

    override fun callStart(call: Call) {
        callStartNanos = System.nanoTime()
        // 주의: query에 auth 토큰이 있으므로 encodedPath만 로깅
        requestLine = "${call.request().method} ${call.request().url.encodedPath}"
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CALL_START] $requestLine")
    }

    override fun dnsStart(call: Call, domainName: String) {
        dnsStartNanos = System.nanoTime()
    }

    override fun dnsEnd(call: Call, domainName: String, inetAddressList: List<java.net.InetAddress>) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][DNS] ${sinceMs(dnsStartNanos)}ms 소요 (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun connectStart(call: Call, inetSocketAddress: InetSocketAddress, proxy: Proxy) {
        newConnection = true
        connectStartNanos = System.nanoTime()
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CONN_NEW] TCP 연결 시작 (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun secureConnectStart(call: Call) {
        secureStartNanos = System.nanoTime()
    }

    override fun secureConnectEnd(call: Call, handshake: Handshake?) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][TLS] handshake ${sinceMs(secureStartNanos)}ms 소요 (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun connectEnd(call: Call, inetSocketAddress: InetSocketAddress, proxy: Proxy, protocol: Protocol?) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CONN_DONE] 수립 완료 ${sinceMs(connectStartNanos)}ms 소요, protocol=$protocol (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun connectFailed(call: Call, inetSocketAddress: InetSocketAddress, proxy: Proxy, protocol: Protocol?, ioe: IOException) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CONN_FAIL] ${sinceMs(connectStartNanos)}ms 후 실패: ${ioe.message} (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun connectionAcquired(call: Call, connection: Connection) {
        val kind = if (newConnection) "NEW" else "REUSED"
        warnLog(
            TAG,
            "[CONN_DIAG][$clientLabel][ACQUIRED][$kind] conn=${System.identityHashCode(connection)} " +
                "protocol=${connection.protocol()} (+${sinceCallStartMs()}ms) $requestLine"
        )
    }

    override fun responseHeadersEnd(call: Call, response: Response) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][RESP] code=${response.code} protocol=${response.protocol} (+${sinceCallStartMs()}ms) $requestLine")
    }

    override fun callEnd(call: Call) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CALL_END] total=${sinceCallStartMs()}ms newConn=$newConnection $requestLine")
    }

    override fun callFailed(call: Call, ioe: IOException) {
        warnLog(TAG, "[CONN_DIAG][$clientLabel][CALL_FAIL] total=${sinceCallStartMs()}ms newConn=$newConnection ${ioe.message} $requestLine")
    }
}

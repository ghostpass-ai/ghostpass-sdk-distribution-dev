package com.ghostpasssdk.gopasssdk.domain.repository.storage

/**
 * 호스트앱의 명시적 모니터링 제어 의도를 보관하는 저장소.
 *
 * 호스트가 stopMonitoring()을 명시적으로 호출하면 억제 상태가 되고,
 * 이 상태에서는 SDK 내부의 startMonitoring 시도(initialize 등)가 무효화된다.
 * 호스트가 startMonitoring()을 명시적으로 호출하면 억제가 해제된다.
 *
 * 프로세스 재시작 후에도 의도가 유지되어야 하므로 디스크에 영속화된다.
 */
internal interface MonitoringPolicyRepository {

    /** 호스트가 명시적으로 모니터링을 중지한 상태인지 여부 */
    val isSuppressedByHost: Boolean

    /** 호스트의 명시적 stopMonitoring 호출 시 설정 — 내부 start 요청을 무효화한다 */
    suspend fun suppressByHost()

    /** 호스트의 명시적 startMonitoring 호출 또는 SDK reset 시 해제 */
    suspend fun clearSuppression()
}

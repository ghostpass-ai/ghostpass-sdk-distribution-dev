package com.ghostpasssdk.gopasssdk.data.dto.session

import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionResultPayload
import kotlinx.serialization.Serializable

@Serializable
internal data class SessionResultDto(
    val sessionId: String,
    val status: String,
    val terminatedAt: String? = null,
    val failCount: Int = 0
) {
    fun toDomain(): SessionResultPayload = SessionResultPayload(
        sessionId = sessionId,
        status = status,
        terminatedAt = terminatedAt,
        failCount = failCount
    )
}

package com.ghostpasssdk.gopasssdk.data.repository.remote

import com.ghostpasssdk.gopasssdk.data.api.FirebaseApi
import com.ghostpasssdk.gopasssdk.data.dto.firebase.CustomTokenSignInRequest
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.HEADER_SKIP_API_KEY
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.data.dto.firebase.FirebaseSseWrapperDto
import com.ghostpasssdk.gopasssdk.data.dto.firebase.KioskToUserPayloadDto
import com.ghostpasssdk.gopasssdk.data.dto.firebase.UserToKioskPayloadDto
import com.ghostpasssdk.gopasssdk.data.dto.landmark.FaceVectorPayloadDto
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.AuthToken
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.KioskToUserPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.UserToKioskPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.landmark.FaceVectorPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.RuntimeFlowErrorCode
import com.ghostpasssdk.gopasssdk.domain.usecase.errorlog.RuntimeFlowErrorReporter
import com.ghostpasssdk.gopasssdk.utils.wipe
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json.Default.decodeFromString
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import java.io.IOException
import java.security.Key
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.Job

internal class FirebaseRealtimeSessionRepositoryImpl(
    private val firebaseApi: FirebaseApi,
    private val criticalFirebaseApi: FirebaseApi,
    private val sseOkHttpClient: OkHttpClient,
    private val cryptoEngine: CryptoEngine,
    private val errorReporter: RuntimeFlowErrorReporter,
    private val hedgingExecutor: RtdbHedgingExecutor
) : RealtimeSessionRepository {

    companion object {
        private val TAG = "FirebaseRTDB Repo ${BuildConfig.SIGNATURE}"
        // Firebase RTDB SSE keep-alive 주기(~30초)의 2배.
        // 연결이 조용히 끊기면 keep-alive도 멈추므로 readTimeout으로 감지한다.
        private const val SSE_READ_TIMEOUT_SECONDS = 60L
        private const val HEARTBEAT_INTERVAL_MS = 5_000L
        // 5초 × 2회 = 10초. 서버도 10초 무갱신 시 세션 삭제
        private const val HEARTBEAT_MAX_CONSECUTIVE_FAILURES = 2
        private val JSON_MEDIA_TYPE = "application/json".toMediaType()
    }

    override suspend fun authenticate(customToken: String): AuthToken {
        return try {
            val request = CustomTokenSignInRequest(token = customToken, returnSecureToken = true)
            val response = firebaseApi.signInWithCustomToken(BuildConfig.FB_API_KEY, request)

            if (response.isSuccessful) {
                val body = response.body() ?: throw GoPassException.from(
                    error = ErrorCode.SERVER_ERROR,
                    internalCode = InternalErrorCode.SESSION_RESPONSE_INVALID
                )
                AuthToken(idToken = body.idToken)
            } else {
                throw GoPassException.from(
                    error = ErrorCode.SERVER_ERROR,
                    internalCode = InternalErrorCode.SESSION_SERVER_ERROR
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: IOException) {
            throw GoPassException.from(error = ErrorCode.NETWORK_DISCONNECTED)
        } catch (e: Exception) {
            throw GoPassException.from(
                error = ErrorCode.SERVER_ERROR,
                internalCode = InternalErrorCode.SESSION_REQUEST_FAILED
            )
        }
    }

    override fun observeKioskPayload(path: String, authToken: String): Flow<KioskToUserPayload> = callbackFlow {
        val sseUrl = "${BuildConfig.FB_DB_URL}$path/kiosk_to_user.json?auth=$authToken"
        val kioskPayloadUrl = "${BuildConfig.FB_DB_URL}$path/kiosk_to_user.json"
        val heartbeatUrl = "${BuildConfig.FB_DB_URL}$path/lastSeenAt.json"

        val sseClient = sseOkHttpClient.newBuilder()
            .readTimeout(SSE_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .build()

        val factory = EventSources.createFactory(sseClient)
        val currentEventSource = AtomicReference<EventSource?>(null)
        val isClosed = AtomicBoolean(false)
        val heartbeatJob = AtomicReference<Job?>(null)

        val sessionNodeUrl = "${BuildConfig.FB_DB_URL}$path.json"

        // BOOTSTRAP GET과 SSE 첫 put 이벤트가 같은 payload를 각각 전달할 수 있으므로
        // (SSE는 연결 시 노드의 현재 상태를 put으로 재전달) seq 기준으로 1회만 emit한다.
        // BOOTSTRAP은 코루틴(IO), SSE는 OkHttp 스레드에서 호출되므로 CAS로 비교-갱신.
        val lastEmittedSeq = AtomicInteger(0)

        fun emitPayload(source: String, payloadDto: KioskToUserPayloadDto) {
            val prevSeq = lastEmittedSeq.getAndUpdate { maxOf(it, payloadDto.seq) }
            if (payloadDto.seq <= prevSeq) {
                warnLog(TAG, "[FACE_AUTH][RECEIVE][$source] 중복 수신 skip (seq=${payloadDto.seq}, 마지막 처리 seq=$prevSeq)")
                return
            }
            val ageMs = System.currentTimeMillis() - payloadDto.ts
            warnLog(TAG, "[FACE_AUTH][RECEIVE][$source] kiosk_to_user 데이터 수신 (seq=${payloadDto.seq}, age=${ageMs}ms)")
            val result = trySend(payloadDto.toDomain())
            if (result.isFailure) {
                warnLog(TAG, "[FACE_AUTH][RECEIVE][$source] kiosk_to_user 전달 실패: ${result.exceptionOrNull()?.message}")
            }
        }

        fun startHeartbeat() {
            heartbeatJob.getAndSet(null)?.cancel()
            heartbeatJob.set(launch {
                var consecutiveFailures = 0

                while (true) {
                    val cycleStartNanos = System.nanoTime()

                    try {
                        // body는 반드시 블록 안에서 소비: hedge 패자가 완주해도 body를 안 읽으면
                        // 커넥션이 풀에 반납되지 않는다 (PUT/PATCH는 print=silent 빈 응답이라 무관)
                        val (isNodeResponseOk, body) = hedgingExecutor.execute(RtdbHedgedOp.SESSION_NODE_CHECK) {
                            val nodeResponse = firebaseApi.getNode(sessionNodeUrl, authToken)
                            val nodeBody = nodeResponse.body()?.string()
                            nodeResponse.errorBody()?.close()
                            nodeResponse.isSuccessful to nodeBody
                        }

                        if (!isNodeResponseOk || body == null || body == "null") {
                            warnLog(TAG, "💔 세션 노드 소멸 감지 ($path) → flow 종료")
                            errorReporter.report(
                                errorCode = RuntimeFlowErrorCode.SESSION_NODE_GONE,
                                message = "세션 노드 소멸: path=$path"
                            )
                            close(GoPassException.from(
                                error = ErrorCode.SERVER_ERROR,
                                internalCode = InternalErrorCode.SESSION_NODE_GONE
                            ))
                            return@launch
                        }

                        val timestamp = System.currentTimeMillis().toString()
                            .toRequestBody(JSON_MEDIA_TYPE)
                        hedgingExecutor.execute(RtdbHedgedOp.HEARTBEAT) {
                            firebaseApi.updateLastSeenAt(heartbeatUrl, authToken, timestamp)
                        }
                        consecutiveFailures = 0
                        debugLog(TAG, "💓 하트비트 전송 성공 : url = $path")
                    } catch (e: Exception) {
                        consecutiveFailures++
                        warnLog(TAG, "하트비트 전송 실패 ($consecutiveFailures/${HEARTBEAT_MAX_CONSECUTIVE_FAILURES}): ${e.message}")

                        if (consecutiveFailures >= HEARTBEAT_MAX_CONSECUTIVE_FAILURES) {
                            errorLog(TAG, "💔 하트비트 연속 ${HEARTBEAT_MAX_CONSECUTIVE_FAILURES}회 실패 → 연결 끊김 판정, flow 종료")
                            errorReporter.report(
                                errorCode = RuntimeFlowErrorCode.HEARTBEAT_FAILED,
                                message = "하트비트 연속 ${HEARTBEAT_MAX_CONSECUTIVE_FAILURES}회 실패: ${e.message}"
                            )
                            close(GoPassException.from(error = ErrorCode.NETWORK_DISCONNECTED))
                            return@launch
                        }
                    }

                    val elapsedMs = (System.nanoTime() - cycleStartNanos) / 1_000_000
                    val remaining = HEARTBEAT_INTERVAL_MS - elapsedMs
                    if (remaining > 0) delay(remaining)
                }
            })
        }

        fun stopHeartbeat() {
            heartbeatJob.getAndSet(null)?.cancel()
        }

        fun buildRequest() = Request.Builder()
            .url(sseUrl)
            .header("Accept", "text/event-stream")
            .header(HEADER_SKIP_API_KEY, "true")
            .build()

        val eventSource = factory.newEventSource(buildRequest(), object : EventSourceListener() {

            override fun onOpen(eventSource: EventSource, response: Response) {
                debugLog(TAG, "SSE 연결 성공")
                startHeartbeat()
            }

            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                if (data == "null") return

                if (type == "put" || type == "patch") {
                    try {
                        val wrapper = decodeFromString<FirebaseSseWrapperDto>(data)
                        wrapper.data?.let { payloadDto ->
                            emitPayload("SSE", payloadDto)
                        }
                    } catch (e: Exception) {
                        errorLog(TAG, "SSE 데이터 파싱 실패: ${e.message}")
                        errorReporter.report(
                            errorCode = RuntimeFlowErrorCode.SNAPSHOT_PARSE_FAILED,
                            message = "SSE 데이터 파싱 실패: ${e.message}"
                        )
                    }
                }
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                if (isClosed.get()) return
                stopHeartbeat()

                val errorMsg = t?.message ?: "SSE 접속 실패 (코드: ${response?.code})"
                errorLog(TAG, "SSE 연결 끊김 → 재시도 없이 즉시 종료: $errorMsg")
                errorReporter.report(
                    errorCode = RuntimeFlowErrorCode.SSE_DISCONNECTED,
                    message = "SSE 연결 끊김: $errorMsg"
                )

                val exception = when (t) {
                    is GoPassException -> t
                    is IOException -> GoPassException.from(error = ErrorCode.NETWORK_DISCONNECTED)
                    else -> GoPassException.from(
                        error = ErrorCode.SERVER_ERROR,
                        internalCode = InternalErrorCode.SESSION_SERVER_ERROR
                    )
                }
                close(exception)
            }

            override fun onClosed(eventSource: EventSource) {
                stopHeartbeat()
                debugLog(TAG, "SSE 스트림 정상 종료됨")
                close()
            }
        })

        currentEventSource.set(eventSource)

        val bootstrapReadJob = launch {
            try {
                val response = criticalFirebaseApi.getKioskPayload(kioskPayloadUrl, authToken)
                if (!response.isSuccessful) {
                    warnLog(TAG, "[FACE_AUTH][BOOTSTRAP] kiosk_to_user 초기 조회 실패: code=${response.code()}")
                    return@launch
                }

                // RTDB는 빈 노드에 200 + body "null"을 반환 (payload 도착 전 세션 시작이 정상 케이스)
                val body = response.body()?.string()
                if (body == null || body == "null") {
                    debugLog(TAG, "[FACE_AUTH][BOOTSTRAP] kiosk_to_user 초기 데이터 없음")
                    return@launch
                }

                emitPayload("BOOTSTRAP_GET", decodeFromString<KioskToUserPayloadDto>(body))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                warnLog(TAG, "[FACE_AUTH][BOOTSTRAP] kiosk_to_user 초기 조회 예외: ${e.message}")
            }
        }

        awaitClose {
            isClosed.set(true)
            bootstrapReadJob.cancel()
            stopHeartbeat()
            errorLog(TAG, "🛑 SSE 구독 해제 -> EventSource 취소")
            currentEventSource.getAndSet(null)?.cancel()
        }
    }

    override suspend fun updateSession(path: String, authToken: String, data: UserToKioskPayload): Result<Unit> {
        return try {
            val updateUrl = "${BuildConfig.FB_DB_URL}$path/user_to_kiosk.json"
            debugLog(TAG, "updateUrl : $updateUrl")

            val updateDto = UserToKioskPayloadDto(
                payload = data.payload,
                seq = data.seq
            )

            val response = hedgingExecutor.execute(RtdbHedgedOp.SESSION_STATE) {
                criticalFirebaseApi.updateSessionState(updateUrl, authToken, updateDto)
            }

            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(Exception("업데이트 실패: ${response.code()}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun observeAndDecryptFacePayload(
        rtdbPath: String,
        idToken: String,
        sessionId: String,
        dkUser: Key
    ): Flow<FaceVectorPayload> {
        return observeKioskPayload(rtdbPath, idToken)
            .filter { it.encryptedData.isNotEmpty() }
            .mapNotNull { kioskData ->
                decryptAndParsePayload(kioskData, sessionId, dkUser)
            }
    }

    private fun decryptAndParsePayload(
        kioskData: KioskToUserPayload,
        sessionId: String,
        dkUser: Key
    ): FaceVectorPayload? {
        val decryptStartNanos = System.nanoTime()
        // 1. base64 디코딩 + AES-GCM 복호화
        val decryptedBytes = try {
            val aadString = "$sessionId:${kioskData.sequence}:k2u"
            cryptoEngine.decryptData(
                key = dkUser,
                aad = aadString.toByteArray(Charsets.UTF_8),
                encryptedBase64 = kioskData.encryptedData
            )
        } catch (e: IllegalArgumentException) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.PAYLOAD_BASE64_DECODE_FAILED,
                message = "payload base64 디코딩 실패: ${e.message}",
                sessionId = sessionId
            )
            return null
        } catch (e: Exception) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.PAYLOAD_DECRYPT_FAILED,
                message = "payload AES-GCM 복호화 실패: ${e.message}",
                sessionId = sessionId
            )
            return null
        }

        // 2. JSON 파싱
        val jsonString = String(decryptedBytes, Charsets.UTF_8)
        decryptedBytes.wipe()
        val decryptElapsed = (System.nanoTime() - decryptStartNanos) / 1_000_000
        debugLog(TAG, "[FACE_AUTH][DECRYPT] 페이로드 복호화 완료 (${decryptElapsed}ms, json=${jsonString.length}bytes)")

        val payloadDto = try {
            decodeFromString<FaceVectorPayloadDto>(jsonString)
        } catch (e: Exception) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.FACE_VECTOR_JSON_DECODE_FAILED,
                message = "FaceVector JSON 파싱 실패: ${e.message}",
                sessionId = sessionId
            )
            return null
        }

        return payloadDto.toDomain(kioskSequence = kioskData.sequence)
    }
}

package com.ghostpasssdk.gopasssdk.domain.model.internal.error

internal enum class RuntimeFlowErrorCode(val code: String) {

    // ---------------------------------------------------------
    // 1xx – 세션 생성 / 시작 실패
    // ---------------------------------------------------------
    BIOMETRIC_DATA_MISSING("LOG-101"),
    SESSION_RESPONSE_INVALID("LOG-103"),
    TRANSPORT_KEY_LOAD_FAILED("LOG-104"),
    DK_DECRYPT_FAILED("LOG-105"),
    SESSION_EXPIRED("LOG-106"),

    // ---------------------------------------------------------
    // 2xx – 복호화 / 인코딩
    // ---------------------------------------------------------
    DK_BASE64_DECODE_FAILED("LOG-201"),
    DK_AES_GCM_DECRYPT_FAILED("LOG-202"),
    PAYLOAD_BASE64_DECODE_FAILED("LOG-203"),
    PAYLOAD_DECRYPT_FAILED("LOG-204"),
    FACE_VECTOR_JSON_DECODE_FAILED("LOG-205"),
    RESULT_ENCRYPT_FAILED("LOG-206"),

    // ---------------------------------------------------------
    // 4xx – 생체 / 매칭 검증
    // ---------------------------------------------------------
    RECEIVED_VECTOR_EMPTY("LOG-401"),
    STORED_BIOMETRIC_LOAD_FAILED("LOG-402"),
    STORED_BIOMETRIC_PARSE_EMPTY("LOG-403"),
    VECTOR_LENGTH_MISMATCH("LOG-404"),
    DEVICE_ID_NULL("LOG-405"),
    DEVICE_ID_BLANK("LOG-406"),

    // ---------------------------------------------------------
    // 8xx – RTDB write
    // ---------------------------------------------------------
    RTDB_WRITE_FAILED("LOG-801"),

    // ---------------------------------------------------------
    // 9xx – 인프라 / 연결
    // ---------------------------------------------------------
    CONNECTION_LOST("LOG-902"),
    SNAPSHOT_PARSE_FAILED("LOG-903"),
    RESULT_REPORT_FAILED("LOG-904"),
    SESSION_DELETE_FAILED("LOG-905"),
}

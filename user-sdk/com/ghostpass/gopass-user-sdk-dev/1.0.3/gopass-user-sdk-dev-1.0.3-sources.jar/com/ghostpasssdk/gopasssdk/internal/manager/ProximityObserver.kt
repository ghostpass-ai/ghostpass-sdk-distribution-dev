package com.ghostpasssdk.gopasssdk.internal.manager

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconServiceEvents
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.CompareFacesUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.FetchAndDecryptSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.ProcessSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.UpdateSessionResultUseCase
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.useAndWipe
import com.ghostpasssdk.gopasssdk.utils.verboseLog
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import javax.security.auth.Destroyable

internal class ProximityObserver(
    private val fetchAndDecryptSessionUseCase: FetchAndDecryptSessionUseCase,
    private val processSessionUseCase: ProcessSessionUseCase,
    private val compareFacesUseCase: CompareFacesUseCase,
    private val updateSessionResultUseCase: UpdateSessionResultUseCase,
    private val sessionRepository: SessionRepository
) {
    companion object {
        private val TAG = "ProximityObserver ${BuildConfig.SIGNATURE}"
        private const val TARGET_HIT_COUNT = 3 // 목표 감지 횟수
        private const val PAYLOAD_GRACE_MILLIS = 10_000L
        private val COOLDOWN_MILLIS = if (BuildConfig.DEBUG) 30 * 1000L else 60 * 1000L
    }

    private val lifecycleScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val isLifecycleInitialized = AtomicBoolean(false)
    private val isListening = AtomicBoolean(false)

    fun initializeLifecycle() {
        if (!isLifecycleInitialized.compareAndSet(false, true)) {
            debugLog(TAG, "Lifecycle collector already initialized")
            return
        }

        lifecycleScope.launch {
            launch {
                BeaconServiceEvents.beaconAppeared.collect {
                    debugLog(TAG, "📡 비콘 감지 시작 -> 옵저버 Listening 시작")
                    startListening()
                }
            }

            launch {
                BeaconServiceEvents.beaconLost.collect {
                    debugLog(TAG, "⏸️ 비콘 미감지 -> 옵저버 Listening 일시 정지")
                    stopListening()
                }
            }

            launch {
                BeaconServiceEvents.scanStopped.collect {
                    debugLog(TAG, "⏸️ 비콘 스캔 중단 감지 -> 옵저버 Listening 일시 정지")
                    stopListening()
                }
            }
            launch {
                BeaconServiceEvents.serviceDestroyed.collect {
                    debugLog(TAG, "🛑 서비스 완전 종료 감지 -> 진행 중 세션 정리 및 Listening 중단")
                    handleServiceDestroyed()
                }
            }

            launch {
                BeaconServiceEvents.beaconOutOfRange.collect { event ->
                    val beaconKey = "${event.major}_${event.minor}"
                    handleBeaconOutOfRange(beaconKey, event.rssi)
                }
            }
        }
    }
    private val observerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // 비콘 신호 수집만 전담할 코루틴 Job
    private var collectorJob: Job? = null

    // 비콘 기기별 감지 누적 횟수
    private val hitCounts = ConcurrentHashMap<String, Int>()

    // 비콘 기기별 "세션 획득 ~ RTDB 인증 대기" 전체 과정을 담은 Job
    private val activeSessionJobs = ConcurrentHashMap<String, Job>()
    // 비콘 기기별 활성 세션 ID (세션 삭제 API 호출용)
    private val activeSessionIds = ConcurrentHashMap<String, String>()
    private val cooldownMap = ConcurrentHashMap<String, Long>()

    fun startListening() {
        if (!isListening.compareAndSet(false, true)) return

        collectorJob = observerScope.launch {
            BeaconServiceEvents.beaconDetected.collect { event ->
                val beaconKey = "${event.major}_${event.minor}"

                val lastFinishedTime = cooldownMap[beaconKey]
                if (lastFinishedTime != null) {
                    if (System.currentTimeMillis() - lastFinishedTime < COOLDOWN_MILLIS) {
                        return@collect
                    } else {
                        cooldownMap.remove(beaconKey)
                    }
                }

                if (activeSessionJobs.containsKey(beaconKey)) return@collect

                val currentCount = hitCounts.merge(beaconKey, 1) { oldVal, _ -> oldVal + 1 } ?: 1
                debugLog(TAG, "비콘 감지 누적: Key=$beaconKey, 카운트=$currentCount/$TARGET_HIT_COUNT")

                if (currentCount >= TARGET_HIT_COUNT) {
                    hitCounts.remove(beaconKey)
                    handleSessionLifecycle(beaconKey, event.major, event.minor, event.rssi)
                }
            }
        }
    }

    /**
     * FCM으로 전달받은 세션을 비콘 감지 없이 직접 세션 라이프사이클에 주입한다.
     * 복호화는 caller(InfrastructureManager)에서 완료된 상태로 전달받는다.
     * RTDB 관찰 → 얼굴 비교 → 결과 전송 흐름은 비콘 경로와 동일.
     */
    fun delegateSession(decrypted: DecryptedSession) {
        val sessionKey = "fcm_${decrypted.sessionId}"

        val existingJob = activeSessionJobs.putIfAbsent(sessionKey, Job())
        if (existingJob != null) {
            debugLog(TAG, "이미 진행 중인 세션: $sessionKey — 중복 세션 키 파기")
            decrypted.destroySecurely()
            return
        }

        val job = observerScope.launch {
            try {
                debugLog(TAG, "📩 FCM 세션 관찰 시작 (${decrypted.sessionId})")
                activeSessionIds[sessionKey] = decrypted.sessionId
                runSessionObservation(sessionKey, decrypted)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                errorLog(TAG, "FCM 세션 처리 중 에러: ${e.message}")
            } finally {
                activeSessionJobs.remove(sessionKey)
                activeSessionIds.remove(sessionKey)
                resetBeaconStateForRedetection(decrypted)
                debugLog(TAG, "🧹 FCM 세션 자원 정리 완료 ($sessionKey)")
            }
        }

        activeSessionJobs[sessionKey] = job

        // scope 취소 등으로 코루틴이 즉시 취소된 경우 body 미실행 → destroySecurely 수동 호출
        if (job.isCancelled) {
            decrypted.destroySecurely()
            activeSessionJobs.remove(sessionKey)
            activeSessionIds.remove(sessionKey)
        }
    }

    private fun handleSessionLifecycle(beaconKey: String, major: Int, minor: Int, rssi: Int) {
        lateinit var sessionJob: Job
        sessionJob = observerScope.launch(start = CoroutineStart.LAZY) {
            try {
                verboseLog(TAG, "🎯 3회 감지 완료! 세션 API 호출 시작 ($beaconKey)")
                val sessionResponse = fetchAndDecryptSessionUseCase.execute(major, minor, rssi)

                activeSessionIds[beaconKey] = sessionResponse.sessionId
                debugLog(TAG, "✅ 세션 획득 및 복호화 완료! RTDB 인증 대기 시작 (expiresAt 기준)")
                runSessionObservation(beaconKey, sessionResponse)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                errorLog(TAG, "세션 통신 또는 RTDB 처리 중 에러: ${e.message}")
            } finally {
                activeSessionJobs.remove(beaconKey, sessionJob)
                activeSessionIds.remove(beaconKey)
                hitCounts.remove(beaconKey)
                debugLog(TAG, "🧹 세션 자원 로컬 정리 완료. 다시 비콘 신호 수신 대기 ($beaconKey)")
            }
        }

        val existingJob = activeSessionJobs.putIfAbsent(beaconKey, sessionJob)
        if (existingJob != null) {
            sessionJob.cancel()
            return
        }

        sessionJob.start()
    }

    /**
     * FCM 세션 처리 완료 후 해당 비콘 키의 로컬 상태를 초기화하여
     * 비콘 3회 감지 → 세션 생성 사이클이 다시 시작되도록 한다.
     */
    private fun resetBeaconStateForRedetection(session: DecryptedSession) {
        if (session.beaconMajor.isEmpty() || session.beaconMinor.isEmpty()) return
        val beaconKey = "${session.beaconMajor}_${session.beaconMinor}"

        activeSessionJobs.remove(beaconKey)?.cancel()
        activeSessionIds.remove(beaconKey)
        hitCounts.remove(beaconKey)
        cooldownMap.remove(beaconKey)
        debugLog(TAG, "🔄 비콘 상태 초기화 완료 ($beaconKey) → 재감지 대기")
    }

    /**
     * RSSI가 유효 범위를 이탈한 비콘의 활성 세션을 즉시 삭제한다.
     * 서버에 DELETE /api/v1/sessions/{sessionId}를 호출하고 로컬 자원을 정리한다.
     */
    private fun handleBeaconOutOfRange(beaconKey: String, rssi: Int) {
        val sessionId = activeSessionIds[beaconKey] ?: return
        val job = activeSessionJobs[beaconKey] ?: return

        debugLog(TAG, "📡 RSSI 범위 이탈 감지: $beaconKey (RSSI=$rssi) → 세션 [$sessionId] 삭제 요청")

        // cancel()은 cooperative하므로 finally 실행 전까지 시간차가 있다.
        // 즉시 제거하지 않으면 그 사이 중복 beaconOutOfRange 이벤트로 delete API가 이중 호출될 수 있다.
        // finally 블록의 remove()는 정상 종료 경로(타임아웃, 인증 완료)를 위한 안전망이다.
        job.cancel()
        activeSessionJobs.remove(beaconKey)
        activeSessionIds.remove(beaconKey)
        hitCounts.remove(beaconKey)

        observerScope.launch {
            try {
                sessionRepository.deleteSession(sessionId)
                debugLog(TAG, "🗑️ 세션 삭제 API 호출 성공: $sessionId ($beaconKey)")
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                errorLog(TAG, "세션 삭제 API 호출 실패: $sessionId — ${e.message}")
            }
        }
    }

    /**
     * 비콘/FCM 양쪽에서 공유하는 세션 관찰 공통 로직.
     * DecryptedSession을 받아 RTDB 인증 → SSE 관찰 → 얼굴 비교 → 결과 전송을 수행한다.
     */
    private suspend fun runSessionObservation(
        sessionKey: String,
        session: DecryptedSession
    ) {
        try {
            var deadlineMillis = session.expiresAtMillis
            val remainingMillis = deadlineMillis - System.currentTimeMillis()
            if (remainingMillis <= 0) {
                debugLog(TAG, "[AUTH_PROGRESS] 세션 이미 만료됨 ($sessionKey)")
                return
            }
            debugLog(TAG, "[AUTH_PROGRESS] 세션 관찰 시작. 남은 시간=${remainingMillis}ms ($sessionKey)")

            val (facePayloadFlow, idToken) = processSessionUseCase.execute(session)

            var completed = false
            val timedOut = withTimeoutOrNull(remainingMillis + PAYLOAD_GRACE_MILLIS) {
                facePayloadFlow.first { facePayload ->
                    val beforeGraceRemaining = deadlineMillis - System.currentTimeMillis()
                    debugLog(
                        TAG,
                        "[AUTH_PROGRESS] payload 수신. 벡터 크기=${facePayload.vector.size}, ts=${facePayload.timestamp}, 유예 전 남은 시간=${beforeGraceRemaining}ms"
                    )

                    deadlineMillis += PAYLOAD_GRACE_MILLIS
                    debugLog(TAG, "[AUTH_PROGRESS] +${PAYLOAD_GRACE_MILLIS}ms 유예 부여")

                    val compareResult = facePayload.vector.useAndWipe { vector ->
                        compareFacesUseCase.execute(vector)
                    }.also {
                        debugLog(TAG, "🛡️ [보안] 메모리 내 수신된 생체 벡터 데이터 영구 소각 완료")
                    }

                    val isUpdateSuccess = updateSessionResultUseCase.execute(
                        session = session,
                        idToken = idToken,
                        isSuccess = compareResult
                    )
                    debugLog(TAG, "[AUTH_PROGRESS] 인증=$compareResult, 결과 전송=$isUpdateSuccess")

                    deadlineMillis -= PAYLOAD_GRACE_MILLIS
                    val remaining = deadlineMillis - System.currentTimeMillis()
                    debugLog(TAG, "[AUTH_PROGRESS] -${PAYLOAD_GRACE_MILLIS}ms 유예 회수. 남은 시간=${remaining}ms")

                    if (compareResult && isUpdateSuccess) {
                        completed = true
                        cooldownMap[sessionKey] = System.currentTimeMillis()
                        debugLog(TAG, "[AUTH_PROGRESS] 최종 성공. 세션 종료 ($sessionKey)")
                        true
                    } else if (remaining <= 0) {
                        debugLog(TAG, "[AUTH_PROGRESS] 만료. 세션 자연 종료 ($sessionKey)")
                        true
                    } else {
                        debugLog(TAG, "[AUTH_PROGRESS] 인증 실패 OR 서버 전송 실패. ${remaining}ms 남음, 다음 payload 대기")
                        false
                    }
                }
                true
            } == null

            if (timedOut) {
                debugLog(TAG, "[AUTH_PROGRESS] payload 미수신 타임아웃. 세션 자연 종료 ($sessionKey)")
            }
        } finally {
            updateSessionResultUseCase.clearSessionState(session.sessionId)
            session.destroySecurely()
        }
    }

    fun stopListening() {
        if (!isListening.compareAndSet(true, false)) return

        collectorJob?.cancel()
        collectorJob = null

        hitCounts.clear()

        debugLog(TAG, "옵저버 완전 종료")
    }

    private fun handleServiceDestroyed() {
        stopListening()
        observerScope.coroutineContext.cancelChildren()
        activeSessionJobs.clear()
        activeSessionIds.clear()
        hitCounts.clear()
        cooldownMap.clear()
        debugLog(TAG, "🧹 서비스 종료에 따른 세션/쿨다운 자원 정리 완료")
    }

    fun destroy() {
        stopListening()
        lifecycleScope.cancel()
        observerScope.cancel()
        activeSessionJobs.clear()
        activeSessionIds.clear()
        cooldownMap.clear()
        debugLog(TAG, "🛑 옵저버 자원 완전 파기 완료")
    }

    fun destroySessionSecurely(session: DecryptedSession) {
        session.destroySecurely()
    }

    private fun DecryptedSession.destroySecurely() {
        runCatching {
            val destroyableKey = dkUser as? Destroyable
            if (destroyableKey?.isDestroyed == false) {
                destroyableKey.destroy()
                debugLog(TAG, "세션 [$sessionId] dkUser 메모리 안전 파기 완료")
            }
        }.onFailure { e ->
            errorLog(TAG, "세션 [$sessionId] dkUser 파기 실패: ${e.message}")
        }
    }
}

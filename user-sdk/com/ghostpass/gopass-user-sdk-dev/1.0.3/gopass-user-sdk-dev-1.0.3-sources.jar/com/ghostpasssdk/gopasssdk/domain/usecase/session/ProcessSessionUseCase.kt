package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.model.internal.landmark.FaceVectorPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.utils.debugLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

internal class ProcessSessionUseCase(
    private val realtimeSessionRepository: RealtimeSessionRepository
) {

    companion object {
        private val TAG = "ProcessSessionUseCase ${BuildConfig.SIGNATURE}"
    }

    suspend fun execute(session: DecryptedSession): Pair<Flow<FaceVectorPayload>, String> =
        withContext(Dispatchers.IO) {
            debugLog(TAG, "1. 실시간 세션(REST) 로그인 시도...")
            val authToken = realtimeSessionRepository.authenticate(session.firebaseToken)
            debugLog(TAG, "   -> 로그인 성공! ID Token 획득")

            debugLog(TAG, "2. RTDB 경로 SSE 관찰 시작... (상태값 변경 대기 중)")
            val facePayloadFlow = realtimeSessionRepository.observeAndDecryptFacePayload(
                rtdbPath = session.rtdbPath,
                idToken = authToken.idToken,
                sessionId = session.sessionId,
                dkUser = session.dkUser
            )

            return@withContext Pair(facePayloadFlow, authToken.idToken)
        }
}
package com.ghostpasssdk.gopasssdk.data.repository.storage

import android.content.Context
import com.ghostpasssdk.gopasssdk.BuildConfig
import androidx.core.content.edit
import com.ghostpasssdk.gopasssdk.core.security.infra.LocalDataEncryptor
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.utils.errorLog

internal class IdentityRepositoryImpl(
    context: Context,
    private val localDataEncryptor: LocalDataEncryptor
) : IdentityRepository {

    companion object {
        private val TAG = "IdentityRepositoryImpl ${BuildConfig.SIGNATURE}"
        private const val PREF_NAME = "user_identity_prefs"
        private const val PREF_API_KEY = "api_key"
        private const val PREF_BEACON_UUID = "beacon_uuid"
        private const val PREF_INSTALL_ID = "install_id"
        private const val PREF_DEVICE_ID = "device_id"
        private const val PREF_IDENTITY_ID = "identity_id"
        private const val PREF_REGISTERED_AT = "registered_at"
    }

    private val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    // ==========================================
    // Save Methods (Encrypt & Write)
    // ==========================================

    override fun saveApiKey(apiKey: String) {
        val encryptedApiKey = try {
            localDataEncryptor.encrypt(apiKey)
        } catch (e: Exception) {
            errorLog(TAG, "API KEY 암호화 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.API_KEY_ENCRYPT_FAILED
            )
        }

        try {
            val isSaved = prefs.edit()
                .putString(PREF_API_KEY, encryptedApiKey)
                .commit()

            if (!isSaved) {
                errorLog(TAG, "API KEY 디스크 쓰기 실패 (commit=false)")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.API_KEY_SAVE_FAILED
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "API KEY 저장 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.API_KEY_SYSTEM_EXCEPTION
            )
        }
    }

    override fun saveBeaconUuid(beaconUuid: String) {
        val encryptedBeaconUuid = try {
            localDataEncryptor.encrypt(beaconUuid)
        } catch (e: Exception) {
            errorLog(TAG, "BEACON UUID 암호화 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.BEACON_UUID_ENCRYPT_FAILED
            )
        }

        try {
            val isSaved = prefs.edit()
                .putString(PREF_BEACON_UUID, encryptedBeaconUuid)
                .commit()

            if (!isSaved) {
                errorLog(TAG, "BEACON UUID 디스크 쓰기 실패 (commit=false)")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.BEACON_UUID_SAVE_FAILED
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "BEACON UUID 저장 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.BEACON_UUID_SYSTEM_EXCEPTION
            )
        }
    }

    override fun saveInstallId(installId: String) {
        val encryptedInstallId = try {
            localDataEncryptor.encrypt(installId)
        } catch (e: Exception) {
            errorLog(TAG, "INSTALL ID 암호화 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.INSTALL_ID_ENCRYPT_FAILED
            )
        }

        try {
            val isSaved = prefs.edit()
                .putString(PREF_INSTALL_ID, encryptedInstallId)
                .commit()

            if (!isSaved) {
                errorLog(TAG, "INSTALL ID 디스크 쓰기 실패 (commit=false)")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.INSTALL_ID_SAVE_FAILED
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "INSTALL ID 저장 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.INSTALL_ID_SYSTEM_EXCEPTION
            )
        }
    }

    override fun saveDeviceId(deviceId: String) {
        val encryptedDeviceId = try {
            localDataEncryptor.encrypt(deviceId)
        } catch (e: Exception) {
            errorLog(TAG, "DEVICE ID 암호화 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.DEVICE_ID_ENCRYPT_FAILED
            )
        }

        try {
            val isSaved = prefs.edit()
                .putString(PREF_DEVICE_ID, encryptedDeviceId)
                .commit()

            if (!isSaved) {
                errorLog(TAG, "DEVICE ID 디스크 쓰기 실패 (commit=false)")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.DEVICE_ID_SAVE_FAILED
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "DEVICE ID 저장 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.DEVICE_ID_SYSTEM_EXCEPTION
            )
        }
    }

    override fun saveIdentityId(identityId: String) {
        val encryptedIdentityId = try {
            localDataEncryptor.encrypt(identityId)
        } catch (e: Exception) {
            errorLog(TAG, "IDENTITY ID 암호화 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.IDENTITY_ID_ENCRYPT_FAILED
            )
        }

        try {
            val isSaved = prefs.edit()
                .putString(PREF_IDENTITY_ID, encryptedIdentityId)
                .commit()

            if (!isSaved) {
                errorLog(TAG, "IDENTITY ID 디스크 쓰기 실패 (commit=false)")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.IDENTITY_ID_SAVE_FAILED
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "IDENTITY ID 저장 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.IDENTITY_ID_SYSTEM_EXCEPTION
            )
        }
    }

    override fun saveRegisteredAt(registeredAt: Long) {
        val encryptedRegisteredAt = try {
            localDataEncryptor.encrypt(registeredAt.toString())
        } catch (e: Exception) {
            errorLog(TAG, "REGISTERED_AT 암호화 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                internalCode = InternalErrorCode.BIO_DATA_ENCRYPT_FAILED
            )
        }

        try {
            val isSaved = prefs.edit()
                .putString(PREF_REGISTERED_AT, encryptedRegisteredAt)
                .commit()

            if (!isSaved) {
                errorLog(TAG, "REGISTERED_AT 디스크 쓰기 실패 (commit=false)")
                throw GoPassException.from(
                    error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                    internalCode = InternalErrorCode.BIO_DATA_SAVE_FAILED
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "REGISTERED_AT 저장 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                internalCode = InternalErrorCode.BIO_DATA_SAVE_FAILED
            )
        }
    }

    // ==========================================
    // Get Methods (Read & Decrypt)
    // ==========================================

    override fun getApiKey(): String? {
        val encrypted = prefs.getString(PREF_API_KEY, null) ?: return null
        return try {
            localDataEncryptor.decrypt(encrypted)
        } catch (e: Exception) {
            errorLog(TAG, "API KEY 복호화 실패 : $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.API_KEY_DECRYPT_FAILED
            )
        }
    }

    override fun getBeaconUuid(): String? {
        val encrypted = prefs.getString(PREF_BEACON_UUID, null) ?: return null
        return try {
            localDataEncryptor.decrypt(encrypted)
        } catch (e: Exception) {
            errorLog(TAG, "BEACON UUID 복호화 실패 : $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.BEACON_UUID_DECRYPT_FAILED
            )
        }
    }

    override fun getInstallId(): String? {
        val encrypted = prefs.getString(PREF_INSTALL_ID, null) ?: return null
        return try {
            localDataEncryptor.decrypt(encrypted)
        } catch (e: Exception) {
            errorLog(TAG, "INSTALL ID 복호화 실패 : $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.INSTALL_ID_DECRYPT_FAILED
            )
        }
    }

    override fun getDeviceId(): String? {
        val encrypted = prefs.getString(PREF_DEVICE_ID, null) ?: return null
        return try {
            localDataEncryptor.decrypt(encrypted)
        } catch (e: Exception) {
            errorLog(TAG, "DEVICE ID 복호화 실패 : $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.DEVICE_ID_DECRYPT_FAILED
            )
        }
    }

    override fun getIdentityId(): String? {
        val encrypted = prefs.getString(PREF_IDENTITY_ID, null) ?: return null
        return try {
            localDataEncryptor.decrypt(encrypted)
        } catch (e: Exception) {
            errorLog(TAG, "IDENTITY ID 복호화 실패 : $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.IDENTITY_ID_DECRYPT_FAILED
            )
        }
    }

    override fun getRegisteredAt(): Long? {
        if (!prefs.contains(PREF_REGISTERED_AT)) return null
        val encrypted = prefs.getString(PREF_REGISTERED_AT, null) ?: return null
        return try {
            localDataEncryptor.decrypt(encrypted).toLong()
        } catch (e: Exception) {
            errorLog(TAG, "REGISTERED_AT 복호화 실패 : $e")
            throw GoPassException.from(
                error = ErrorCode.INTERNAL_ERROR,
                internalCode = InternalErrorCode.BIO_DATA_DECRYPT_FAILED
            )
        }
    }

    override fun clearRegisteredAt() {
        prefs.edit(commit = true) {
            remove(PREF_REGISTERED_AT)
        }
    }

    override fun clearIdentity() {
        prefs.edit { clear() }
    }
}

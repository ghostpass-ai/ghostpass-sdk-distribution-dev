package com.ghostpasssdk.gopasssdk.data.repository.integrity

import android.content.Context
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.integrity.IntegrityTokenProvider
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.StandardIntegrityManager
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import java.io.IOException

internal class PlayIntegrityTokenProvider(
    private val context: Context
) : IntegrityTokenProvider {
    companion object {
        private val TAG = "PlayIntegrityTokenProvider ${BuildConfig.SIGNATURE}"
    }

    private val prepareMutex = Mutex()
    @Volatile
    private var cachedTokenProvider: StandardIntegrityManager.StandardIntegrityTokenProvider? = null

    override suspend fun fetchIntegrityToken(hash: String): String {
        val tokenProvider = getOrPrepareTokenProvider()

        // Request (실제 토큰 발급)
        val tokenResponse = try {
            tokenProvider.request(
                StandardIntegrityManager.StandardIntegrityTokenRequest.builder()
                    .setRequestHash(hash)
                    .build()
            ).await()
        } catch (e: IOException) {
            errorLog(TAG, "Integrity tokenResponse IO 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.NETWORK_DISCONNECTED
            )
        } catch (e: Exception) {
            // 할당량 초과, 기기 부적합 등 서비스 로직 에러
            errorLog(TAG, "Integrity tokenResponse 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.ATTEST_KEY_GENERATION_FAILED
            )
        }

        debugLog(TAG, "attestation key: ${tokenResponse.token()}")
        return tokenResponse.token()
    }

    private suspend fun getOrPrepareTokenProvider(): StandardIntegrityManager.StandardIntegrityTokenProvider {
        cachedTokenProvider?.let { return it }

        return prepareMutex.withLock {
            cachedTokenProvider?.let { return@withLock it }

            val standardIntegrityManager = IntegrityManagerFactory.createStandard(context)

            try {
                standardIntegrityManager.prepareIntegrityToken(
                    StandardIntegrityManager.PrepareIntegrityTokenRequest.builder()
                        .setCloudProjectNumber(BuildConfig.CLOUD_PROJECT_NUMBER)
                        .build()
                ).await().also { provider ->
                    cachedTokenProvider = provider
                }
            } catch (e: Exception) {
                errorLog(TAG, "Integrity Prepare 실패: $e")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.ATTESTATION_NOT_SUPPORTED
                )
            }
        }
    }
}

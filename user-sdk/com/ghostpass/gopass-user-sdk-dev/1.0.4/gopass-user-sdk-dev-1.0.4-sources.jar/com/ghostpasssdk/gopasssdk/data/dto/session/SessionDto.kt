package com.ghostpasssdk.gopasssdk.data.dto.session

import android.os.Build
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import kotlinx.serialization.Serializable
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

@Serializable
internal data class SessionDto(
    val sessionId: String,
    val rtdbPath: String,
    val encryptedDk: String,
    val firebaseToken: String,
    val status: String,
    val expiresAt: String,
    val beaconMajor: String = "",
    val beaconMinor: String = ""
) {
    fun toDomain(): EncryptedSession = EncryptedSession(
        sessionId = this.sessionId,
        rtdbPath = this.rtdbPath,
        encryptedDk = this.encryptedDk,
        firebaseToken = this.firebaseToken,
        status = this.status,
        expiresAtMillis = parseExpiresAtMillis(),
        beaconMajor = this.beaconMajor,
        beaconMinor = this.beaconMinor
    )

    private fun parseExpiresAtMillis(): Long {
        expiresAt.toLongOrNull()?.let { return it }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                java.time.Instant.parse(expiresAt).toEpochMilli()
            } else {
                val cleaned = expiresAt.substringBefore(".").removeSuffix("Z")
                SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }.parse(cleaned)!!.time
            }
        } catch (e: Exception) {
            throw IllegalArgumentException("Invalid expiresAt format: $expiresAt", e)
        }
    }
}

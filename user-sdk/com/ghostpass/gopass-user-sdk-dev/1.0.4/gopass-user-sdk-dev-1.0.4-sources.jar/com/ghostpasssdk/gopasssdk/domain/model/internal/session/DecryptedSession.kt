package com.ghostpasssdk.gopasssdk.domain.model.internal.session

import java.security.Key

internal data class DecryptedSession(
    val sessionId: String,
    val rtdbPath: String,
    val dkUser: Key,
    val firebaseToken: String,
    val expiresAtMillis: Long,
    val beaconMajor: String,
    val beaconMinor: String
)

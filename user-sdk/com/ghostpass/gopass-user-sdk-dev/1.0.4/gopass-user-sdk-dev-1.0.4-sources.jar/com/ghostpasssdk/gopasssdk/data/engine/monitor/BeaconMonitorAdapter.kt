package com.ghostpasssdk.gopasssdk.data.engine.monitor

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.engine.monitor.MonitoringServiceLauncher
import com.ghostpasssdk.gopasssdk.domain.engine.monitor.ProximityMonitorEngine
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.withTimeoutOrNull

internal class BeaconMonitorAdapter(
    private val serviceLauncher: MonitoringServiceLauncher,
    private val timeoutMillis: Long = TIMEOUT_MILLIS
): ProximityMonitorEngine {

    companion object {
        private val TAG = "BeaconMonitorAdapter ${BuildConfig.SIGNATURE}"
        private const val TIMEOUT_MILLIS = 5000L
    }

    override val isRunning: Boolean
        get() = serviceLauncher.isServiceRunning

    override suspend fun startMonitoring(): Boolean {
        debugLog(TAG, "startMonitoring: 안드로이드 포그라운드 서비스 호출")

        BeaconServiceEvents.clearScanStartEvents()

        try {
            serviceLauncher.launchService()
        } catch (e: Exception) {
            errorLog(TAG, "서비스 시작 실패 (OS 예외): ${e.message}")
            runCatching { serviceLauncher.stopService() }
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.MONITORING_SERVICE_OS_EXCEPTION
            )
        }

        val result = withTimeoutOrNull(timeoutMillis) {
            merge(
                BeaconServiceEvents.monitorReady.map { true },
                BeaconServiceEvents.scanStarted.map { true },
                BeaconServiceEvents.scanStartFailed.map {
                    errorLog(TAG, "서비스 시작 실패됨: $it")
                    runCatching { serviceLauncher.stopService() }
                    false
                }
            ).first()
        }

        if (result == null) {
            runCatching { serviceLauncher.stopService() }
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.MONITORING_SERVICE_TIMEOUT
            )
        }

        if (!result) {
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.MONITORING_SERVICE_START_FAILED
            )
        }

        return true
    }

    override suspend fun stopMonitoring(): Boolean {
        debugLog(TAG, "stopMonitoring: 호출")

        BeaconServiceEvents.clearDestroyEvents()

        runCatching { serviceLauncher.stopService() }

        val result = withTimeoutOrNull(timeoutMillis) {
            BeaconServiceEvents.serviceDestroyed.first()
            true
        }

        if (result == null) {
            errorLog(TAG, "stopMonitoring 타임아웃: 서비스 종료 신호를 받지 못함")
        }
        return result ?: false
    }
}

package com.ghostpasssdk.gopasssdk.domain.usecase.monitor

import com.ghostpasssdk.gopasssdk.domain.engine.monitor.ProximityMonitorEngine
import com.ghostpasssdk.gopasssdk.core.device.domain.DeviceStatusProvider
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class StartProximityMonitorUseCase(
    private val monitorEngine: ProximityMonitorEngine,
    private val landmarkRepository: LandmarkRepository,
    private val identityRepository: IdentityRepository,
    private val deviceStatusProvider: DeviceStatusProvider
) {
    companion object {
        private val TAG = "StartProximityMonitorUseCase ${BuildConfig.SIGNATURE}"
    }
    suspend fun execute(): Boolean = withContext(Dispatchers.Default){
        debugLog(TAG, "비콘 시작 호출")
        if(!landmarkRepository.hasLandmark()){
            debugLog(TAG, "비콘 모니터링을 시작했지만 랜드마크가 존재하지 않습니다.")
            return@withContext false
        }

        validateEnvironment()

        return@withContext monitorEngine.startMonitoring()
    }

    private fun validateEnvironment() {
        if (!deviceStatusProvider.isBluetoothPermissionGranted()) {
            throw GoPassException.from(
                error = ErrorCode.BLUETOOTH_PERMISSION_DENIED,
                internalCode = InternalErrorCode.BLUETOOTH_PERMISSION_DENIED
            )
        }

        if (!deviceStatusProvider.isLocationPermissionGranted()) {
            throw GoPassException.from(
                error = ErrorCode.LOCATION_PERMISSION_DENIED,
                internalCode = InternalErrorCode.LOCATION_PERMISSION_DENIED
            )
        }

        if (!deviceStatusProvider.isLocationPermissionSufficient()) {
            throw GoPassException.from(
                error = ErrorCode.LOCATION_PERMISSION_INSUFFICIENT,
                internalCode = InternalErrorCode.LOCATION_PERMISSION_INSUFFICIENT
            )
        }

        if (identityRepository.getBeaconUuid().isNullOrBlank()) {
            throw GoPassException.from(
                error = ErrorCode.BEACON_UUID_NOT_FOUND,
                internalCode = InternalErrorCode.BEACON_UUID_NOT_FOUND
            )
        }
    }
}

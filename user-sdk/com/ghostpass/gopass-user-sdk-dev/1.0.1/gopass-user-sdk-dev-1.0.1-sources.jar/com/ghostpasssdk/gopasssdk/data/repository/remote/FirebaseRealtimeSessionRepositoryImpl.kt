package com.ghostpasssdk.gopasssdk.data.repository.remote

import com.ghostpasssdk.gopasssdk.data.api.FirebaseApi
import com.ghostpasssdk.gopasssdk.data.dto.firebase.CustomTokenSignInRequest
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.data.dto.firebase.FirebaseSseWrapperDto
import com.ghostpasssdk.gopasssdk.data.dto.firebase.UserToKioskPayloadDto
import com.ghostpasssdk.gopasssdk.data.dto.landmark.FaceVectorPayloadDto
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.AuthToken
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.KioskToUserPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.UserToKioskPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.landmark.FaceVectorPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.utils.wipe
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json.Default.decodeFromString
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import java.io.IOException
import java.security.Key
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.Job

internal class FirebaseRealtimeSessionRepositoryImpl(
    private val firebaseApi: FirebaseApi,
    private val okHttpClient: OkHttpClient,
    private val cryptoEngine: CryptoEngine
) : RealtimeSessionRepository {

    companion object {
        private const val TAG = "FirebaseRTDB Repo TAG"
        private const val SSE_RETRY_DELAY_MS = 2_000L
        private const val SSE_RETRY_TIMEOUT_MS = 60_000L
    }

    override suspend fun authenticate(customToken: String): AuthToken {
        return try {
            val request = CustomTokenSignInRequest(token = customToken, returnSecureToken = true)
            val response = firebaseApi.signInWithCustomToken(BuildConfig.FB_API_KEY, request)

            if (response.isSuccessful) {
                val body = response.body() ?: throw GoPassException.from(
                    error = ErrorCode.SERVER_ERROR,
                    internalCode = InternalErrorCode.SESSION_RESPONSE_INVALID
                )
                AuthToken(idToken = body.idToken)
            } else {
                throw GoPassException.from(
                    error = ErrorCode.SERVER_ERROR,
                    internalCode = InternalErrorCode.SESSION_SERVER_ERROR
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: IOException) {
            throw GoPassException.from(error = ErrorCode.NETWORK_DISCONNECTED)
        } catch (e: Exception) {
            throw GoPassException.from(
                error = ErrorCode.SERVER_ERROR,
                internalCode = InternalErrorCode.SESSION_REQUEST_FAILED
            )
        }
    }

    override fun observeKioskPayload(path: String, authToken: String): Flow<KioskToUserPayload> = callbackFlow {
        val sseUrl = "${BuildConfig.FB_DB_URL}$path/kiosk_to_user.json?auth=$authToken"

        val sseClient = okHttpClient.newBuilder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()

        val factory = EventSources.createFactory(sseClient)
        val currentEventSource = AtomicReference<EventSource?>(null)
        val retryStartTime = AtomicLong(0L)
        val isClosed = AtomicBoolean(false)
        val connectionGeneration = AtomicLong(0L)
        val reconnectJob = AtomicReference<Job?>(null)

        fun buildRequest() = Request.Builder()
            .url(sseUrl)
            .header("Accept", "text/event-stream")
            .header("X-Skip-Signature", "true")
            .build()

        fun connect() {
            if (isClosed.get()) return

            reconnectJob.getAndSet(null)?.cancel()
            val generation = connectionGeneration.incrementAndGet()
            currentEventSource.getAndSet(null)?.cancel()

            if (isClosed.get()) return

            val newEventSource = factory.newEventSource(buildRequest(), object : EventSourceListener() {

                override fun onOpen(eventSource: EventSource, response: Response) {
                    if (connectionGeneration.get() != generation || currentEventSource.get() !== eventSource) {
                        return
                    }

                    val startedAt = retryStartTime.getAndSet(0L)
                    if (startedAt > 0L) {
                        val elapsed = System.currentTimeMillis() - startedAt
                        debugLog(TAG, "SSE 재연결 성공 (${elapsed}ms 경과)")
                    }
                }

                override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                    if (data == "null") return

                    if (type == "put" || type == "patch") {
                        try {
                            val wrapper = decodeFromString<FirebaseSseWrapperDto>(data)
                            wrapper.data?.let { payloadDto ->
                                debugLog(TAG, "📦 진짜 데이터 trySend 발사!")
                                trySend(payloadDto.toDomain())
                            }
                        } catch (e: Exception) {
                            errorLog(TAG, "SSE 데이터 파싱 실패: ${e.message}")
                        }
                    }
                }

                override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                    if (connectionGeneration.get() != generation) return
                    if (!currentEventSource.compareAndSet(eventSource, null)) return

                    val errorMsg = t?.message ?: "SSE 접속 실패 (코드: ${response?.code})"

                    // 네트워크 에러 → 세션 만료(1분) 이내 2초 간격 재연결 시도
                    val startedAt = retryStartTime.updateAndGet {
                        if (it == 0L) System.currentTimeMillis() else it
                    }
                    val elapsed = System.currentTimeMillis() - startedAt

                    if (!isClosed.get() && t is IOException && elapsed < SSE_RETRY_TIMEOUT_MS) {
                        warnLog(TAG, "SSE 네트워크 에러, ${SSE_RETRY_DELAY_MS}ms 후 재연결 (경과 ${elapsed}ms): $errorMsg")
                        val job = launch {
                            delay(SSE_RETRY_DELAY_MS)
                            if (isClosed.get() || connectionGeneration.get() != generation) return@launch
                            connect()
                        }
                        reconnectJob.getAndSet(job)?.cancel()
                        return
                    }

                    errorLog(TAG, errorMsg)
                    val exception = when (t) {
                        is GoPassException -> t
                        is IOException -> GoPassException.from(error = ErrorCode.NETWORK_DISCONNECTED)
                        else -> GoPassException.from(
                            error = ErrorCode.SERVER_ERROR,
                            internalCode = InternalErrorCode.SESSION_SERVER_ERROR
                        )
                    }
                    close(exception)
                }

                override fun onClosed(eventSource: EventSource) {
                    if (connectionGeneration.get() != generation) return
                    if (!currentEventSource.compareAndSet(eventSource, null)) return

                    debugLog(TAG, "SSE 스트림 정상 종료됨")
                    close()
                }
            })

            if (!currentEventSource.compareAndSet(null, newEventSource)) {
                newEventSource.cancel()
            }
        }

        connect()

        awaitClose {
            isClosed.set(true)
            reconnectJob.getAndSet(null)?.cancel()
            debugLog(TAG, "🛑 SSE 구독 해제 -> EventSource 취소")
            currentEventSource.getAndSet(null)?.cancel()
        }
    }

    override suspend fun updateSession(path: String, authToken: String, data: UserToKioskPayload): Result<Unit> {
        return try {
            val updateUrl = "${BuildConfig.FB_DB_URL}$path/user_to_kiosk.json"
            debugLog(TAG, "updateUrl : $updateUrl")

            val updateDto = UserToKioskPayloadDto(
                payload = data.payload,
                seq = data.seq
            )

            val response = firebaseApi.updateSessionState(updateUrl, authToken, updateDto)

            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(Exception("업데이트 실패: ${response.code()}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun observeAndDecryptFacePayload(
        rtdbPath: String,
        idToken: String,
        sessionId: String,
        dkUser: Key
    ): Flow<FaceVectorPayload> {
        return observeKioskPayload(rtdbPath, idToken)
            .filter { it.encryptedData.isNotEmpty() }
            .map { kioskData ->
                // 1. 복호화
                val aadString = "$sessionId:${kioskData.sequence}:k2u"
                val decryptedBytes = cryptoEngine.decryptData(
                    key = dkUser,
                    aad = aadString.toByteArray(Charsets.UTF_8),
                    encryptedBase64 = kioskData.encryptedData
                )

                val jsonString = String(decryptedBytes, Charsets.UTF_8)
                decryptedBytes.wipe()
                debugLog(TAG, "복호화 성공! JSON 길이: ${jsonString.length}")

                // 2. Data 레이어이므로 DTO로 파싱
                val payloadDto = decodeFromString<FaceVectorPayloadDto>(jsonString)

                // 3. 순수 Domain 모델로 매핑해서 리턴
                payloadDto.toDomain()
            }
    }
}

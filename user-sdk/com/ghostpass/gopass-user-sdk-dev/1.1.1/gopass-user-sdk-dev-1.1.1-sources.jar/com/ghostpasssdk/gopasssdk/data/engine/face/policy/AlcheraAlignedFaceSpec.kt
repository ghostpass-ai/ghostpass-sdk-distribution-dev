package com.ghostpasssdk.gopasssdk.data.engine.face.policy

import com.alcherainc.facesdk.type.FeatureExtension.InputAlignedFaceImage

/**
 * 알체라 인식 모델의 정렬 얼굴 입력 규격.
 *
 * 벤더 상수를 그대로 노출해 매직넘버를 만들지 않는다.
 * 벤더 타입 참조를 data 레이어 안에 가두는 역할도 겸한다. (di/domain 레이어가 SDK 타입에 의존하지 않도록)
 *
 * `FeatureExtension.ExtractFeature()` 는 `InputAlignedFaceImage`(112x112x3 BGR) 만 받는
 * 오버로드를 갖는다. `AlignedFaceImageDynamic` 을 받는 오버로드는 존재하지 않으므로,
 * 인식 모델이 이 크기 외의 입력을 받는 경로는 API 상 없다.
 */
internal object AlcheraAlignedFaceSpec {
    val ALIGNED_FACE_WIDTH: Int = InputAlignedFaceImage.kWidth
    val ALIGNED_FACE_HEIGHT: Int = InputAlignedFaceImage.kHeight
}

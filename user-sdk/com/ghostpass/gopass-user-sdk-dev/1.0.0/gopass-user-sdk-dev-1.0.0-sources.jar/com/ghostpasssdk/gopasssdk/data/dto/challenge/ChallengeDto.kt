package com.ghostpasssdk.gopasssdk.data.dto.challenge

import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Challenge
import kotlinx.serialization.Serializable

@Serializable
internal data class ChallengeDto(
    val challenge: String,
    val expiresIn: Long
){
    fun toDomain(): Challenge = Challenge(
        challenge = this.challenge,
        expiresIn = this.expiresIn
    )
}
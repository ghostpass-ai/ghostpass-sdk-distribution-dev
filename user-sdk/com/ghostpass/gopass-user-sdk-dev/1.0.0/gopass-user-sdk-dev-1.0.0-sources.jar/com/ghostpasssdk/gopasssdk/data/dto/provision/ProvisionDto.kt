package com.ghostpasssdk.gopasssdk.data.dto.provision

import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Provision
import kotlinx.serialization.Serializable

@Serializable
internal data class ProvisionDto(
    val serverPublicKey: String,
    val encryptedAppSecret: String,
    val identityId: String,
    val deviceId: String
){
    fun toDomain(): Provision = Provision(
        serverPublicKey = this.serverPublicKey,
        encryptedAppSecret = this.encryptedAppSecret,
        identityId = this.identityId,
        deviceId = this.deviceId
    )
}
package com.ghostpasssdk.gopasssdk.data.dto.session

import kotlinx.serialization.Serializable

@Serializable
internal data class SessionRequest(
    val beaconMajor: Int,
    val beaconMinor: Int,
    val beaconRssi: Int
)

package com.ghostpasssdk.gopasssdk.domain.model.internal.firebase

internal data class AuthToken(
    val idToken: String
)
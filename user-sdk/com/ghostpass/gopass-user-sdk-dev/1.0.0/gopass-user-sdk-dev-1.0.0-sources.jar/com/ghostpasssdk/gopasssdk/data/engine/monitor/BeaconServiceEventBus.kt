package com.ghostpasssdk.gopasssdk.data.engine.monitor

import com.ghostpasssdk.gopasssdk.utils.errorLog
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

@OptIn(ExperimentalCoroutinesApi::class)
internal object BeaconServiceEventBus {

    // ==========================================
    // 1. 스캔 시작 관련 이벤트 (Scan Start)
    // ==========================================
    private val _scanStarted = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val scanStarted = _scanStarted.asSharedFlow()

    private val _scanStartFailed = MutableSharedFlow<String>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val scanStartFailed = _scanStartFailed.asSharedFlow()

    internal fun notifyScanStarted() {
        _scanStopped.resetReplayCache()
        _scanStarted.tryEmit(Unit)
    }

    internal fun notifyScanStartFailed(reason: String) {
        _scanStartFailed.tryEmit(reason)
    }

    internal fun clearScanStartEvents() {
        _scanStarted.resetReplayCache()
        _scanStartFailed.resetReplayCache()
    }


    // ==========================================
    // 2. 스캔 중단 관련 이벤트 (Scan Stop)
    // ==========================================
    private val _scanStopped = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val scanStopped = _scanStopped.asSharedFlow()

    internal fun notifyScanStopped() {
        _scanStopped.tryEmit(Unit)
    }

    internal fun clearScanStopEvents() {
        _scanStopped.resetReplayCache()
    }


    // ==========================================
    // 3. 리전 진입/이탈 이벤트 (Region)
    // ==========================================
    private val _regionEntered = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val regionEntered = _regionEntered.asSharedFlow()

    private val _regionExited = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val regionExited = _regionExited.asSharedFlow()

    internal fun notifyRegionEntered() {
        _regionExited.resetReplayCache()
        _regionEntered.tryEmit(Unit)
    }

    internal fun notifyRegionExited() {
        _regionEntered.resetReplayCache()
        _regionExited.tryEmit(Unit)
    }

    internal fun clearRegionEvents() {
        _regionEntered.resetReplayCache()
        _regionExited.resetReplayCache()
    }


    // ==========================================
    // 4. 서비스 완전 종료/파기 관련 이벤트 (Destroy)
    // ==========================================
    private val _serviceDestroyed = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val serviceDestroyed = _serviceDestroyed.asSharedFlow()

    internal fun notifyServiceDestroyed() {
        val success = _serviceDestroyed.tryEmit(Unit)
        if (!success) {
            errorLog("EventBus", "Destroy 이벤트 발송 실패 (버퍼 가득 참)")
        }
    }

    internal fun clearDestroyEvents() {
        _serviceDestroyed.resetReplayCache()
    }

    // SDK reset 시 모든 Replay 캐시를 비워 재초기화 시 Stale 이벤트 수신 방지
    internal fun resetAllCaches() {
        _scanStarted.resetReplayCache()
        _scanStartFailed.resetReplayCache()
        _scanStopped.resetReplayCache()
        _regionEntered.resetReplayCache()
        _regionExited.resetReplayCache()
        _serviceDestroyed.resetReplayCache()
    }


    // ==========================================
    // 5. 비콘 기기 감지 이벤트 (Detect)
    // ==========================================
    private val _beaconDetected = MutableSharedFlow<BeaconDetectionEvent>(
        extraBufferCapacity = 32,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val beaconDetected = _beaconDetected.asSharedFlow()

    internal fun notifyBeaconDetected(major: Int, minor: Int, rssi: Int) {
        val success = _beaconDetected.tryEmit(BeaconDetectionEvent(major, minor, rssi))
        if (!success) {
            errorLog("EventBus", "비콘 감지 이벤트 발송 실패 (버퍼 오버플로우)")
        }
    }

    data class BeaconDetectionEvent(val major: Int, val minor: Int, val rssi: Int)
}

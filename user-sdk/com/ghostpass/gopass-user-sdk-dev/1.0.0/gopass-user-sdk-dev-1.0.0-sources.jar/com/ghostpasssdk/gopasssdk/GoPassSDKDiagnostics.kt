package com.ghostpasssdk.gopasssdk

import android.content.Context
import androidx.annotation.Keep
import com.ghostpasssdk.gopasssdk.domain.model.external.debug.ChallengeFaultCase
import com.ghostpasssdk.gopasssdk.domain.model.external.debug.ConfigFaultCase
import com.ghostpasssdk.gopasssdk.domain.model.external.debug.ConfirmFaultCase
import com.ghostpasssdk.gopasssdk.domain.model.external.debug.MonitoringFaultCase
import com.ghostpasssdk.gopasssdk.domain.model.external.debug.ProvisionFaultCase
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ProvisionParams
import com.ghostpasssdk.gopasssdk.domain.model.external.debug.SessionFaultCase
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconMonitorAdapter
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconServiceEventBus
import com.ghostpasssdk.gopasssdk.domain.engine.monitor.MonitoringServiceLauncher
import com.ghostpasssdk.gopasssdk.internal.di.SdkContainer
import com.ghostpasssdk.gopasssdk.internal.di.createApiDiagnosticsManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope

@Keep
object GoPassSDKDiagnostics {

    suspend fun debugProvisionLocalValidationWithFault(
        apiKey: String,
        context: Context,
        faultCase: ProvisionFaultCase
    ) {
        val container = SdkContainer.getOrCreate(context)
        val diagnosticsManager = container.createApiDiagnosticsManager()
        diagnosticsManager.provisionForDiagnostics(
            apiKey = apiKey,
            validateRequest = true
        ) { params ->
            params.withProvisionFault(faultCase)
        }
    }

    suspend fun debugProvisionServerMappingWithFault(
        apiKey: String,
        context: Context,
        faultCase: ProvisionFaultCase
    ) {
        val container = SdkContainer.getOrCreate(context)
        val diagnosticsManager = container.createApiDiagnosticsManager()
        diagnosticsManager.provisionForDiagnostics(
            apiKey = apiKey,
            validateRequest = false
        ) { params ->
            params.withProvisionFault(faultCase)
        }
    }

    suspend fun debugChallengeWithFault(
        context: Context,
        faultCase: ChallengeFaultCase
    ) {
        val container = SdkContainer.getOrCreate(context)
        container.createApiDiagnosticsManager().challengeForDiagnostics(
            apiKey = when (faultCase) {
                ChallengeFaultCase.EMPTY_API_KEY -> ""
                ChallengeFaultCase.INVALID_API_KEY -> "invalid-api-key"
            }
        )
    }

    suspend fun debugConfirmWithFault(
        apiKey: String,
        context: Context,
        faultCase: ConfirmFaultCase
    ) {
        val container = SdkContainer.getOrCreate(context)
        val diagnosticsManager = container.createApiDiagnosticsManager()
        diagnosticsManager.confirmForDiagnostics(
            apiKey = apiKey,
            mutate = { params ->
                when (faultCase) {
                    ConfirmFaultCase.EMPTY_IDENTITY_ID -> params.copy(identityId = "")
                    ConfirmFaultCase.INVALID_IDENTITY_ID -> params.copy(identityId = "invalid-identity-id")
                    ConfirmFaultCase.EMPTY_DEVICE_ID -> params.copy(deviceId = "")
                    ConfirmFaultCase.INVALID_DEVICE_ID -> params.copy(deviceId = "invalid-device-id")
                    ConfirmFaultCase.MISSING_HMAC_KEY,
                    ConfirmFaultCase.EMPTY_DEVICE_ID_HEADER -> params
                }
            },
            mutateState = {
                when (faultCase) {
                    ConfirmFaultCase.MISSING_HMAC_KEY -> diagnosticsManager.deleteHmacKeyForDiagnostics()
                    ConfirmFaultCase.EMPTY_DEVICE_ID_HEADER -> container.identityRepository.saveDeviceId("")
                    else -> Unit
                }
            }
        )
    }

    suspend fun debugConfigWithFault(
        apiKey: String,
        context: Context,
        faultCase: ConfigFaultCase
    ) {
        val container = SdkContainer.getOrCreate(context)
        val diagnosticsManager = container.createApiDiagnosticsManager()
        diagnosticsManager.configForDiagnostics(apiKey) {
            when (faultCase) {
                ConfigFaultCase.MISSING_HMAC_KEY -> diagnosticsManager.deleteHmacKeyForDiagnostics()
                ConfigFaultCase.EMPTY_API_KEY_HEADER -> container.identityRepository.saveApiKey("")
                ConfigFaultCase.INVALID_API_KEY_HEADER -> container.identityRepository.saveApiKey("invalid-api-key")
                ConfigFaultCase.EMPTY_DEVICE_ID_HEADER -> container.identityRepository.saveDeviceId("")
                ConfigFaultCase.INVALID_DEVICE_ID_HEADER -> container.identityRepository.saveDeviceId("invalid-device-id")
            }
        }
    }

    suspend fun debugSessionWithFault(
        apiKey: String,
        context: Context,
        faultCase: SessionFaultCase
    ) {
        val container = SdkContainer.getOrCreate(context)
        val diagnosticsManager = container.createApiDiagnosticsManager()
        when (faultCase) {
            SessionFaultCase.MISSING_HMAC_KEY -> {
                diagnosticsManager.sessionForDiagnostics(
                    apiKey = apiKey,
                    mutateState = {
                        diagnosticsManager.deleteHmacKeyForDiagnostics()
                    }
                )
            }

            SessionFaultCase.EMPTY_DEVICE_ID_HEADER -> {
                diagnosticsManager.sessionForDiagnostics(
                    apiKey = apiKey,
                    mutateState = {
                        container.identityRepository.saveDeviceId("")
                    }
                )
            }

            SessionFaultCase.INVALID_DEVICE_ID_HEADER -> {
                diagnosticsManager.sessionForDiagnostics(
                    apiKey = apiKey,
                    mutateState = {
                        container.identityRepository.saveDeviceId("invalid-device-id")
                    }
                )
            }

            else -> {
                diagnosticsManager.sessionForDiagnostics(
                    apiKey = apiKey,
                    mutateParams = { params ->
                        when (faultCase) {
                            SessionFaultCase.ZERO_MAJOR -> params.copy(major = 0)
                            SessionFaultCase.NEGATIVE_MAJOR -> params.copy(major = -1)
                            SessionFaultCase.ZERO_MINOR -> params.copy(minor = 0)
                            SessionFaultCase.NEGATIVE_MINOR -> params.copy(minor = -1)
                            SessionFaultCase.MISSING_HMAC_KEY,
                            SessionFaultCase.EMPTY_DEVICE_ID_HEADER,
                            SessionFaultCase.INVALID_DEVICE_ID_HEADER -> params
                        }
                    }
                )
            }
        }
    }

    suspend fun debugMonitoringWithFault(faultCase: MonitoringFaultCase) {
        val fakeLauncher = object : MonitoringServiceLauncher {
            override val isServiceRunning: Boolean = false
            override fun launchService() {
                if (faultCase == MonitoringFaultCase.OS_EXCEPTION) {
                    throw IllegalStateException("Diagnostics: 포그라운드 서비스 OS 예외 시뮬레이션")
                }
            }
            override fun stopService() = Unit
        }

        val adapter = BeaconMonitorAdapter(
            serviceLauncher = fakeLauncher,
            timeoutMillis = if (faultCase == MonitoringFaultCase.TIMEOUT) 100L else 5000L
        )

        coroutineScope {
            if (faultCase == MonitoringFaultCase.SERVICE_START_FAILED) {
                launch { BeaconServiceEventBus.notifyScanStartFailed("Diagnostics: BLE 스택 오류 시뮬레이션") }
            }
            adapter.startMonitoring()
        }
    }

    private fun ProvisionParams.withProvisionFault(faultCase: ProvisionFaultCase): ProvisionParams = when (faultCase) {
        ProvisionFaultCase.EMPTY_CHALLENGE -> copy(challenge = "")
        ProvisionFaultCase.EMPTY_ATTESTATION -> copy(attestation = "")
        ProvisionFaultCase.EMPTY_PLATFORM -> copy(platform = "")
        ProvisionFaultCase.EMPTY_PLATFORM_ID -> copy(platformId = "")
        ProvisionFaultCase.EMPTY_INSTALL_ID -> copy(installId = "")
        ProvisionFaultCase.EMPTY_CLIENT_PUBLIC_KEY -> copy(clientPublicKey = "")
    }
}

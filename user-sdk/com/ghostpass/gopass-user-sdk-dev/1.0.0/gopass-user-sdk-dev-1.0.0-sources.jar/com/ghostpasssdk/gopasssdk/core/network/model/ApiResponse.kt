package com.ghostpasssdk.gopasssdk.core.network.model

import kotlinx.serialization.Serializable

@Serializable
internal data class ApiResponse<T>(
    val success: Boolean,
    val code: String? = null,
    val message: String? = null,
    val timestamp: String? = null,
    val data: T? = null
)
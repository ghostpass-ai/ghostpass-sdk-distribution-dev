package com.ghostpasssdk.gopasssdk.core.device.domain

internal interface DeviceStatusProvider {
    fun isBluetoothPermissionGranted(): Boolean
    fun isLocationPermissionGranted(): Boolean
    fun isLocationPermissionSufficient(): Boolean
    fun isBluetoothEnabled(): Boolean
    fun isNetworkConnected(): Boolean
    fun isGpsEnabled(): Boolean
}

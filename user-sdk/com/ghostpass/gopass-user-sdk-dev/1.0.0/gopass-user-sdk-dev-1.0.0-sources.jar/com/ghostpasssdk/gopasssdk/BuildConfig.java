/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.ghostpasssdk.gopasssdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.ghostpasssdk.gopasssdk";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "dev";
  // Field from product flavor: dev
  public static final String BASE_URL = "https://newdev.ghostpass.ai/";
  // Field from product flavor: dev
  public static final long CLOUD_PROJECT_NUMBER = 586976457858L;
  // Field from product flavor: dev
  public static final String FB_API_KEY = "AIzaSyC94NBiktKi8sdgWe2kZvs7GltZjxSVWA0";
  // Field from product flavor: dev
  public static final String FB_APP_ID = "1:507647761857:android:a7c29fb3c7ce240fd96340";
  // Field from product flavor: dev
  public static final String FB_DB_URL = "https://gpass-dev-cd816-default-rtdb.asia-southeast1.firebasedatabase.app";
  // Field from product flavor: dev
  public static final String FB_PROJECT_ID = "gpass-dev-cd816";
  // Field from default config.
  public static final String RTDB_IV = "";
  // Field from default config.
  public static final String RTDB_SECRET_KEY = "";
  // Field from default config.
  public static final String SDK_VERSION = "2.1.5";
  // Field from default config.
  public static final String SHARED_KEY = "";
}

package com.ghostpasssdk.gopasssdk.domain.usecase.device

import com.ghostpasssdk.gopasssdk.core.device.domain.DeviceStatusProvider

internal class CheckAllConditionsUseCase(
    private val deviceStatusProvider: DeviceStatusProvider
) {
    enum class Missing { Bluetooth, Network, Gps }

    data class Result(
        val ok: Boolean,
        val missing: Missing?
    )

    operator fun invoke(): Result {
        val bt = deviceStatusProvider.isBluetoothEnabled()
        val net = deviceStatusProvider.isNetworkConnected()
        val gps = deviceStatusProvider.isGpsEnabled()
        val ok = bt && net && gps
        val missing = when {
            !bt -> Missing.Bluetooth
            !gps -> Missing.Gps
            !net -> Missing.Network
            else -> null
        }
        return Result(ok, missing)
    }
}
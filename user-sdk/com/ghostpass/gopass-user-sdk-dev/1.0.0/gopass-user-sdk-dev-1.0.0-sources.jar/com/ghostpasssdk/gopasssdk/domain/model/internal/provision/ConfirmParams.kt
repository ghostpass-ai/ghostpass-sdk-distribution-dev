package com.ghostpasssdk.gopasssdk.domain.model.internal.provision

internal data class ConfirmParams(
    val identityId: String,
    val deviceId: String
)

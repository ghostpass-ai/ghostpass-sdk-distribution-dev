package com.ghostpasssdk.gopasssdk.utils

import android.util.Log
import com.ghostpasssdk.gopasssdk.BuildConfig

internal fun debugLog(tag: String, msg: String) {
    if (BuildConfig.DEBUG) Log.d(tag, msg)
}

internal fun infoLog(tag: String, msg: String) {
    if(BuildConfig.DEBUG) Log.i(tag, msg)
}

internal fun verboseLog(tag: String, msg: String) {
    if(BuildConfig.DEBUG) Log.v(tag, msg)
}
internal fun warnLog(tag: String, msg: String) {
    if(BuildConfig.DEBUG) Log.w(tag, msg)
}

internal fun errorLog(tag: String, msg: String) {
    if (BuildConfig.DEBUG) Log.e(tag, msg)
}
package com.ghostpasssdk.gopasssdk.domain.model.internal.session

internal data class EncryptedSession(
    val sessionId: String,
    val rtdbPath: String,
    val encryptedDk: String,
    val firebaseToken: String,
    val status: String,
    val expiresAt: String
)

package com.ghostpasssdk.gopasssdk.data.dto.firebase

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class UserToKioskPayloadDto(
    val payload: String,
    val seq: Int,
    val ts: FirebaseServerValueDto = FirebaseServerValueDto()
)

@Serializable
internal data class FirebaseServerValueDto(
    @SerialName(".sv") val sv: String = "timestamp"
)

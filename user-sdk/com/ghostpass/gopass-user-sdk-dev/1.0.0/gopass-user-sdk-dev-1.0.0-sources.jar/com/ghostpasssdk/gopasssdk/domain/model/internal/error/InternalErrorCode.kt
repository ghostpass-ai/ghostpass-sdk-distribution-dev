package com.ghostpasssdk.gopasssdk.domain.model.internal.error

internal enum class InternalErrorCode(val code: String) {

    // ---------------------------------------------------------
    // MARK: 4.0 Environment & Permission (IN-0xx)
    // ---------------------------------------------------------
    BLUETOOTH_DISABLED("IN-001"),                  // 블루투스 비활성화
    BLUETOOTH_PERMISSION_DENIED("IN-002"),        // 블루투스 권한 누락
    LOCATION_PERMISSION_DENIED("IN-003"),         // 위치 권한 누락
    LOCATION_PERMISSION_INSUFFICIENT("IN-004"),   // 위치 권한 부족
    BEACON_UUID_NOT_FOUND("IN-005"),              // 비콘 UUID 미저장

    // ---------------------------------------------------------
    // MARK: 4.1 Initialization (IN-1xx)
    // ---------------------------------------------------------
    FACE_ENGINE_MODEL_NOT_FOUND("IN-101"),          // 얼굴 엔진 모델 파일을 찾지 못함
    FACE_SDK_INIT_FAILED("IN-102"),                 // Face SDK 초기화 호출 실패
    FACE_FEATURE_INIT_FAILED("IN-103"),             // 얼굴 특징 추출기 초기화 실패
    FACE_ANTI_SPOOFING_INIT_FAILED("IN-104"),       // 위변조 판별기 초기화 실패
    CONTAINER_IS_NULL("IN-100"),                      // SDK 미초기화 상태에서 호출
    DEVICE_ID_NOT_FOUND("IN-105"),                  // 단말 식별자 조회 실패
    API_KEY_ENCRYPT_FAILED("IN-106"),               // API Key 암호화(인코딩) 실패
    API_KEY_SAVE_FAILED("IN-107"),                  // API Key 저장 실패
    API_KEY_EMPTY("IN-108"),                        // API Key 비어 있음
    SECRET_KEY_NOT_FOUND("IN-109"),                // 저장된 Secret Key를 찾지 못함
    MASTER_KEY_GENERATION_FAILED("IN-110"),        // 마스터 키 생성 실패
    ECDH_KEY_GENERATION_FAILED("IN-111"),          // ECDH 키 생성 실패
    PRIVATE_KEY_NOT_FOUND("IN-112"),               // ECDH 개인키 조회 실패
    SHARED_KEY_DERIVATION_FAILED("IN-113"),        // Shared Key 유도 실패
    MONITORING_SERVICE_OS_EXCEPTION("IN-114"),    // 포그라운드 서비스 시작 OS 예외 (백그라운드 실행 제한 등)
    MONITORING_SERVICE_START_FAILED("IN-115"),    // 비콘 서비스 내부 시작 실패 (BLE 스택 오류 등)
    MONITORING_SERVICE_TIMEOUT("IN-116"),         // 비콘 서비스 시작 응답 타임아웃

    // ---------------------------------------------------------
    // MARK: 4.2 Provisioning & Identity (IN-2xx)
    // ---------------------------------------------------------
    ATTESTATION_NOT_SUPPORTED("IN-201"),            // 현재 단말 환경에서 지원 불가
    ATTEST_KEY_GENERATION_FAILED("IN-202"),         // attest key 생성 실패
    TRANSPORT_KEY_DERIVATION_FAILED("IN-203"),      // transport key 유도 실패
    ATTESTATION_FAILED("IN-204"),                   // 단말 인증 실패
    SERVER_PUBLIC_KEY_DECODE_FAILED("IN-205"),      // 서버 공개키 디코딩 실패
    APP_SECRET_DECODE_FAILED("IN-206"),             // 앱 시크릿 디코딩 실패
    CONFIRM_FAILED("IN-207"),                       // 최종 confirm 처리 실패
    DECRYPTION_FAILED("IN-208"),                    // 프로비저닝 응답 복호화 실패

    IDENTITY_ID_ENCRYPT_FAILED("IN-211"),           // identityId 암호화 실패
    IDENTITY_ID_SAVE_FAILED("IN-212"),              // identityId 저장 실패
    DEVICE_ID_ENCRYPT_FAILED("IN-213"),             // deviceId 암호화 실패
    DEVICE_ID_SAVE_FAILED("IN-214"),                // deviceId 저장 실패

    HMAC_KEY_SE_KEY_FAILED("IN-215"),               // HMAC Key용 Secure Enclave 키 생성 실패
    HMAC_KEY_SAVE_FAILED("IN-217"),                 // HMAC Key 저장 실패
    HMAC_KEY_LOAD_FOR_CONFIRM_FAILED("IN-218"),     // confirm 단계 HMAC Key 로드 실패
    API_KEY_NOT_FOUND("IN-221"),                    // 저장된 API Key 없음
    DEVICE_ID_LOAD_FOR_CONFIRM_FAILED("IN-222"),    // confirm 단계 deviceId 로드 실패

    TRANSPORT_KEY_SE_KEY_FAILED("IN-223"),          // transport key용 Secure Enclave 키 생성 실패
    TRANSPORT_KEY_SAVE_FAILED("IN-225"),            // transport key 저장 실패

    // API: challenge
    CHALLENGE_REQUEST_FAILED("IN-227"),             // challenge API 요청 실패
    CHALLENGE_RESPONSE_INVALID("IN-228"),           // challenge API 응답 형식 오류
    CHALLENGE_SERVER_ERROR("IN-229"),               // challenge API 서버 오류
    CHALLENGE_DECODING_FAILED("IN-230"),            // challenge API 응답 디코딩 실패

    // API: provision
    PROVISION_REQUEST_FAILED("IN-233"),             // provision API 요청 실패
    PROVISION_RESPONSE_INVALID("IN-234"),           // provision API 응답 형식 오류
    PROVISION_SERVER_ERROR("IN-235"),               // provision API 서버 오류
    PROVISION_DECODING_FAILED("IN-236"),            // provision API 응답 디코딩 실패
    PROVISION_ECDH_KEY_ERROR("IN-237"),             // provision API ECDH 키 교환 처리 오류

    // API: confirm
    CONFIRM_REQUEST_FAILED("IN-239"),               // confirm API 요청 실패
    CONFIRM_RESPONSE_INVALID("IN-240"),             // confirm API 응답 형식 오류
    CONFIRM_SERVER_ERROR("IN-241"),                 // confirm API 서버 오류
    CONFIRM_DECODING_FAILED("IN-242"),              // confirm API 응답 디코딩 실패

    // IdentityRepository
    API_KEY_SYSTEM_EXCEPTION("IN-243"),             // API Key 저장 중 시스템 예외
    API_KEY_DECRYPT_FAILED("IN-244"),               // API Key 복호화 실패
    BEACON_UUID_SYSTEM_EXCEPTION("IN-245"),         // Beacon UUID 저장 중 시스템 예외
    BEACON_UUID_DECRYPT_FAILED("IN-246"),           // Beacon UUID 복호화 실패
    INSTALL_ID_ENCRYPT_FAILED("IN-247"),            // Install ID 암호화 실패
    INSTALL_ID_SAVE_FAILED("IN-248"),               // Install ID 디스크 쓰기 실패
    INSTALL_ID_SYSTEM_EXCEPTION("IN-249"),          // Install ID 저장 중 시스템 예외
    INSTALL_ID_DECRYPT_FAILED("IN-250"),            // Install ID 복호화 실패
    DEVICE_ID_SYSTEM_EXCEPTION("IN-251"),           // Device ID 저장 중 시스템 예외
    DEVICE_ID_DECRYPT_FAILED("IN-252"),             // Device ID 복호화 실패
    IDENTITY_ID_SYSTEM_EXCEPTION("IN-253"),         // Identity ID 저장 중 시스템 예외
    IDENTITY_ID_DECRYPT_FAILED("IN-254"),           // Identity ID 복호화 실패


    // ---------------------------------------------------------
    // MARK: 4.3 Config (IN-3xx)
    // ---------------------------------------------------------
    DEVICE_ID_LOAD_FOR_CONFIG_FAILED("IN-302"),     // config 조회 단계 deviceId 로드 실패
    HMAC_KEY_LOAD_FOR_CONFIG_FAILED("IN-303"),      // config 조회 단계 HMAC Key 로드 실패
    BEACON_UUID_ENCRYPT_FAILED("IN-304"),           // Beacon UUID 암호화(인코딩) 실패
    BEACON_UUID_SAVE_FAILED("IN-305"),              // Beacon UUID 저장 실패

    // API: config
    CONFIG_REQUEST_FAILED("IN-307"),                // config API 요청 실패
    CONFIG_RESPONSE_INVALID("IN-308"),              // config API 응답 형식 오류
    CONFIG_SERVER_ERROR("IN-309"),                  // config API 서버 오류
    CONFIG_DECODING_FAILED("IN-310"),               // config API 응답 디코딩 실패
    CONFIG_IDENTIFIER_MISSING("IN-311"),            // config API 식별자 헤더 누락
    CONFIG_HMAC_INVALID("IN-312"),                  // config API HMAC 검증 실패
    CONFIG_TIMESTAMP_EXPIRED("IN-313"),             // config API timestamp 만료
    CONFIG_NONCE_REUSED("IN-314"),                  // config API nonce 재사용


    // ---------------------------------------------------------
    // MARK: 4.4 BioDataRegistration (IN-4xx)
    // ---------------------------------------------------------
    FEATURE_NOT_EXTRACTED("IN-403"),                // 얼굴 특징 벡터 추출 실패
    BIO_DATA_ENCRYPT_FAILED("IN-404"),             // 생체 정보 암호화 실패
    BIO_DATA_SAVE_FAILED("IN-405"),                 // 생체 정보 저장 실패
    INPUT_IMAGE_MEMORY_INSUFFICIENT("IN-406"),      // 입력 이미지 처리 전 메모리 부족
    BIO_DATA_DECRYPT_FAILED("IN-407"),              // 생체 정보 복호화 실패

    // API: session
    SESSION_REQUEST_FAILED("IN-501"),                // session API 요청 실패
    SESSION_RESPONSE_INVALID("IN-502"),              // session API 응답 형식 오류
    SESSION_SERVER_ERROR("IN-503"),                  // session API 서버 오류
    SESSION_DECODING_FAILED("IN-504"),               // session API 응답 디코딩 실패
    SESSION_IDENTIFIER_MISSING("IN-505"),            // session API 식별자 헤더 누락
    SESSION_HMAC_INVALID("IN-506"),                  // session API HMAC 검증 실패
    SESSION_HMAC_KEY_LOAD_FAILED("IN-507"),          // session API 호출 전 HMAC Key 로드 실패
    SESSION_DEVICE_ID_LOAD_FAILED("IN-508"),         // session API 호출 전 deviceId 로드 실패

    // Provision request validation
    PROVISION_CHALLENGE_MISSING("IN-515"),           // provision 요청 challenge 누락
    PROVISION_ATTESTATION_MISSING("IN-516"),         // provision 요청 attestation 누락
    PROVISION_PLATFORM_INVALID("IN-517"),            // provision 요청 platform 값 오류
    PROVISION_PLATFORM_ID_MISSING("IN-518"),         // provision 요청 platformId 누락
    PROVISION_INSTALL_ID_MISSING("IN-519"),          // provision 요청 installId 누락
    PROVISION_CLIENT_PUBLIC_KEY_INVALID("IN-521"),  // provision 요청 clientPublicKey 값 오류

    // ---------------------------------------------------------
    // MARK: 4.5 Push Token (IN-6xx)
    // ---------------------------------------------------------
    PUSH_TOKEN_EMPTY("IN-601"),                      // push token 비어 있음
    PUSH_TOKEN_REQUEST_FAILED("IN-602"),             // push-token API 요청 실패
    PUSH_TOKEN_RESPONSE_INVALID("IN-603"),           // push-token API 응답 형식 오류
    PUSH_TOKEN_SERVER_ERROR("IN-604"),               // push-token API 서버 오류
    PUSH_TOKEN_DECODING_FAILED("IN-605"),            // push-token API 응답 디코딩 실패
    PUSH_TOKEN_HMAC_KEY_LOAD_FAILED("IN-606"),       // push-token API 호출 전 HMAC Key 로드 실패
    PUSH_TOKEN_DEVICE_ID_LOAD_FAILED("IN-607"),      // push-token API 호출 전 deviceId 로드 실패

    // ---------------------------------------------------------
    // MARK: 4.6 HandsFree Session (IN-8xx)
    // ---------------------------------------------------------
    HANDSFREE_PAYLOAD_DECODING_FAILED("IN-801"),     // FCM payload JSON 디코딩 실패
    HANDSFREE_PAYLOAD_INVALID("IN-802"),             // FCM payload 필드 검증 실패
    HANDSFREE_BIO_DATA_NOT_FOUND("IN-803"),          // 생체 데이터 미등록 상태
    HANDSFREE_TRANSPORT_KEY_LOAD_FAILED("IN-804"),   // transport key 로드 실패
    HANDSFREE_DK_DECRYPTION_FAILED("IN-805"),        // DK 복호화 실패
    HANDSFREE_SESSION_EXPIRED("IN-806"),             // 위임 세션 만료
}

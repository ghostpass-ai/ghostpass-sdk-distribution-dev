package com.ghostpasssdk.gopasssdk.domain.engine.face

internal interface FaceCompareEngine {
    suspend fun compare(
        sourceVector: FloatArray,
        targetVector: FloatArray
    ): Float
}
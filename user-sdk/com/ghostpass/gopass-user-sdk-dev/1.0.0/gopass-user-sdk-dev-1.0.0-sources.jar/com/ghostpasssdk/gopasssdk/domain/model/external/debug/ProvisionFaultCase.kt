package com.ghostpasssdk.gopasssdk.domain.model.external.debug

import androidx.annotation.Keep

@Keep
enum class ProvisionFaultCase {
    EMPTY_CHALLENGE,
    EMPTY_ATTESTATION,
    EMPTY_PLATFORM,
    EMPTY_PLATFORM_ID,
    EMPTY_INSTALL_ID,
    EMPTY_CLIENT_PUBLIC_KEY,
}

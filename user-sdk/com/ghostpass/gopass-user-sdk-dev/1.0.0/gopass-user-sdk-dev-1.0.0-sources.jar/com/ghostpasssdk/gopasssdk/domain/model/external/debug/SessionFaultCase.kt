package com.ghostpasssdk.gopasssdk.domain.model.external.debug

import androidx.annotation.Keep

@Keep
enum class SessionFaultCase {
    MISSING_HMAC_KEY,
    ZERO_MAJOR,
    NEGATIVE_MAJOR,
    ZERO_MINOR,
    NEGATIVE_MINOR,
    EMPTY_DEVICE_ID_HEADER,
    INVALID_DEVICE_ID_HEADER,
    ;

    companion object {
        val localValidationCases = listOf(
            MISSING_HMAC_KEY,
            EMPTY_DEVICE_ID_HEADER
        )

        val serverMappingCases = listOf(
            INVALID_DEVICE_ID_HEADER,
            ZERO_MAJOR,
            NEGATIVE_MAJOR,
            ZERO_MINOR,
            NEGATIVE_MINOR
        )
    }
}

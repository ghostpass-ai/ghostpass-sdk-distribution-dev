package com.ghostpasssdk.gopasssdk.data.dto.firebase

import kotlinx.serialization.Serializable

@Serializable
internal data class CustomTokenSignInRequest(
    val token: String,
    val returnSecureToken: Boolean = true
)

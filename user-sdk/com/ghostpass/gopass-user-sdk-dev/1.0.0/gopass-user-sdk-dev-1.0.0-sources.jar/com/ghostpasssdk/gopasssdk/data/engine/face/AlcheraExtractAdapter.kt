package com.ghostpasssdk.gopasssdk.data.engine.face

import com.ghostpasssdk.gopasssdk.data.engine.face.capability.FaceFeatureCapability
import com.ghostpasssdk.gopasssdk.data.engine.face.wrapper.AlcheraDetectedFace
import com.ghostpasssdk.gopasssdk.data.engine.face.wrapper.AlcheraImageFrame
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceExtractEngine
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceEngineTypes
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode

internal class AlcheraExtractAdapter(
    private val capability: FaceFeatureCapability
) : FaceExtractEngine {
    override suspend fun extractLandmarkVector(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FloatArray {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace
        val vector = capability.extractFeature(
            nativeImage,
            nativeFace
        ).feature_vector
        return vector ?: throw GoPassException.from(
            error = ErrorCode.REGISTER_BIO_DATA_FAILED,
            internalCode = InternalErrorCode.FEATURE_NOT_EXTRACTED
        )
    }
}
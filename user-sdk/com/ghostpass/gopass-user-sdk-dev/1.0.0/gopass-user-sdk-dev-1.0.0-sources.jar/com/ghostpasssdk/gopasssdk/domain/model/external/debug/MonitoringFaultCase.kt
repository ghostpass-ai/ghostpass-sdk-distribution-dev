package com.ghostpasssdk.gopasssdk.domain.model.external.debug

import androidx.annotation.Keep

@Keep
enum class MonitoringFaultCase {
    OS_EXCEPTION,
    SERVICE_START_FAILED,
    TIMEOUT,
}

package com.ghostpasssdk.gopasssdk.data.engine.monitor

import android.Manifest
import android.app.ForegroundServiceStartNotAllowedException
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanResult
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.warnLog

/**
 * OS PendingIntent BLE 스캔의 수신자.
 *
 * 앱 프로세스가 종료된 상태에서 BT 칩이 매칭 비콘을 감지하면
 * OS가 이 리시버를 깨운다. 리시버는 게이트키퍼 역할만 수행하고
 * 실제 스캔/인증 로직은 BeaconDetectionService(FGS)에 위임한다.
 *
 * Android 12+ 백그라운드 FGS 시작 조건:
 * ACCESS_BACKGROUND_LOCATION이 런타임에 grant("항상 허용")되어 있어야
 * foregroundServiceType="location" 서비스를 백그라운드에서 시작할 수 있다.
 */
internal class BeaconWakeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_BEACON_WAKE) return

        // 서비스가 이미 살아있으면 ScanCallback이 처리 중 — 중복 방지
        if (BeaconDetectionService.isServiceAlive) return

        val results: List<ScanResult>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra(
                BluetoothLeScanner.EXTRA_LIST_SCAN_RESULT,
                ScanResult::class.java
            )
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableArrayListExtra(BluetoothLeScanner.EXTRA_LIST_SCAN_RESULT)
        }

        if (results.isNullOrEmpty()) return

        // Android 12+: ACCESS_BACKGROUND_LOCATION이 grant 안 되면 FGS 시작 불가
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val hasBgLocation = ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_BACKGROUND_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasBgLocation) {
                warnLog(TAG,
                    "ACCESS_BACKGROUND_LOCATION 미허용 — FGS 시작 불가. " +
                    "마더앱에서 위치 권한을 '항상 허용'으로 설정해야 앱 종료 후에도 비콘 감지가 가능합니다."
                )
                return
            }
        }

        debugLog(TAG, "OS 비콘 감지 wake-up → FGS 기동 (결과 ${results.size}건)")

        try {
            val serviceIntent = Intent(context, BeaconDetectionService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {
            // ForegroundServiceStartNotAllowedException 등 — 크래시 방지
            warnLog(TAG, "FGS 시작 실패 (백그라운드 제한): ${e.message}")
        }
    }

    companion object {
        private const val TAG = "BeaconWakeReceiver TAG"
        const val ACTION_BEACON_WAKE = "com.ghostpasssdk.action.BEACON_WAKE"
        const val WAKE_SCAN_REQUEST_CODE = 0xBEAC
    }
}

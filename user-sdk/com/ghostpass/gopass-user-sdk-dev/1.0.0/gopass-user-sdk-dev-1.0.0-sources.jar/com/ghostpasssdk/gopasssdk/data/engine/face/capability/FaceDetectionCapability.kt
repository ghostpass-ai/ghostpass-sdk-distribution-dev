package com.ghostpasssdk.gopasssdk.data.engine.face.capability

import com.alcherainc.facesdk.type.Face
import com.alcherainc.facesdk.type.Faces
import com.alcherainc.facesdk.type.InputImage
import com.alcherainc.facesdk.type.LandmarkConfidence

internal interface FaceDetectionCapability {
    fun getInputImageFromNV21Buffer(
        faceImage: ByteArray,
        width: Int,
        height: Int,
        rotation: Int,
        var4: Boolean
    ): InputImage

    fun detectFaceInContinuousImage(image: InputImage): Faces
    fun computeLandmarkConfidence(image: InputImage, face: Face): LandmarkConfidence
}
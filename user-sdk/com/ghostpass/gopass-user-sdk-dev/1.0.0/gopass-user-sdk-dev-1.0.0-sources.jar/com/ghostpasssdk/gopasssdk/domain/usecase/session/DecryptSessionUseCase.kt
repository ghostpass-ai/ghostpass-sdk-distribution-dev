package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager
import com.ghostpasssdk.gopasssdk.core.security.infra.EphemeralAesKey
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import com.ghostpasssdk.gopasssdk.utils.wipe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class DecryptSessionUseCase(
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager
) {
    suspend fun execute(encrypted: EncryptedSession): DecryptedSession = withContext(Dispatchers.IO) {
        var decryptedBytes: ByteArray? = null
        val aad = encrypted.sessionId.toByteArray(Charsets.UTF_8)
        val key = keyManager.getSecretKey(KeyManager.TRANSPORT_ALIAS)

        try {
            decryptedBytes = cryptoEngine.decryptData(
                key = key,
                aad = aad,
                encryptedBase64 = encrypted.encryptedDk
            )

            val ephemeralKey = EphemeralAesKey(decryptedBytes)
            decryptedBytes = null

            DecryptedSession(
                sessionId = encrypted.sessionId,
                rtdbPath = encrypted.rtdbPath,
                dkUser = ephemeralKey,
                firebaseToken = encrypted.firebaseToken,
                expiresAt = encrypted.expiresAt
            )
        } finally {
            decryptedBytes.wipe()
        }
    }
}

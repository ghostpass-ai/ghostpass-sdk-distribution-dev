package com.ghostpasssdk.gopasssdk.data.engine.face

import android.content.Context
import com.alcherainc.facesdk.AntispoofingExtension
import com.alcherainc.facesdk.FaceSDK
import com.alcherainc.facesdk.FeatureExtension
import com.alcherainc.facesdk.type.AntispoofingExtension.BGRImageLiveness
import com.alcherainc.facesdk.type.Face
import com.alcherainc.facesdk.type.Faces
import com.alcherainc.facesdk.type.FeatureExtension.FaceFeature
import com.alcherainc.facesdk.type.FeatureExtension.FaceQuality
import com.alcherainc.facesdk.type.FeatureExtension.FeatureDistance
import com.alcherainc.facesdk.type.InputImage
import com.alcherainc.facesdk.type.LandmarkConfidence
import com.ghostpasssdk.gopasssdk.data.engine.face.capability.FaceDetectionCapability
import com.ghostpasssdk.gopasssdk.data.engine.face.capability.FaceFeatureCapability
import com.ghostpasssdk.gopasssdk.data.engine.face.capability.FaceLivenessCapability
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceEngineManager
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.IOException

internal class AlcheraSdkManager(
    private val context: Context
) : FaceEngineManager,
    FaceDetectionCapability,
    FaceFeatureCapability,
    FaceLivenessCapability {
    companion object {
        const val TAG = "AlcheraSdkManager TAG"
    }

    private val initMutex = Mutex()
    @Volatile private var initialized = false

    private val faceSdk: FaceSDK = FaceSDK()
    private lateinit var featureExtension: FeatureExtension
    private lateinit var antispoofingExtension: AntispoofingExtension

    override suspend fun initialize() {
        initMutex.withLock {
            if (initialized) return

            try {
                // 1. 모델 파일 경로 설정 및 복사
                val modelDir = File(context.filesDir, "facesdk/bin").absolutePath
                try {
                    copyModelsIfNeeded(context, "bin", modelDir)
                } catch (e: Exception) {
                    errorLog(TAG, "모델 파일 복사 실패: ${e.message}")
                    throw GoPassException.from(
                        error = ErrorCode.INITIALIZATION_FAILED,
                        internalCode = InternalErrorCode.FACE_ENGINE_MODEL_NOT_FOUND
                    )
                }

                // 2. FaceSDK 코어 초기화
                val initResult = faceSdk.Initialize(modelDir)
                if (!initResult.result) {
                    errorLog(TAG, "FaceSDK 초기화 실패: ${initResult.last_error}")
                    throw GoPassException.from(
                        error = ErrorCode.INITIALIZATION_FAILED,
                        internalCode = InternalErrorCode.FACE_SDK_INIT_FAILED
                    )
                }

                // 3. Feature 확장 모듈 활성화
                featureExtension = faceSdk.GetFeatureExtension().apply {
                    if (!Enable().result) {
                        errorLog(TAG, "FeatureExtension 활성화 실패")
                        throw GoPassException.from(
                            error = ErrorCode.INITIALIZATION_FAILED,
                            internalCode = InternalErrorCode.FACE_FEATURE_INIT_FAILED
                        )
                    }
                }

                // 4. Antispoofing (Liveness) 확장 모듈 활성화
                antispoofingExtension = faceSdk.GetAntispoofingExtension().apply {
                    if (!Enable().result) {
                        errorLog(TAG, "AntispoofingExtension 활성화 실패")
                        throw GoPassException.from(
                            error = ErrorCode.INITIALIZATION_FAILED,
                            internalCode = InternalErrorCode.FACE_ANTI_SPOOFING_INIT_FAILED
                        )
                    }
                }

                initialized = true
                debugLog(TAG, "FaceSDK 초기화 성공")

            } catch (e: GoPassException) {
                throw e
            } catch (e: Exception) {
                // 예상치 못한 시스템 에러 방어
                errorLog(TAG, "초기화 중 알 수 없는 예외 발생: ${e.message}")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.FACE_SDK_INIT_FAILED
                )
            }
        }
    }

    private fun copyModelsIfNeeded(ctx: Context, assetFolder: String, targetDir: String) {
        val target = File(targetDir)
        if (target.exists() && target.listFiles()?.isNotEmpty() == true) return

        val tmp = File(target.parentFile, "${target.name}.tmp")
        if (tmp.exists()) tmp.deleteRecursively()
        if (!tmp.mkdirs()) throw IOException("임시 디렉토리 생성 실패: ${tmp.absolutePath}")

        try {
            copyAssets(ctx, assetFolder, tmp.absolutePath)
            if (tmp.listFiles()?.isEmpty() == true) {
                throw IOException("Asset 폴더가 비어있거나 복사되지 않았습니다.")
            }
            if (target.exists()) target.deleteRecursively()
            if (!tmp.renameTo(target)) {
                throw IOException("임시 폴더를 대상 폴더로 변경하는 데 실패했습니다.")
            }
        } catch (e: Exception) {
            tmp.deleteRecursively()
            throw e
        }
    }

    private fun copyAssets(context: Context, src: String, dst: String) {
        val assetManager = context.assets
        val files = assetManager.list(src) ?: throw IOException("Asset 리스트를 가져올 수 없음: $src")

        for (filename in files) {
            val assetPath = if (src.isEmpty()) filename else "$src/$filename"
            val subFiles = assetManager.list(assetPath)
            if (subFiles?.isNotEmpty() == true) {
                val nextDst = File(dst, filename).apply { mkdirs() }
                copyAssets(context, assetPath, nextDst.absolutePath)
            } else {
                assetManager.open(assetPath).use { input ->
                    File(dst, filename).outputStream().use { out ->
                        input.copyTo(out)
                    }
                }
            }
        }
    }

    override fun getInputImageFromNV21Buffer(
        faceImage: ByteArray,
        width: Int,
        height: Int,
        rotation: Int,
        var4: Boolean
    ): InputImage {
        return FaceSDK.GetInputImageFromNV21Buffer(faceImage, width, height, rotation, var4)
    }

    override fun detectFaceInContinuousImage(image: InputImage): Faces {
        return faceSdk.DetectFaceInContinuousImage(image)
    }

    override fun computeLandmarkConfidence(
        image: InputImage, face: Face
    ): LandmarkConfidence {
        return faceSdk.ComputeLandmarkConfidence(image, face)
    }

    override fun extractFeature(
        image: InputImage,
        face: Face
    ): FaceFeature {
        return featureExtension.ExtractFeature(image, face)
    }

    override fun computeFeatures(
        sourceVector: FloatArray,
        targetVector: FloatArray
    ): FeatureDistance {
        return featureExtension.ComputeDistance(sourceVector, targetVector)
    }

    override fun estimateFaceQuality(
        image: InputImage,
        face: Face,
        returnFeature: Boolean
    ): FaceQuality {
        return featureExtension.EstimateFaceQuality(image, face, returnFeature)
    }

    override fun checkLivenessFromBGRImage(
        i0: InputImage,
        i1: InputImage,
        i2: InputImage,
        i3: InputImage,
        face: Face
    ): BGRImageLiveness {
        return antispoofingExtension.CheckLivenessFromBGRImage(
            i0, i1, i2, i3,face
        )
    }

    override fun resetInputBGRLivenessChecker() {
        antispoofingExtension.ResetInputBGRLivenessChecker()
    }
}
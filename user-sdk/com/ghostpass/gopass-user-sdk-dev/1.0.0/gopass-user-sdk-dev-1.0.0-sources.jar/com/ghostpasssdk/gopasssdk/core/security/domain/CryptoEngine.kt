package com.ghostpasssdk.gopasssdk.core.security.domain

import java.security.Key
import java.security.PrivateKey
import java.security.PublicKey
import javax.crypto.SecretKey

internal interface CryptoEngine {
    /**
     * 서버의 공개키와 내부 개인키를 연산하여 ECDH 기반의 Shared Key를 도출합니다.
     */
    fun deriveSharedKey(key: PrivateKey, serverPublicKey: PublicKey): ByteArray

    /**
     * HKDF 알고리즘을 사용하여 입력된 키 구성 요소(IKM)로부터 256비트(32바이트) 키를 파생합니다.
     */
    fun hkdf(ikm: ByteArray, salt: ByteArray, info: String): ByteArray

    /**
     * AES-GCM 알고리즘을 사용하여 Base64로 인코딩된 암호문을 복호화합니다.
     * @param key 복호화에 사용할 대칭키
     * @param encryptedBase64 복호화할 데이터 (IV + CipherText 조합의 Base64)
     * @param aad 추가 인증 데이터
     */
    fun decryptData(key: Key, encryptedBase64: String, aad: ByteArray): ByteArray

    /**
     * AES-GCM 알고리즘을 사용하여 평문을 암호화합니다.
     * @return IV와 CipherText(+Tag)가 결합된 Base64 인코딩 문자열
     */
    fun encrypt(plainText: String, key: Key, aad: ByteArray): String

    /**
     * HMAC-SHA256 알고리즘을 사용하여 주어진 문자열에 대한 서명(Signature)을 생성합니다.
     * 내부적으로 [KeyManager]에 저장된 HMAC 전용 키를 사용합니다.
     * @return 16진수(Hex) 문자열 형태의 서명
     */
    fun generateHmacSignature(key: SecretKey, stringToSign: String): String

    /**
     * Base64(X.509)로 인코딩된 타원곡선(EC) 공개키 문자열을 PublicKey 객체로 디코딩합니다.
     */
    fun decodeECPublicKey(base64: String): PublicKey

    /**
     * 입력된 문자열을 SHA-256 알고리즘으로 해싱합니다.
     * @return 16진수(Hex) 문자열 형태의 해시값
     */
    fun hashSha256(input: String): String
}
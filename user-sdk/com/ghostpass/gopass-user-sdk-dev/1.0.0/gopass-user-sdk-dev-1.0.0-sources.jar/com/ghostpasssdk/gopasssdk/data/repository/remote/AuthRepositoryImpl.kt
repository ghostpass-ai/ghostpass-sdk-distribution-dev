package com.ghostpasssdk.gopasssdk.data.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.infra.SignedRequestPreflightChecker
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.core.network.utils.safeApiCall
import com.ghostpasssdk.gopasssdk.data.api.AuthApi
import com.ghostpasssdk.gopasssdk.data.dto.confirm.ConfirmRequest
import com.ghostpasssdk.gopasssdk.data.dto.provision.ProvisionRequest
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Challenge
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Config
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Confirm
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ConfirmParams
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Provision
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ProvisionParams
import com.ghostpasssdk.gopasssdk.domain.repository.remote.AuthRepository

internal class AuthRepositoryImpl(
    private val authApi: AuthApi,
    private val signedRequestPreflightChecker: SignedRequestPreflightChecker
) : AuthRepository {

    companion object {
        const val TAG = "AuthRepoImpl TAG"
    }

    override suspend fun challenge(): ApiResult<Challenge> {
        return safeApiCall({ authApi.requestChallenge() }) { it.toDomain() }
    }

    override suspend fun provision(params: ProvisionParams): ApiResult<Provision> {
        val requestDto = ProvisionRequest(
            challenge = params.challenge,
            attestation = params.attestation,
            platform = params.platform,
            platformId = params.platformId,
            installId = params.installId,
            osVersion = params.osVersion,
            appVersion = params.appVersion,
            sdkVersion = params.sdkVersion,
            clientPublicKey = params.clientPublicKey
        )
        return safeApiCall({ authApi.requestProvision(requestDto) }) { it.toDomain() }
    }

    override suspend fun confirm(params: ConfirmParams): ApiResult<Confirm> {
        signedRequestPreflightChecker.ensureConfirmReady()
        val requestDto = ConfirmRequest(
            identityId = params.identityId,
            deviceId = params.deviceId
        )
        return safeApiCall({ authApi.requestConfirm(requestDto) }) { it.toDomain() }
    }

    override suspend fun config(): ApiResult<Config> {
        signedRequestPreflightChecker.ensureConfigReady()
        return safeApiCall({ authApi.requestConfig() }) { it.toDomain() }
    }
}

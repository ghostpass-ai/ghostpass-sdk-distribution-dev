package com.ghostpasssdk.gopasssdk.data.engine.face.capability

import com.alcherainc.facesdk.type.Face
import com.alcherainc.facesdk.type.FeatureExtension.FaceFeature
import com.alcherainc.facesdk.type.FeatureExtension.FeatureDistance
import com.alcherainc.facesdk.type.InputImage

internal interface FaceFeatureCapability {
    fun extractFeature(image: InputImage, face: Face): FaceFeature
    fun computeFeatures(sourceVector: FloatArray, targetVector: FloatArray): FeatureDistance
}
package com.ghostpasssdk.gopasssdk.internal.manager

import android.content.Context
import android.os.Build
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager.Companion.HMAC_ALIAS
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager.Companion.TRANSPORT_ALIAS
import com.ghostpasssdk.gopasssdk.data.repository.mapper.ApiEndpoint
import com.ghostpasssdk.gopasssdk.data.repository.mapper.getOrThrow
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Challenge
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Config
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Confirm
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ConfirmParams
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Provision
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ProvisionParams
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionParams
import com.ghostpasssdk.gopasssdk.domain.repository.integrity.IntegrityTokenProvider
import com.ghostpasssdk.gopasssdk.domain.repository.remote.AuthRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.DeviceIdUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.ProvisionRequestValidator
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.ProvisionUseCase

internal class ApiDiagnosticsManager(
    private val context: Context,
    private val identityRepository: IdentityRepository,
    private val deviceIdUseCase: DeviceIdUseCase,
    private val provisionUseCase: ProvisionUseCase,
    private val authRepository: AuthRepository,
    private val sessionRepository: SessionRepository,
    private val integrityTokenProvider: IntegrityTokenProvider,
    private val keyManager: KeyManager,
) {
    companion object {
        private const val PLATFORM = "ANDROID"
    }

    private val provisionRequestValidator by lazy {
        ProvisionRequestValidator(
            expectedPlatform = PLATFORM,
            publicKeyValidator = provisionUseCase::isValidPublicKey
        )
    }

    suspend fun challengeForDiagnostics(apiKey: String): Challenge = runDiagnostic {
        identityRepository.saveApiKey(apiKey)
        authRepository.challenge().getOrThrow(ApiEndpoint.CHALLENGE)
    }

    suspend fun provisionForDiagnostics(
        apiKey: String,
        validateRequest: Boolean = true,
        mutate: (ProvisionParams) -> ProvisionParams = { it }
    ): Provision = runDiagnostic {
        identityRepository.saveApiKey(apiKey)
        deviceIdUseCase.getOrCreate()
        val request = mutate(createProvisionRequest()).also { params ->
            if (validateRequest) {
                provisionRequestValidator.validate(params)
            }
        }
        authRepository.provision(request).getOrThrow(ApiEndpoint.PROVISION)
    }

    suspend fun confirmForDiagnostics(
        apiKey: String,
        mutate: (ConfirmParams) -> ConfirmParams = { it },
        mutateState: () -> Unit = {}
    ): Confirm = runDiagnostic {
        val provision = prepareProvisionedIdentity(apiKey)
        mutateState()
        val request = mutate(
            ConfirmParams(
                identityId = provision.identityId,
                deviceId = provision.deviceId
            )
        )
        authRepository.confirm(request).getOrThrow(ApiEndpoint.CONFIRM)
    }

    suspend fun configForDiagnostics(
        apiKey: String,
        mutateState: () -> Unit = {}
    ): Config = runDiagnostic {
        prepareConfirmedIdentity(apiKey)
        mutateState()
        authRepository.config().getOrThrow(ApiEndpoint.CONFIG)
    }

    suspend fun sessionForDiagnostics(
        apiKey: String,
        mutateParams: (SessionParams) -> SessionParams = { it },
        mutateState: () -> Unit = {}
    ): EncryptedSession = runDiagnostic {
        prepareConfirmedIdentity(apiKey)
        mutateState()
        val request = mutateParams(
            SessionParams(
                major = 1,
                minor = 1,
                rssi = -80
            )
        )
        sessionRepository.sessions(request).getOrThrow(ApiEndpoint.SESSION)
    }

    private suspend fun prepareProvisionedIdentity(apiKey: String): Provision {
        identityRepository.saveApiKey(apiKey)
        deviceIdUseCase.getOrCreate()

        val provision = authRepository.provision(createProvisionRequest())
            .getOrThrow(ApiEndpoint.PROVISION)

        provisionUseCase.processKeyExchange(
            apiKey = apiKey,
            provision = provision
        )
        identityRepository.saveIdentityId(provision.identityId)
        identityRepository.saveDeviceId(provision.deviceId)
        return provision
    }

    private suspend fun prepareConfirmedIdentity(apiKey: String): Provision {
        val provision = prepareProvisionedIdentity(apiKey)
        authRepository.confirm(
            ConfirmParams(
                identityId = provision.identityId,
                deviceId = provision.deviceId
            )
        ).getOrThrow(ApiEndpoint.CONFIRM)
        return provision
    }

    private suspend fun createProvisionRequest(): ProvisionParams {
        val challenge = authRepository.challenge().getOrThrow(ApiEndpoint.CHALLENGE)
        val token = integrityTokenProvider.fetchIntegrityToken(challenge.challenge)
        val appVersion =
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown"

        return ProvisionParams(
            challenge = challenge.challenge,
            attestation = token,
            platform = PLATFORM,
            platformId = deviceIdUseCase.getPlatformId(),
            installId = deviceIdUseCase.getInstallId(),
            osVersion = Build.VERSION.RELEASE,
            appVersion = appVersion,
            sdkVersion = BuildConfig.SDK_VERSION,
            clientPublicKey = provisionUseCase.generatePublicKey()
        )
    }

    private suspend fun <T> runDiagnostic(block: suspend () -> T): T {
        cleanupDiagnosticState()
        return try {
            block()
        } finally {
            cleanupDiagnosticState()
        }
    }

    private fun cleanupDiagnosticState() {
        identityRepository.clearIdentity()
        keyManager.deleteKey(HMAC_ALIAS)
        keyManager.deleteKey(TRANSPORT_ALIAS)
    }

    fun deleteHmacKeyForDiagnostics() {
        keyManager.deleteKey(HMAC_ALIAS)
    }
}

package com.ghostpasssdk.gopasssdk.data.repository.mapper

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClientException
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import java.io.IOException

internal fun <T> ApiResult<T>.getOrThrow(
    endpoint: ApiEndpoint
): T = when (this) {
    is ApiResult.Success -> data
    is ApiResult.Failure -> throw toGoPassException(endpoint)
    is ApiResult.NetworkError -> throw toGoPassException(endpoint)
}

private fun ApiResult.Failure.toGoPassException(endpoint: ApiEndpoint): GoPassException {
    if (endpoint == ApiEndpoint.SESSION && code == "SDK-9204") {
        return GoPassException.from(
            error = ErrorCode.SERVER_ERROR,
            customMessage = message
        )
    }

    if (endpoint != ApiEndpoint.PROVISION && code.isPassThroughServerMessageError()) {
        return GoPassException.from(
            error = ErrorCode.SERVER_ERROR,
            customMessage = message
        )
    }

    if (code.isSensitiveServerError()) {
        return GoPassException.from(
            error = ErrorCode.SERVER_ERROR,
            internalCode = endpoint.toSensitiveInternalErrorCode(code)
        )
    }

    // SDK 비즈니스 에러 → 기존 직접 매핑 (서버 메시지 전달)
    if (code.isUserVisibleServerError()) {
        if (endpoint == ApiEndpoint.PROVISION) {
            return GoPassException.from(
                error = code.toExternalErrorCode(),
                internalCode = code.toProvisionInternalErrorCode()
            )
        }

        return GoPassException.from(
            error = code.toExternalErrorCode(),
            customMessage = message
        )
    }

    // 그 외 → SERVER_ERROR + endpoint별 InternalErrorCode
    val internalCode = when (code) {
        "PARSE_ERROR" -> endpoint.decodingFailed
        "EMPTY_BODY", "MISSING_DATA", "C-1001" -> endpoint.responseInvalid
        else -> endpoint.serverError
    }

    val customMessage = when {
        endpoint == ApiEndpoint.PROVISION -> null
        code == "PARSE_ERROR" || code == "EMPTY_BODY" || code == "MISSING_DATA" -> null
        else -> message
    }

    return GoPassException.from(
        error = ErrorCode.SERVER_ERROR,
        customMessage = customMessage,
        internalCode = internalCode
    )
}

private fun String?.toProvisionInternalErrorCode(): InternalErrorCode = when (this) {
    "SDK-9100" -> InternalErrorCode.ATTESTATION_FAILED
    "SDK-9101" -> InternalErrorCode.ATTESTATION_NOT_SUPPORTED
    "SDK-9109" -> InternalErrorCode.PROVISION_ECDH_KEY_ERROR
    else -> InternalErrorCode.PROVISION_SERVER_ERROR
}

private fun ApiEndpoint.toSensitiveInternalErrorCode(code: String?): InternalErrorCode = when (this) {
    ApiEndpoint.CONFIG -> when (code) {
        "SDK-9010", "HMAC_INVALID" -> InternalErrorCode.CONFIG_HMAC_INVALID
        "SDK-9011", "TIMESTAMP_EXPIRED" -> InternalErrorCode.CONFIG_TIMESTAMP_EXPIRED
        "SDK-9012", "NONCE_REUSED" -> InternalErrorCode.CONFIG_NONCE_REUSED
        "SDK-9013", "MISSING_IDENTIFIER" -> InternalErrorCode.CONFIG_IDENTIFIER_MISSING
        else -> serverError
    }

    ApiEndpoint.SESSION -> when (code) {
        "SDK-9010", "HMAC_INVALID" -> InternalErrorCode.SESSION_HMAC_INVALID
        "SDK-9013", "MISSING_IDENTIFIER" -> InternalErrorCode.SESSION_IDENTIFIER_MISSING
        else -> serverError
    }

    else -> serverError
}

private fun ApiResult.NetworkError.toGoPassException(endpoint: ApiEndpoint): GoPassException {
    if (error is ApiClientException) return error.goPassException

    if (error is GoPassException) return error

    if (error is IOException) {
        return GoPassException.from(error = ErrorCode.NETWORK_DISCONNECTED)
    }

    return GoPassException.from(
        error = ErrorCode.SERVER_ERROR,
        internalCode = endpoint.requestFailed
    )
}

private fun String?.toExternalErrorCode(): ErrorCode = when (this) {
    "SDK-9000" -> ErrorCode.SDK_SERVICE_NOT_FOUND
    "SDK-9001" -> ErrorCode.SDK_SERVICE_INACTIVE
    "SDK-9002" -> ErrorCode.SDK_SERVICE_CODE_DUPLICATE
    "SDK-9003" -> ErrorCode.SDK_API_KEY_DUPLICATE
    else -> ErrorCode.SERVER_ERROR
}

private fun String?.isUserVisibleServerError(): Boolean = when (this) {
    // ---------------------------------------------------------
    // 서비스 / API Key (SDK-900x)
    // ---------------------------------------------------------
    "SDK-9000", // SDK_SERVICE_NOT_FOUND
    "SDK-9001", // SDK_SERVICE_INACTIVE
    "SDK-9002", // SDK_SERVICE_CODE_DUPLICATE
    "SDK-9003", // SDK_API_KEY_DUPLICATE

        // ---------------------------------------------------------
        // KMS (SDK-902x)
        // ---------------------------------------------------------
    "SDK-9020", // SDK_KMS_ERROR

        // ---------------------------------------------------------
        // Provisioning / Attestation / Identity / Device (SDK-910x)
        // ---------------------------------------------------------
    "SDK-9100", // SDK_ATTESTATION_FAILED
    "SDK-9101", // SDK_ATTESTATION_PLATFORM_UNSUPPORTED
    "SDK-9102", // SDK_PROVISION_SESSION_NOT_FOUND
    "SDK-9103", // SDK_PROVISION_SESSION_EXPIRED
    "SDK-9104", // SDK_IDENTITY_NOT_FOUND
    "SDK-9105", // SDK_IDENTITY_INACTIVE
    "SDK-9106", // SDK_DEVICE_NOT_FOUND
    "SDK-9107", // SDK_DEVICE_INACTIVE
    "SDK-9108", // SDK_IDENTITY_CONFIRM_FAILED
    "SDK-9109", // SDK_ECDH_KEY_ERROR
    "SDK-9110"  // (이름 미지정, 401 Unauthorized)
        -> true

    else -> false
}

private fun String?.isSensitiveServerError(): Boolean = when (this) {
    "SDK-9010", // SDK_HMAC_INVALID
    "SDK-9011", // SDK_TIMESTAMP_EXPIRED
    "SDK-9012", // SDK_NONCE_REUSED
    "SDK-9013", // SDK_HMAC_MISSING_IDENTIFIER
    "HMAC_INVALID",
    "TIMESTAMP_EXPIRED",
    "NONCE_REUSED",
    "MISSING_IDENTIFIER"
        -> true

    else -> false
}

private fun String?.isPassThroughServerMessageError(): Boolean = when (this) {
    "MISSING_API_KEY",
    "INVALID_API_KEY"
        -> true

    else -> false
}

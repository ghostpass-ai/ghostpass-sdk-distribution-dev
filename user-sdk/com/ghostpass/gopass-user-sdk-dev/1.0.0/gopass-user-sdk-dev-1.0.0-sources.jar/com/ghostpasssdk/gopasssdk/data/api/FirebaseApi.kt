package com.ghostpasssdk.gopasssdk.data.api

import com.ghostpasssdk.gopasssdk.data.dto.firebase.CustomTokenSignInDto
import com.ghostpasssdk.gopasssdk.data.dto.firebase.CustomTokenSignInRequest
import com.ghostpasssdk.gopasssdk.data.dto.firebase.UserToKioskPayloadDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

internal interface FirebaseApi {
    @Headers("X-Skip-Signature: true")
    @POST("https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken")
    suspend fun signInWithCustomToken(
        @Query("key") apiKey: String, // Firebase Web API Key
        @Body request: CustomTokenSignInRequest
    ): Response<CustomTokenSignInDto>

    @Headers("X-Skip-Signature: true")
    @PATCH
    suspend fun updateSessionState(
        @Url url: String,
        @Query("auth") auth: String,
        @Body data: UserToKioskPayloadDto
    ): Response<Unit>
}
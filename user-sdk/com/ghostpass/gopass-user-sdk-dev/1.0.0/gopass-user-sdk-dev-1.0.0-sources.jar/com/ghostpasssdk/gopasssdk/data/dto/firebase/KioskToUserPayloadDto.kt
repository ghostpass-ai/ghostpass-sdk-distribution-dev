package com.ghostpasssdk.gopasssdk.data.dto.firebase

import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.KioskToUserPayload
import kotlinx.serialization.Serializable

@Serializable
internal data class KioskToUserPayloadDto(
    val payload: String,
    val seq: Int,
    val ts: Long
) {
    fun toDomain(): KioskToUserPayload = KioskToUserPayload(
        encryptedData = this.payload,
        sequence = this.seq,
        timestamp = this.ts
    )
}

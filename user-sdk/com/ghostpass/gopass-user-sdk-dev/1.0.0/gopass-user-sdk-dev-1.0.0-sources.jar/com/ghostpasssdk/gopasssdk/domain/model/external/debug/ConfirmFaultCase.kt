package com.ghostpasssdk.gopasssdk.domain.model.external.debug

import androidx.annotation.Keep

@Keep
enum class ConfirmFaultCase {
    MISSING_HMAC_KEY,
    EMPTY_DEVICE_ID_HEADER,
    EMPTY_IDENTITY_ID,
    INVALID_IDENTITY_ID,
    EMPTY_DEVICE_ID,
    INVALID_DEVICE_ID,
}

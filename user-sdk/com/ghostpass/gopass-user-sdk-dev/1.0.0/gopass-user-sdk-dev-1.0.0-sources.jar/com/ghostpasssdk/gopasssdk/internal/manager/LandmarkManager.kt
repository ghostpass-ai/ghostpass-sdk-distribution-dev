package com.ghostpasssdk.gopasssdk.internal.manager

import android.view.Surface
import com.ghostpasssdk.gopasssdk.domain.model.external.BioDataFrameStatus
import com.ghostpasssdk.gopasssdk.domain.model.external.HasBioDataResult
import com.ghostpasssdk.gopasssdk.domain.model.external.CaptureGuide
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceExtractResult
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.FaceRegisterUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StartProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StopProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog


internal class LandmarkManager(
    private val faceRegisterUseCase: FaceRegisterUseCase,
    private val landmarkRepository: LandmarkRepository,
    private val identityRepository: IdentityRepository,
    private val startProximityMonitorUseCase: StartProximityMonitorUseCase,
    private val stopProximityMonitorUseCase: StopProximityMonitorUseCase
) {
    companion object {
        private const val TAG = "LandmarkManager TAG"
    }

    suspend fun saveLandmark(
        faceImage: ByteArray,
        width: Int,
        height: Int,
        rotation: Int
    ): BioDataFrameStatus {

        if (landmarkRepository.hasLandmark()) {
            ensureProximityMonitoringStarted()
            return BioDataFrameStatus.Success
        }

        val surfaceRotation =  mapToSurfaceRotation(rotation)

        val extractResult = faceRegisterUseCase.execute(
            faceImage = faceImage,
            width = width,
            height = height,
            rotation = surfaceRotation
        )

        return when (extractResult) {
            is FaceExtractResult.Success -> {
                landmarkRepository.saveLandmark(extractResult.landmark)
                try {
                    identityRepository.saveRegisteredAt(System.currentTimeMillis())
                } catch (e: Exception) {
                    landmarkRepository.deleteLandmark()
                    throw e
                }
                ensureProximityMonitoringStarted()
                BioDataFrameStatus.Success
            }

            is FaceExtractResult.Continue -> {
                if (extractResult.reason == CaptureGuide.ALREADY_COMPLETED) {
                    BioDataFrameStatus.Success
                } else {
                    BioDataFrameStatus.ContinueCapture(extractResult.reason)
                }
            }
        }
    }

    suspend fun deleteLandmark(): Boolean {
        faceRegisterUseCase.resetCompletedState()
        val isDeleted = landmarkRepository.deleteLandmark()

        if (isDeleted) {
            identityRepository.clearRegisteredAt()
            debugLog(TAG, "랜드마크 삭제됨 -> 비콘 스캔 중지 요청")
            try {
                val isStopped = stopProximityMonitorUseCase.execute()
                debugLog(TAG, "비콘 스캔 중지 결과: $isStopped")
            } catch (e: Exception) {
                errorLog(TAG, "비콘 스캔 중지 중 에러 발생: ${e.message}")
            }
        }

        return isDeleted
    }

    fun getHasBioDataResult(): HasBioDataResult = landmarkRepository.getHasBioDataResult()

    private suspend fun ensureProximityMonitoringStarted() {
        try {
            val isStarted = startProximityMonitorUseCase.execute()
            debugLog(TAG, "비콘 스캔 시작 요청 결과: $isStarted")
        } catch (e: GoPassException) {
            errorLog(TAG, "비콘 스캔 시작 중 에러 발생: ${e.message}")
            if (e.isRetryableMonitoringError()) {
                throw e
            }
        } catch (e: Exception) {
            errorLog(TAG, "비콘 스캔 시작 중 에러 발생: ${e.message}")
        }
    }

    private fun mapToSurfaceRotation(degrees: Int): Int {
        return when (degrees) {
            270 -> Surface.ROTATION_270
            0 -> Surface.ROTATION_0
            90 -> Surface.ROTATION_90
            180 -> Surface.ROTATION_180
            else -> Surface.ROTATION_270
        }
    }

    private fun GoPassException.isRetryableMonitoringError(): Boolean {
        return code == ErrorCode.BLUETOOTH_DISABLED.externalCode ||
            code == ErrorCode.BLUETOOTH_PERMISSION_DENIED.externalCode ||
            code == ErrorCode.LOCATION_PERMISSION_DENIED.externalCode ||
            code == ErrorCode.LOCATION_PERMISSION_INSUFFICIENT.externalCode ||
            code == ErrorCode.BEACON_UUID_NOT_FOUND.externalCode
    }
}

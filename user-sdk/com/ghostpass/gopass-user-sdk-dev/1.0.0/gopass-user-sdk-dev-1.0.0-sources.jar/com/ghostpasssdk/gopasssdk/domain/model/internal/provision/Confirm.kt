package com.ghostpasssdk.gopasssdk.domain.model.internal.provision

internal data class Confirm(
    val confirmed: Boolean,
    val message: String
)

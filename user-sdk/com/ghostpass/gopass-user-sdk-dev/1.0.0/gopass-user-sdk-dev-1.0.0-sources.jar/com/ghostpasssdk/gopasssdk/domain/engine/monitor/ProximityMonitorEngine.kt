package com.ghostpasssdk.gopasssdk.domain.engine.monitor

internal interface ProximityMonitorEngine {
    val isRunning: Boolean
    suspend fun startMonitoring(): Boolean
    suspend fun stopMonitoring(): Boolean
}
package com.ghostpasssdk.gopasssdk.domain.repository.storage

import com.ghostpasssdk.gopasssdk.domain.model.external.HasBioDataResult

internal interface LandmarkRepository {
    suspend fun saveLandmark(landmark: FloatArray)
    suspend fun deleteLandmark(): Boolean
    fun hasLandmark(): Boolean
    fun getHasBioDataResult(): HasBioDataResult
    suspend fun loadLandmark(): FloatArray
}

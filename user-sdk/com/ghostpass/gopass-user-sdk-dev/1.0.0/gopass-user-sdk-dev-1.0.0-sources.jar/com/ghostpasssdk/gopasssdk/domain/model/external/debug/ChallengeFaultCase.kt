package com.ghostpasssdk.gopasssdk.domain.model.external.debug

import androidx.annotation.Keep

@Keep
enum class ChallengeFaultCase {
    EMPTY_API_KEY,
    INVALID_API_KEY,
}

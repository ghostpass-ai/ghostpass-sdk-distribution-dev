package com.ghostpasssdk.gopasssdk.domain.usecase.monitor

import com.ghostpasssdk.gopasssdk.domain.engine.monitor.ProximityMonitorEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class StopProximityMonitorUseCase(
    private val monitorEngine: ProximityMonitorEngine
) {
    suspend fun execute(): Boolean = withContext(Dispatchers.Default) {
        if(!monitorEngine.isRunning){
            return@withContext true
        }
        return@withContext monitorEngine.stopMonitoring()
    }
}
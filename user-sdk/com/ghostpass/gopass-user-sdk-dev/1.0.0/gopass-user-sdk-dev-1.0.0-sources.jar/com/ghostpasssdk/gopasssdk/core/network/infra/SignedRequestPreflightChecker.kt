package com.ghostpasssdk.gopasssdk.core.network.infra

import com.ghostpasssdk.gopasssdk.core.security.infra.RequestSigner
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository

internal class SignedRequestPreflightChecker(
    private val identityRepository: IdentityRepository,
    private val requestSigner: RequestSigner
) {

    fun ensureConfirmReady() {
        ensureReady(
            missingHmacCode = InternalErrorCode.HMAC_KEY_LOAD_FOR_CONFIRM_FAILED,
            missingDeviceIdCode = InternalErrorCode.DEVICE_ID_LOAD_FOR_CONFIRM_FAILED
        )
    }

    fun ensureConfigReady() {
        ensureReady(
            missingHmacCode = InternalErrorCode.HMAC_KEY_LOAD_FOR_CONFIG_FAILED,
            missingDeviceIdCode = InternalErrorCode.DEVICE_ID_LOAD_FOR_CONFIG_FAILED
        )
    }

    fun ensureSessionReady() {
        ensureReady(
            missingHmacCode = InternalErrorCode.SESSION_HMAC_KEY_LOAD_FAILED,
            missingDeviceIdCode = InternalErrorCode.SESSION_DEVICE_ID_LOAD_FAILED
        )
    }

    fun ensurePushTokenReady() {
        ensureReady(
            missingHmacCode = InternalErrorCode.PUSH_TOKEN_HMAC_KEY_LOAD_FAILED,
            missingDeviceIdCode = InternalErrorCode.PUSH_TOKEN_DEVICE_ID_LOAD_FAILED
        )
    }

    private fun ensureReady(
        missingHmacCode: InternalErrorCode,
        missingDeviceIdCode: InternalErrorCode
    ) {
        if (!requestSigner.isAvailable()) {
            throw GoPassException.from(
                error = ErrorCode.INTERNAL_ERROR,
                internalCode = missingHmacCode
            )
        }

        val deviceId = identityRepository.getDeviceId()
        if (deviceId.isNullOrBlank()) {
            throw GoPassException.from(
                error = ErrorCode.INTERNAL_ERROR,
                internalCode = missingDeviceIdCode
            )
        }
    }
}

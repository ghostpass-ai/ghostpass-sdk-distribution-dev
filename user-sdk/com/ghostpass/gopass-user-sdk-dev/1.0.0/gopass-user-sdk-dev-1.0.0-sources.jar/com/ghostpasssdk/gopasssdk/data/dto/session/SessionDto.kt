package com.ghostpasssdk.gopasssdk.data.dto.session

import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import kotlinx.serialization.Serializable

@Serializable
internal data class SessionDto(
    val sessionId: String,
    val rtdbPath: String,
    val encryptedDk: String,
    val firebaseToken: String,
    val status: String,
    val expiresAt: String
) {
    fun toDomain(): EncryptedSession = EncryptedSession(
        sessionId = this.sessionId,
        rtdbPath = this.rtdbPath,
        encryptedDk = this.encryptedDk,
        firebaseToken = this.firebaseToken,
        status = this.status,
        expiresAt = this.expiresAt
    )
}

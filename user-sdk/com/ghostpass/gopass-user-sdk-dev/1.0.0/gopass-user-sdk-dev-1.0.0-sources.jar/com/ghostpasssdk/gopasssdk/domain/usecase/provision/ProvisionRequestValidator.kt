package com.ghostpasssdk.gopasssdk.domain.usecase.provision

import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ProvisionParams

internal class ProvisionRequestValidator(
    private val expectedPlatform: String,
    private val publicKeyValidator: (String) -> Boolean
) {
    fun validate(params: ProvisionParams) {
        when {
            params.challenge.isBlank() -> throw invalid(InternalErrorCode.PROVISION_CHALLENGE_MISSING)
            params.attestation.isBlank() -> throw invalid(InternalErrorCode.PROVISION_ATTESTATION_MISSING)
            params.platform != expectedPlatform -> throw invalid(InternalErrorCode.PROVISION_PLATFORM_INVALID)
            params.platformId.isBlank() -> throw invalid(InternalErrorCode.PROVISION_PLATFORM_ID_MISSING)
            params.installId.isBlank() -> throw invalid(InternalErrorCode.PROVISION_INSTALL_ID_MISSING)
            !publicKeyValidator(params.clientPublicKey) ->
                throw invalid(InternalErrorCode.PROVISION_CLIENT_PUBLIC_KEY_INVALID)
        }
    }

    private fun invalid(internalErrorCode: InternalErrorCode): GoPassException {
        return GoPassException.from(
            error = ErrorCode.INVALID_PARAMETERS,
            internalCode = internalErrorCode
        )
    }
}

package com.ghostpasssdk.gopasssdk.domain.model.external

import androidx.annotation.Keep

@Keep
data class HasBioDataResult(
    val hasBioData: Boolean,
    val registeredAt: String?
)

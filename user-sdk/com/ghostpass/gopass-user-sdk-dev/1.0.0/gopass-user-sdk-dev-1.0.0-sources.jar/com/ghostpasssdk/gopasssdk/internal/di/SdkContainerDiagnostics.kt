package com.ghostpasssdk.gopasssdk.internal.di

import com.ghostpasssdk.gopasssdk.internal.manager.ApiDiagnosticsManager

internal fun SdkContainer.createApiDiagnosticsManager(): ApiDiagnosticsManager {
    return ApiDiagnosticsManager(
        context = appContext,
        identityRepository = identityRepository,
        deviceIdUseCase = deviceIdUseCase,
        provisionUseCase = provisionUseCase,
        authRepository = authRepository,
        sessionRepository = sessionRepository,
        integrityTokenProvider = integrityTokenProvider,
        keyManager = keyManager
    )
}

package com.ghostpasssdk.gopasssdk.domain.model.external.error

import androidx.annotation.Keep
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode

@Keep
class GoPassException(
    val code: String,
    override val message: String,
    val internalCode: String? = null
) : Exception(message, null, false, false) {
    override fun fillInStackTrace(): Throwable = this

    override fun toString(): String {
        val internalInfo = internalCode?.let { " (Internal: $it)" } ?: ""
        return "[$code] $message$internalInfo"
    }

    companion object {
        internal fun from(
            error: ErrorCode,
            customMessage: String? = null
        ): GoPassException {
            val msg = customMessage ?: error.message ?: "GoPass SDK error: ${error.externalCode}"
            return GoPassException(
                code = error.externalCode,
                message = msg,
                internalCode = null
            )
        }

        internal fun from(
            error: ErrorCode,
            customMessage: String? = null,
            internalCode: InternalErrorCode
        ): GoPassException {
            val msg = customMessage ?: error.message ?: "GoPass SDK error: ${error.externalCode}"
            return GoPassException(
                code = error.externalCode,
                message = msg,
                internalCode = internalCode.code
            )
        }
    }
}

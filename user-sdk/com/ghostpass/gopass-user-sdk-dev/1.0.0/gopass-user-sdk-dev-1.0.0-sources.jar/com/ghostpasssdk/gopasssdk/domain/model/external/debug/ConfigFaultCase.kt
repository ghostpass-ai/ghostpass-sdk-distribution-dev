package com.ghostpasssdk.gopasssdk.domain.model.external.debug

import androidx.annotation.Keep

@Keep
enum class ConfigFaultCase {
    MISSING_HMAC_KEY,
    EMPTY_API_KEY_HEADER,
    INVALID_API_KEY_HEADER,
    EMPTY_DEVICE_ID_HEADER,
    INVALID_DEVICE_ID_HEADER,
}

package com.ghostpasssdk.gopasssdk.domain.engine.face

import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceEngineTypes
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceExtractResult

internal interface FaceDetectionEngine {

    fun checkMemory(width: Int, height: Int)

    fun createInputImage(
        faceImage: ByteArray,
        width: Int,
        height: Int,
        rotation: Int
    ): FaceEngineTypes.FaceImageFrame

    fun detectFirstFace(inputImage: FaceEngineTypes.FaceImageFrame): FaceEngineTypes.DetectedFace?

    fun validatePose(face: FaceEngineTypes.DetectedFace): FaceExtractResult.Continue?

    fun validatePosition(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue?

    fun validateSizeMin(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue?

    fun validateSizeMax(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue?

    fun validateLandmarkConfidence(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue?
}
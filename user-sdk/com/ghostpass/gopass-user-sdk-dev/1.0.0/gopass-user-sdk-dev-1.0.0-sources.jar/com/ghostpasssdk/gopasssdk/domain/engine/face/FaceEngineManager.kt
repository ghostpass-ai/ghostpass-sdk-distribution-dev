package com.ghostpasssdk.gopasssdk.domain.engine.face

internal interface FaceEngineManager {
    suspend fun initialize()
}
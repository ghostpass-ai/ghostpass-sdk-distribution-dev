package com.ghostpasssdk.gopasssdk.data.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.infra.SignedRequestPreflightChecker
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.core.network.utils.safeApiCall
import com.ghostpasssdk.gopasssdk.data.api.SessionApi
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionRequest
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionParams
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository

internal class SessionRepositoryImpl(
    private val sessionApi: SessionApi,
    private val signedRequestPreflightChecker: SignedRequestPreflightChecker
) : SessionRepository {
    override suspend fun sessions(
        params: SessionParams
    ): ApiResult<EncryptedSession> {
        signedRequestPreflightChecker.ensureSessionReady()
        val requestDto = SessionRequest(
            beaconMajor = params.major,
            beaconMinor = params.minor,
            beaconRssi = params.rssi
        )
        return safeApiCall({ sessionApi.requestSession(requestDto) }) { it.toDomain() }
    }
}

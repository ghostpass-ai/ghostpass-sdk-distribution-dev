package com.ghostpasssdk.gopasssdk.core.security.infra

import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager

internal class LocalDataEncryptor(
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager
) {
    fun encrypt(plainText: String): String {
        val masterKey = keyManager.getSecretKey(KeyManager.MASTER_KEY_ALIAS)
        val emptyAad = ByteArray(0)
        return cryptoEngine.encrypt(plainText, masterKey, emptyAad)
    }

    fun decrypt(encryptedBase64: String): String {
        val masterKey = keyManager.getSecretKey(KeyManager.MASTER_KEY_ALIAS)
        val emptyAad = ByteArray(0)
        val decryptedBytes = cryptoEngine.decryptData(masterKey, encryptedBase64, emptyAad)
        return String(decryptedBytes, Charsets.UTF_8)
    }
}
package com.ghostpasssdk.gopasssdk.domain.model.internal.landmark

internal data class FaceVectorPayload(
    val type: String,
    val vector: FloatArray,
    val timestamp: Long
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as FaceVectorPayload

        if (timestamp != other.timestamp) return false
        if (type != other.type) return false
        if (!vector.contentEquals(other.vector)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = timestamp.hashCode()
        result = 31 * result + type.hashCode()
        result = 31 * result + vector.contentHashCode()
        return result
    }
}

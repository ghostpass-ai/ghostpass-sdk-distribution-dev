package com.ghostpasssdk.gopasssdk.data.engine.monitor

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.ghostpasssdk.gopasssdk.R
import com.ghostpasssdk.gopasssdk.core.device.observer.DeviceStateObserver
import com.ghostpasssdk.gopasssdk.domain.usecase.device.CheckAllConditionsUseCase
import com.ghostpasssdk.gopasssdk.internal.di.SdkContainer
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

internal class BeaconDetectionService : Service() {

    companion object {
        const val TAG = "BeaconDetectionService TAG"
        const val ACTION_STOP_FOREGROUND = "com.ghostpasssdk.action.STOP_FOREGROUND"
        private const val SERVICE_CHANNEL_ID = "beacon_channel_v2"
        private const val SERVICE_NOTIFICATION_ID = 2
        private const val RSSI_THRESHOLD_MIN = -70
        private const val RSSI_THRESHOLD_MAX = 0
        // 키오스크 비콘 ADVERTISE_MODE_LOW_LATENCY(~100ms) + SCAN_MODE_BALANCED(~5초 주기) 기준,
        // 스캔 윈도우 약 2회분(10초) 동안 미수신 시 실제 리전 이탈로 판정
        private const val REGION_EXIT_TIMEOUT_MS = 10_000L
        private const val APPLE_COMPANY_ID = 0x004C

        private val scanning = AtomicBoolean(false)

        /** BeaconWakeReceiver가 서비스 생존 여부를 판단하는 플래그 */
        @Volatile
        var isServiceAlive = false
            private set

        private val insuranceScanRegistered = AtomicBoolean(false)

        fun isCurrentlyScanning(): Boolean {
            return scanning.get()
        }
    }

    private lateinit var checkAllConditionsUseCase: CheckAllConditionsUseCase
    private lateinit var notificationManager: NotificationManager
    private var wakeLock: PowerManager.WakeLock? = null

    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private var targetUuid: UUID? = null

    /**
    isInRegion / regionExitJob은 모든 접근 경로가 Main 스레드로 통일되어 있어
    별도 동기화 없이 단일 스레드 보장으로 스레드 안전성을 확보한다.
    - processScanResult: mainScope.launch → Main
    - stopBeaconScanning: onStartCommand/onDestroy/deviceStateObserver 전부 Main
    - handleScanFailed: Binder 스레드이나, 해당 필드 접근은 mainScope.launch 내부에서만 수행
     **/
    private var isInRegion = false
    private var regionExitJob: Job? = null

    private lateinit var container: SdkContainer
    private lateinit var deviceStateObserver: DeviceStateObserver

    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            mainScope.launch { processScanResult(result) }
        }

        override fun onScanFailed(errorCode: Int) {
            handleScanFailed(errorCode)
        }
    }

    /**
    @Synchronized: Binder 스레드에서 호출되므로 scanning / bluetoothLeScanner 보호 필요.
    isInRegion / regionExitJob 접근은 mainScope.launch 내부에서만 수행하여 Main 스레드 통일.
     **/
    @Synchronized
    private fun handleScanFailed(errorCode: Int) {
        errorLog(TAG, "BLE 스캔 실패: errorCode=$errorCode")
        scanning.set(false)
        BeaconServiceEventBus.clearScanStartEvents()
        BeaconServiceEventBus.notifyScanStartFailed("BLE 스캔 실패: errorCode=$errorCode")
        BeaconServiceEventBus.notifyScanStopped()
        mainScope.launch {
            val wasInRegion = isInRegion
            regionExitJob?.cancel()
            regionExitJob = null
            isInRegion = false
            if (wasInRegion) {
                BeaconServiceEventBus.notifyRegionExited()
            }
        }
    }

    private fun processScanResult(result: ScanResult) {
        val scanRecord = result.scanRecord ?: return
        val manufacturerData = scanRecord.getManufacturerSpecificData(APPLE_COMPANY_ID) ?: return
        val iBeacon = parseIBeacon(manufacturerData) ?: return

        val target = targetUuid ?: return
        if (iBeacon.uuid != target) return

        // 리전 진입/유지 처리
        regionExitJob?.cancel()
        if (!isInRegion) {
            isInRegion = true
            debugLog(TAG, "didEnterRegion: UUID=${iBeacon.uuid}")
            BeaconServiceEventBus.notifyRegionEntered()
        }
        regionExitJob = mainScope.launch {
            delay(REGION_EXIT_TIMEOUT_MS)
            if (isInRegion) {
                isInRegion = false
                debugLog(TAG, "didExitRegion: 감지 해제")
                BeaconServiceEventBus.notifyRegionExited()
            }
        }

        val rssi = result.rssi
        if (rssi in RSSI_THRESHOLD_MIN..RSSI_THRESHOLD_MAX) {
            debugLog(
                TAG,
                "⚡️유효 RSSI 진입: Major=${iBeacon.major}, Minor=${iBeacon.minor}, RSSI=$rssi"
            )
            BeaconServiceEventBus.notifyBeaconDetected(iBeacon.major, iBeacon.minor, rssi)
        }
    }

    private data class IBeaconData(
        val uuid: UUID,
        val major: Int,
        val minor: Int,
        val txPower: Int
    )

    private fun parseIBeacon(manufacturerData: ByteArray): IBeaconData? {
        // iBeacon manufacturer specific data (Apple company ID 이후):
        // Byte 0: 비콘 타입 (0x02)
        // Byte 1: 데이터 길이 (0x15 = 21)
        // Bytes 2-17: UUID (16 bytes)
        // Bytes 18-19: Major (2 bytes, big-endian)
        // Bytes 20-21: Minor (2 bytes, big-endian)
        // Byte 22: TX Power (1 byte, signed)
        if (manufacturerData.size < 23) return null
        if (manufacturerData[0] != 0x02.toByte() || manufacturerData[1] != 0x15.toByte()) return null

        val uuidBuffer = ByteBuffer.wrap(manufacturerData, 2, 16)
        val uuid = UUID(uuidBuffer.long, uuidBuffer.long)

        val major = ((manufacturerData[18].toInt() and 0xFF) shl 8) or
                (manufacturerData[19].toInt() and 0xFF)
        val minor = ((manufacturerData[20].toInt() and 0xFF) shl 8) or
                (manufacturerData[21].toInt() and 0xFF)
        val txPower = manufacturerData[22].toInt()

        return IBeaconData(uuid, major, minor, txPower)
    }

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                SERVICE_CHANNEL_ID,
                "Beacon Scanning",
                NotificationManager.IMPORTANCE_MIN
            )
            notificationManager.createNotificationChannel(ch)
        }
    }

    private fun buildServiceNotification(
        title: String = getString(R.string.notif_1),
        text: String = getString(R.string.notif_2)
    ): Notification {
        return NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setAutoCancel(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_DEFERRED)
            .build().apply {
                flags = flags or Notification.FLAG_NO_CLEAR or Notification.FLAG_ONGOING_EVENT
            }
    }

    override fun onCreate() {
        super.onCreate()
        isServiceAlive = true
        scanning.set(false)
        debugLog(TAG, "onCreate: 호출")

        // ── 1단계: startForeground 최우선 호출 (5초 타임아웃 크래시 방지) ──
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannelIfNeeded()
        val initial = buildServiceNotification(
            title = "고패스가 준비 중…",
            text = "스캔 초기화 중"
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val types = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                startForeground(SERVICE_NOTIFICATION_ID, initial, types)
            } else {
                startForeground(SERVICE_NOTIFICATION_ID, initial)
            }
        } catch (e: Exception) {
            errorLog(TAG, "startForeground 실패 — 조용히 종료: ${e.message}")
            stopSelf()
            return
        }

        // ── 2단계: SDK 컨테이너 초기화 (보험 스캔 wake-up 시 실패할 수 있음) ──
        try {
            container = SdkContainer.getOrCreate(applicationContext)
            checkAllConditionsUseCase = container.checkAllConditionsUseCase
            container.ensureProximityLifecycle()
        } catch (e: Exception) {
            errorLog(TAG, "SDK 초기화 실패 (보험 스캔 wake-up 추정) — 서비스 종료: ${e.message}")
            removeForegroundNotification()
            stopSelf()
            return
        }

        // ── 3단계: 상태 감지 옵저버 시작 ──
        // 모든 콜백을 Main dispatcher로 통일 (NET_CHANGED는 ConnectivityThread에서 올 수 있음)
        deviceStateObserver = DeviceStateObserver(this) { reason ->
            mainScope.launch {
                if (reason == "BT_ON") delay(1000)
                updateScanningState(reason)
            }
        }
        deviceStateObserver.startObserving()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_FOREGROUND) {
            warnLog(TAG, "onStartCommand STOP requested")
            stopForegroundAndService()
            return START_STICKY
        }

        // SDK 초기화 실패로 container가 미초기화 상태일 수 있음 (보험 스캔 wake-up 후 stopSelf 대기 중)
        if (!::container.isInitialized) return START_STICKY

        notificationManager.notify(
            SERVICE_NOTIFICATION_ID,
            buildServiceNotification(title = "고패스가 실행 중", text = "서비스 상태 점검 중")
        )

        updateScanningState(reason = "onStartCommand")
        return START_STICKY
    }

    private fun updateScanningState(reason: String) {
        val result = checkAllConditionsUseCase()
        if (result.ok) {
            startBeaconScanning()
            notificationManager.notify(SERVICE_NOTIFICATION_ID, buildServiceNotification())
        } else {
            stopBeaconScanning("조건 미충족: $reason")
            val title = getString(R.string.notification_title_wait)
            val text = when (result.missing) {
                CheckAllConditionsUseCase.Missing.Bluetooth -> getString(R.string.notification_bluetooth)
                CheckAllConditionsUseCase.Missing.Gps -> getString(R.string.notification_gps)
                CheckAllConditionsUseCase.Missing.Network -> getString(R.string.notification_network)
                else -> getString(R.string.notification_else)
            }
            notificationManager.notify(
                SERVICE_NOTIFICATION_ID,
                buildServiceNotification(title, text)
            )
        }
    }

    /**
    @Synchronized는 scanning / bluetoothLeScanner를 Binder 스레드(handleScanFailed)와의
    동시 접근으로부터 보호하기 위한 것이다. isInRegion / regionExitJob은 Main 스레드 전용.
     **/
    @SuppressLint("MissingPermission")
    @Synchronized
    private fun startBeaconScanning() {
        if (scanning.get()) return

        val uuidStr = container.identityRepository.getBeaconUuid()
        if (uuidStr.isNullOrBlank()) {
            warnLog(TAG, "저장된 비콘 UUID가 없어 스캔을 시작할 수 없습니다.")
            mainScope.launch { BeaconServiceEventBus.notifyScanStartFailed("UUID 누락으로 인한 서비스 종료") }
            stopForegroundAndService()
            return
        }

        try {
            targetUuid = UUID.fromString(uuidStr)

            if (bluetoothLeScanner == null) {
                val bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
                bluetoothLeScanner = bluetoothManager.adapter?.bluetoothLeScanner
            }

            val scanner = bluetoothLeScanner
            if (scanner == null) {
                errorLog(TAG, "BluetoothLeScanner를 가져올 수 없습니다.")
                mainScope.launch {
                    BeaconServiceEventBus.notifyScanStartFailed("BLE 스캐너 초기화 실패")
                }
                return
            }

            val scanFilter = ScanFilter.Builder()
                .setManufacturerData(
                    APPLE_COMPANY_ID,
                    byteArrayOf(0x02, 0x15),
                    byteArrayOf(0xFF.toByte(), 0xFF.toByte())
                )
                .build()

            /** BALANCED: ~2초 스캔 / ~3초 대기 주기. 종일 상시 실행되는 포그라운드 서비스이므로 배터리 고려.
            키오스크 비콘이 ADVERTISE_MODE_LOW_LATENCY(~100ms 주기)로 브로드캐스트하므로
            단일 스캔 윈도우(~2초) 내에서 TARGET_HIT_COUNT(3회)를 충족한다.
            worst case 레이턴시: 스캔 윈도우 대기 ~5초.
             */
            val scanSettings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_BALANCED)
                .setReportDelay(0)
                .build()

            scanner.startScan(listOf(scanFilter), scanSettings, scanCallback)
            scanning.set(true)
            acquireWakeLock()
            BeaconServiceEventBus.notifyScanStarted()

            // 보험 스캔: OS에 PendingIntent BLE 스캔을 한 번만 등록 (프로세스 kill 후에도 유지)
            registerInsuranceScan(scanner, targetUuid!!)

        } catch (e: Exception) {
            errorLog(TAG, "startBeaconScanning 실패: ${e.message}")
            mainScope.launch {
                BeaconServiceEventBus.notifyScanStartFailed("BLE 스캔 시작 실패: ${e.message}")
            }
        }
    }

    // ── 보험 스캔: 프로세스 종료 후에도 OS BT 칩이 비콘 감지 시 BeaconWakeReceiver를 깨운다 ──

    /**
     * OS BT 하드웨어에 PendingIntent 기반 BLE 스캔을 한 번만 등록한다.
     * ScanFilter에 UUID를 포함시켜 우리 비콘만 매칭되도록 한다.
     * PendingIntent는 BeaconWakeReceiver(BroadcastReceiver)를 타겟하며,
     * 리시버가 isServiceAlive를 확인하여 서비스가 죽었을 때만 FGS를 기동한다.
     */
    @SuppressLint("MissingPermission")
    private fun registerInsuranceScan(scanner: BluetoothLeScanner, uuid: UUID) {
        if (!insuranceScanRegistered.compareAndSet(false, true)) {
            debugLog(TAG, "보험 스캔 이미 등록됨 → skip")
            return
        }

        try {
            // UUID를 포함한 ScanFilter — 우리 비콘에만 반응
            val uuidBytes = ByteBuffer.allocate(16).apply {
                putLong(uuid.mostSignificantBits)
                putLong(uuid.leastSignificantBits)
            }.array()

            val pattern = ByteArray(2 + 16) // prefix(2) + uuid(16)
            val mask = ByteArray(2 + 16)
            pattern[0] = 0x02; pattern[1] = 0x15
            mask[0] = 0xFF.toByte(); mask[1] = 0xFF.toByte()
            System.arraycopy(uuidBytes, 0, pattern, 2, 16)
            for (i in 2 until 18) mask[i] = 0xFF.toByte()

            val filter = ScanFilter.Builder()
                .setManufacturerData(APPLE_COMPANY_ID, pattern, mask)
                .build()

            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER)
                .setReportDelay(20_000L) // 20초 배치 — 배터리 보호
                .build()

            val intent = Intent(applicationContext, BeaconWakeReceiver::class.java).apply {
                action = BeaconWakeReceiver.ACTION_BEACON_WAKE
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                applicationContext, BeaconWakeReceiver.WAKE_SCAN_REQUEST_CODE, intent, flags
            )

            scanner.startScan(listOf(filter), settings, pi)
            debugLog(TAG, "보험 스캔 등록 성공 (OS 위임, LOW_POWER, reportDelay=20s)")
        } catch (e: SecurityException) {
            insuranceScanRegistered.set(false)
            warnLog(TAG, "보험 스캔 등록 SecurityException: ${e.message}")
        } catch (e: Exception) {
            insuranceScanRegistered.set(false)
            warnLog(TAG, "보험 스캔 등록 실패: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun unregisterInsuranceScan() {
        if (!insuranceScanRegistered.get()) return
        try {
            val intent = Intent(applicationContext, BeaconWakeReceiver::class.java).apply {
                action = BeaconWakeReceiver.ACTION_BEACON_WAKE
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                applicationContext, BeaconWakeReceiver.WAKE_SCAN_REQUEST_CODE, intent, flags
            )
            val bm = getSystemService(BLUETOOTH_SERVICE) as? BluetoothManager
            bm?.adapter?.bluetoothLeScanner?.stopScan(pi)
            debugLog(TAG, "보험 스캔 해제 완료")
        } catch (e: Exception) {
            warnLog(TAG, "보험 스캔 해제 예외: ${e.message}")
        } finally {
            insuranceScanRegistered.set(false)
        }
    }

    // @Synchronized: startBeaconScanning과 동일한 이유. 상단 필드 주석 참조.
    @SuppressLint("MissingPermission")
    @Synchronized
    private fun stopBeaconScanning(reason: String) {
        if (!scanning.get()) return

        runCatching { bluetoothLeScanner?.stopScan(scanCallback) }
            .onFailure { e -> errorLog(TAG, "stopScan 에러 ($reason): ${e.message}") }
        // 보험 스캔(PendingIntent)은 해제하지 않음 — 프로세스 kill 후 wake-up 유지

        val wasInRegion = isInRegion
        bluetoothLeScanner = null
        regionExitJob?.cancel()
        regionExitJob = null
        isInRegion = false
        scanning.set(false)
        releaseWakeLock()

        if (wasInRegion) {
            BeaconServiceEventBus.notifyRegionExited()
        }
        BeaconServiceEventBus.notifyScanStopped()
    }

    private fun removeForegroundNotification() {
        try {
            notificationManager.cancel(SERVICE_NOTIFICATION_ID)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (e: Exception) {
            warnLog(TAG, "stop foreground error: ${e.message}")
        }
    }

    /** SDK에서 명시적으로 서비스를 종료할 때만 호출. 보험 스캔도 해제한다. */
    private fun stopForegroundAndService() {
        unregisterInsuranceScan()
        removeForegroundNotification()
        stopSelf()
    }

    /**
     * 앱이 최근 앱 목록에서 스와이프 종료될 때 호출된다.
     * 보험 스캔(PendingIntent → BeaconWakeReceiver)이 OS에 등록되어 있으므로
     * 프로세스 kill 후에도 비콘 감지 시 리시버가 FGS를 기동한다.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        warnLog(TAG, "onTaskRemoved: 앱 스와이프 종료 — 보험 스캔이 OS에 유지됨")
    }

    override fun onDestroy() {
        isServiceAlive = false
        stopBeaconScanning("onDestroy")
        releaseWakeLock()
        if (::deviceStateObserver.isInitialized) deviceStateObserver.stopObserving()
        removeForegroundNotification()
        // 보험 스캔은 해제하지 않음 — 프로세스 kill 후에도 OS가 비콘 감지 시 리시버로 FGS 부활
        BeaconServiceEventBus.notifyServiceDestroyed()
        mainScope.cancel()
        super.onDestroy()
    }

    @SuppressLint("WakelockTimeout")
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ghostpass:beacon-scan").apply {
            acquire()
        }
        debugLog(TAG, "WakeLock acquired")
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
                debugLog(TAG, "WakeLock released")
            }
        }
        wakeLock = null
    }

    override fun onBind(intent: Intent): IBinder? = null
}

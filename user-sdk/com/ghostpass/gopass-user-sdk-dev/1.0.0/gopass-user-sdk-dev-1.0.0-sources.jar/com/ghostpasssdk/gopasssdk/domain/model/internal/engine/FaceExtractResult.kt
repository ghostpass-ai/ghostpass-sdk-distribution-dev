package com.ghostpasssdk.gopasssdk.domain.model.internal.engine

import com.ghostpasssdk.gopasssdk.domain.model.external.CaptureGuide

internal sealed interface FaceExtractResult {
    data class Continue(val reason: CaptureGuide) : FaceExtractResult
    data class Success(val landmark: FloatArray) : FaceExtractResult {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as Success

            return landmark.contentEquals(other.landmark)
        }

        override fun hashCode(): Int {
            return landmark.contentHashCode()
        }
    }
}
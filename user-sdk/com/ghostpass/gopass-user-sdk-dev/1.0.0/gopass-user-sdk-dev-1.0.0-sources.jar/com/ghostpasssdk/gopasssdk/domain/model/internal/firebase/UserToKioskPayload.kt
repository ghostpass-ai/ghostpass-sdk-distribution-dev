package com.ghostpasssdk.gopasssdk.domain.model.internal.firebase

internal data class UserToKioskPayload(
    val payload: String,
    val seq: Int
)

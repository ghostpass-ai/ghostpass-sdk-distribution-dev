package com.ghostpasssdk.gopasssdk.domain.usecase.provision

import android.util.Base64
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Provision
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.useAndWipe
import java.security.PrivateKey
import java.security.PublicKey
import javax.crypto.spec.SecretKeySpec

internal class ProvisionUseCase(
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager
) {
    companion object {
        private const val TAG = "ProvisionKeyExchange TAG"
        private const val AES_INFO = "ghostpass-ecdh-provision-v1"
        private const val TRANSPORT_INFO = "ghostpass-transport-key-v1"
        private const val HMAC_INFO = "ghostpass-hmac-key-v1"
    }

    fun generatePublicKey(): String {
        return try {
            keyManager.generateEcdhKeyPair()
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "ECDH 키 쌍 생성 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.ECDH_KEY_GENERATION_FAILED // IN-111
            )
        }
    }

    fun isValidPublicKey(encodedPublicKey: String): Boolean {
        if (encodedPublicKey.isBlank()) {
            return false
        }

        return try {
            cryptoEngine.decodeECPublicKey(encodedPublicKey)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun isRequire(): Boolean {
        return try {
            !keyManager.hasSecretKey(KeyManager.HMAC_ALIAS)
        } catch (e: Exception) {
            errorLog(TAG, "키 존재 여부 확인 중 에러: $e")
            true // 에러가 나면 안전하게 프로비저닝을 다시 요구하도록 처리
        }
    }

    fun processKeyExchange(
        apiKey: String,
        provision: Provision
    ) {
        try {
            val serverPubKey = decodeServerPublicKey(provision.serverPublicKey)

            // Private Key 로드 시점 예외 처리
            val privateKey = try {
                keyManager.getPrivateKey()
            } catch (e: GoPassException) {
                throw e
            } catch (e: Exception) {
                errorLog(TAG, "ECDH 개인키 조회 실패: $e")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.PRIVATE_KEY_NOT_FOUND // IN-112
                )
            }

            provision.deviceId.toByteArray().useAndWipe { deviceIdBytes ->
                deriveProvisionSecret(
                    apiKey = apiKey,
                    provision = provision,
                    deviceIdBytes = deviceIdBytes,
                    privateKey = privateKey,
                    serverPubKey = serverPubKey
                ).useAndWipe { appSecret ->
                    importDerivedKeys(
                        appSecret = appSecret,
                        deviceIdBytes = deviceIdBytes
                    )
                }
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            // 예측하지 못한 시스템 에러 방어
            errorLog(TAG, "Key Exchange 진행 중 시스템 예외: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.CONFIRM_FAILED // 또는 적절한 범용 시스템 에러 코드
            )
        }
    }

    private fun decodeServerPublicKey(serverPublicKey: String): PublicKey {
        return try {
            cryptoEngine.decodeECPublicKey(serverPublicKey)
        } catch (e: Exception) {
            errorLog(TAG, "서버 공개키 디코딩 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.SERVER_PUBLIC_KEY_DECODE_FAILED // IN-205
            )
        }
    }

    private fun deriveProvisionSecret(
        apiKey: String,
        provision: Provision,
        deviceIdBytes: ByteArray,
        privateKey: PrivateKey,
        serverPubKey: PublicKey
    ): ByteArray {

        // 1. Shared Key 도출 및 처리
        val sharedKey = try {
            cryptoEngine.deriveSharedKey(privateKey, serverPubKey)
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "Shared Key 유도 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.SHARED_KEY_DERIVATION_FAILED // IN-113
            )
        }

        return sharedKey.useAndWipe { sk ->

            // 2. HKDF 도출 (AES Key)
            val aesKey = try {
                cryptoEngine.hkdf(sk, deviceIdBytes, AES_INFO)
            } catch (e: Exception) {
                errorLog(TAG, "aesKey 도출 실패: $e")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.TRANSPORT_KEY_DERIVATION_FAILED // IN-203
                )
            }

            aesKey.useAndWipe { ak ->

                // 3. 앱 시크릿 복호화
                val decryptedBytes = try {
                    decryptAppSecret(apiKey, provision, ak)
                } catch (e: GoPassException) {
                    throw e
                } catch (e: Exception) {
                    errorLog(TAG, "앱 시크릿 복호화 실패: $e")
                    throw GoPassException.from(
                        error = ErrorCode.INITIALIZATION_FAILED,
                        internalCode = InternalErrorCode.APP_SECRET_DECODE_FAILED // IN-206
                    )
                }

                decryptedBytes.useAndWipe { db ->

                    // 4. 최종 인코딩 반환
                    try {
                        Base64.encode(db, Base64.NO_WRAP)
                    } catch (e: Exception) {
                        errorLog(TAG, "앱 시크릿 Base64 인코딩 실패: $e")
                        throw GoPassException.from(
                            error = ErrorCode.INITIALIZATION_FAILED,
                            internalCode = InternalErrorCode.DECRYPTION_FAILED
                        )
                    }
                }
            }
        }
    }

    private fun decryptAppSecret(
        apiKey: String,
        provision: Provision,
        aesKey: ByteArray
    ): ByteArray {
        val aadString = "${apiKey.trim()}:${provision.deviceId.trim()}"

        return aadString.toByteArray(Charsets.UTF_8).useAndWipe { aadBytes ->
            try {
                cryptoEngine.decryptData(
                    key = SecretKeySpec(aesKey, "AES"),
                    encryptedBase64 = provision.encryptedAppSecret,
                    aad = aadBytes
                )
            } catch (e: Exception) {
                errorLog(TAG, "앱 시크릿 복호화 에러 (AAD 불일치 등): $e")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.APP_SECRET_DECODE_FAILED // IN-206
                )
            }
        }
    }

    private fun importDerivedKeys(
        appSecret: ByteArray,
        deviceIdBytes: ByteArray
    ) {
        // ---------------------------------------------------------
        // 1. HMAC Key 도출 및 저장
        // ---------------------------------------------------------
        val hmacKey = try {
            cryptoEngine.hkdf(
                ikm = appSecret,
                salt = deviceIdBytes,
                info = HMAC_INFO
            )
        } catch (e: Exception) {
            errorLog(TAG, "HMAC Key 도출 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.TRANSPORT_KEY_DERIVATION_FAILED // IN-203 (파생 실패 공통)
            )
        }

        hmacKey.useAndWipe { hk ->
            try {
                keyManager.importSecretKey(KeyManager.HMAC_ALIAS, hk)
            } catch (e: GoPassException) {
                throw e
            } catch (e: Exception) {
                errorLog(TAG, "HMAC Key 저장 실패: $e")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.HMAC_KEY_SAVE_FAILED // IN-217
                )
            }
        }

        // ---------------------------------------------------------
        // 2. Transport Key 도출 및 저장
        // ---------------------------------------------------------
        val transportKey = try {
            cryptoEngine.hkdf(
                ikm = appSecret,
                salt = deviceIdBytes,
                info = TRANSPORT_INFO
            )
        } catch (e: Exception) {
            errorLog(TAG, "Transport Key 도출 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.TRANSPORT_KEY_DERIVATION_FAILED // IN-203
            )
        }

        transportKey.useAndWipe { tk ->
            try {
                keyManager.importSecretKey(KeyManager.TRANSPORT_ALIAS, tk)
            } catch (e: GoPassException) {
                throw e
            } catch (e: Exception) {
                errorLog(TAG, "Transport Key 저장 실패: $e")
                throw GoPassException.from(
                    error = ErrorCode.INITIALIZATION_FAILED,
                    internalCode = InternalErrorCode.TRANSPORT_KEY_SAVE_FAILED // IN-225
                )
            }
        }
    }
}

package com.ghostpasssdk.gopasssdk.data.engine.face.wrapper

import com.alcherainc.facesdk.type.Face
import com.alcherainc.facesdk.type.InputImage
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceEngineTypes

internal class AlcheraImageFrame(
    val originImage: InputImage
) : FaceEngineTypes.FaceImageFrame

internal class AlcheraDetectedFace(
    val originFace: Face
) : FaceEngineTypes.DetectedFace